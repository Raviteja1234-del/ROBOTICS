"""
Main Application Entry Point for Autonomous Underwater Robot - Seabed Classification & Exploration.

Runs PPO reinforcement learning in a background thread and presents real-time telemetry on desktop dashboard.
"""

from __future__ import annotations
import sys
import time
import argparse
import threading
from typing import Dict, Any
import numpy as np

try:
    from PyQt6.QtWidgets import QApplication
except Exception:
    from PyQt5.QtWidgets import QApplication

from env import make_seabed_env, SeabedEnv
from cnn import train_cnn
from dashboard import DashboardWindow


class SimulationRunner:
    """Manages the background RL exploration loop and thread-safe telemetry sync."""
    def __init__(self, mode: str = "mock", speed: float = 1.0):
        self.mode = mode
        self.speed_multiplier = float(speed)
        self.running = True
        self.paused = False
        self.stop_requested = False

        self.env: SeabedEnv = make_seabed_env(mode=mode)
        self.state_lock = threading.Lock()
        self.shared_state: Dict[str, Any] = {}
        self.start_time = time.time()
        self.logs = [
            f"[{time.strftime('%H:%M:%S')}] Mission system initialized ({mode.upper()} mode)",
            f"[{time.strftime('%H:%M:%S')}] Camera feed acquired",
            f"[{time.strftime('%H:%M:%S')}] PPO Exploration Policy loaded",
            f"[{time.strftime('%H:%M:%S')}] Mission running",
        ]

        # PPO Agent (loads Stable-Baselines3 if present, or heuristic explorer)
        self.policy = None
        self._init_rl_policy()

        # Sync initial state
        self._update_shared_state(self.env.reset()[0], 0.0, False, False, {})

    def _init_rl_policy(self):
        """Initializes or loads Stable-Baselines3 PPO policy."""
        try:
            from stable_baselines3 import PPO
            import os
            model_path = "models/ppo_auv.zip"
            if os.path.exists(model_path):
                self.policy = PPO.load(model_path, env=self.env)
                self.log("Loaded pre-trained PPO policy model")
            else:
                self.policy = PPO("MlpPolicy", self.env, verbose=0, learning_rate=3e-4, n_steps=256, batch_size=64)
                self.log("Created active PPO learning agent")
        except Exception as e:
            self.policy = None
            self.log(f"RL policy fallback to heuristic: {e}")

    def log(self, message: str):
        t_str = time.strftime('%H:%M:%S')
        self.logs.append(f"[{t_str}] {message}")
        if len(self.logs) > 20:
            self.logs.pop(0)

    def _update_shared_state(self, obs: np.ndarray, reward: float, terminated: bool, truncated: bool, info: dict):
        with self.state_lock:
            self.shared_state = {
                "running": self.running and not self.paused,
                "elapsed": time.time() - self.start_time,
                "speed_multiplier": self.speed_multiplier,
                "pos": tuple(self.env.pos),
                "heading": self.env.heading,
                "depth": self.env.depth,
                "speed": self.env.speed,
                "battery": self.env.battery,
                "episode": self.env.episode_count,
                "step": self.env.step_count,
                "total_reward": self.env.total_reward,
                "obstacle_distance": self.env.latest_obstacle_distance,
                "camera_frame": self.env.latest_camera_frame,
                "chase_frame": self.env.latest_chase_frame,
                "cnn": self.env.latest_cnn_prediction,
                "classified_map": self.env.classified_map,
                "explored_mask": self.env.explored_mask,
                "path": list(self.env.path_history),
                "logs": list(self.logs),
            }

    def start(self):
        self.running = True
        self.paused = False
        self.log("Mission started / resumed")

    def pause(self):
        self.paused = True
        self.log("Mission paused")

    def reset(self):
        obs, _ = self.env.reset()
        self.start_time = time.time()
        self._update_shared_state(obs, 0.0, False, False, {})
        self.log("Mission reset")

    def new_environment(self):
        new_seed = int(time.time()) % 10000
        obs, _ = self.env.reset(seed=new_seed)
        self._update_shared_state(obs, 0.0, False, False, {})
        self.log(f"New underwater seabed generated (Seed {new_seed})")

    def set_speed(self, multiplier: float):
        self.speed_multiplier = max(0.25, min(8.0, float(multiplier)))
        self.log(f"Speed multiplier set to {self.speed_multiplier:g}×")

    def run_loop(self):
        """Simulation loop running at targeted tick rate."""
        obs = self.env._build_observation()
        while not self.stop_requested:
            if self.running and not self.paused:
                substeps = max(1, int(round(self.speed_multiplier)))
                for _ in range(substeps):
                    # Select action via PPO or heuristic exploration
                    if self.policy is not None:
                        try:
                            action, _ = self.policy.predict(obs, deterministic=True)
                        except Exception:
                            action = self.env.action_space.sample()
                    else:
                        # Smooth exploration heuristic
                        action = np.array([0.8, np.sin(self.env.step_count * 0.1) * 0.4], dtype=np.float32)

                    obs, reward, terminated, truncated, info = self.env.step(action)
                    self._update_shared_state(obs, reward, terminated, truncated, info)

                    if terminated or truncated:
                        self.log(f"Episode {self.env.episode_count} completed. Reward: {self.env.total_reward:.1f}")
                        obs, _ = self.env.reset()
                        break

            time.sleep(0.08 / max(1.0, self.speed_multiplier))


def main():
    parser = argparse.ArgumentParser(description="Autonomous Underwater Robot - Seabed Classification & Exploration")
    parser.add_argument("--mode", type=str, default="mock", choices=["mock", "holoocean"],
                        help="Simulation mode: 'mock' (default) or 'holoocean'")
    parser.add_argument("--speed", type=float, default=1.0, help="Initial simulation speed multiplier")
    parser.add_argument("--train-cnn", action="store_true", help="Train CNN model on data/ folder and exit")
    parser.add_argument("--data-dir", type=str, default="data", help="Directory containing CNN training images")
    args = parser.parse_args()

    if args.train_cnn:
        print(f"[CNN TRAIN] Training MobileNetV3 classifier from '{args.data_dir}'...")
        train_cnn(data_dir=args.data_dir, output_path="seabed_cnn.pt")
        return

    # Start Simulation Runner
    runner = SimulationRunner(mode=args.mode, speed=args.speed)
    sim_thread = threading.Thread(target=runner.run_loop, daemon=True)
    sim_thread.start()

    # Launch PyQt Application
    app = QApplication(sys.argv)
    callbacks = {
        "start": runner.start,
        "pause": runner.pause,
        "reset": runner.reset,
        "new_env": runner.new_environment,
        "speed": runner.set_speed,
    }
    window = DashboardWindow(
        shared_state=runner.shared_state,
        state_lock=runner.state_lock,
        control_callbacks=callbacks
    )
    window.show()

    try:
        sys.exit(app.exec())
    finally:
        runner.stop_requested = True


if __name__ == "__main__":
    main()
