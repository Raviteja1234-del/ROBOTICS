# verify_dataset.py
"""Verify that the CNN dataset was extracted correctly.
- Checks that train/validation/test directories exist.
- Checks that each split contains class subfolders.
- Loads each split with torchvision.datasets.ImageFolder.
- Counts total images and per‑class distribution.
- Tries to open a sample image from each class to ensure it is readable.
- Prints a concise report.
"""

import pathlib
import sys
from collections import Counter

import torch
from torchvision import datasets
from PIL import Image

ROOT = pathlib.Path(__file__).parent
DATA_ROOT = ROOT / "cnn_dataset"

def check_split(split_name: str) -> bool:
    split_dir = DATA_ROOT / split_name
    if not split_dir.is_dir():
        print(f"[ERROR] Missing split directory: {split_dir}")
        return False
    try:
        dataset = datasets.ImageFolder(split_dir)
    except Exception as e:
        print(f"[ERROR] ImageFolder failed for {split_name}: {e}")
        return False
    if len(dataset) == 0:
        print(f"[ERROR] No images found in split '{split_name}'.")
        return False
    # per‑class counts
    class_counts = Counter([label for _, label in dataset.samples])
    class_names = dataset.classes
    print(f"--- {split_name.upper()} ---")
    print(f"Total images: {len(dataset)}")
    print(f"Classes ({len(class_names)}): {', '.join(class_names)}")
    for idx, name in enumerate(class_names):
        print(f"  {name}: {class_counts.get(idx, 0)}")
    # verify one image per class
    for class_idx, class_name in enumerate(class_names):
        for path, label in dataset.samples:
            if label == class_idx:
                try:
                    Image.open(path).verify()
                except Exception as e:
                    print(f"[ERROR] Corrupted image in class '{class_name}': {path} ({e})")
                    return False
                break
    return True

def main():
    all_ok = True
    for split in ["train", "validation", "test"]:
        all_ok = all_ok and check_split(split)
    if all_ok:
        print("\nAll splits verified successfully.")
        sys.exit(0)
    else:
        print("\nDataset verification failed.")
        sys.exit(1)

if __name__ == "__main__":
    main()
