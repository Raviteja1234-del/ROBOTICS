"""
Mock Seabed Environment: High-fidelity standalone simulation of AUV seabed exploration.
Runs with zero external dependencies (no GPU / Unreal Engine required).
"""

from __future__ import annotations
import math
import random
from typing import Tuple, Optional
import numpy as np
import cv2

from .seabed_env import SeabedEnv


class MockSeabedEnv(SeabedEnv):
    """
    Simulates AUV seabed dynamics, synthetic camera views, sonar raycasts, and bathymetry.
    """
    def __init__(self, grid_size: int = 100, max_steps: int = 2000, cnn_weights: Optional[str] = "seabed_cnn.pt", seed: int = 42):
        super().__init__(grid_size=grid_size, max_steps=max_steps, cnn_weights=cnn_weights)
        self.rng = np.random.default_rng(seed)
        self.heightmap = np.zeros((grid_size, grid_size), dtype=np.float32)
        self.obstacles = []
        self._generate_terrain(seed=seed)
        self.reset(seed=seed)

    def _generate_terrain(self, seed: int = 42) -> None:
        """Generates realistic seabed biomes (Rock, Sand, Coral Reef) and bathymetric depth."""
        np.random.seed(seed)
        n = self.grid_size
        
        # Perlin-like multi-scale terrain generation
        base = np.zeros((n, n), dtype=np.float32)
        for scale, weight in [(8, 0.5), (16, 0.3), (32, 0.2)]:
            grid_pts = np.random.randn(scale, scale)
            resized = cv2.resize(grid_pts, (n, n), interpolation=cv2.INTER_CUBIC)
            base += resized * weight

        # Normalize to [0, 1]
        base = (base - base.min()) / (base.max() - base.min() + 1e-6)
        self.heightmap = base * 15.0 + 5.0  # Seabed depth between 5m and 20m

        # Partition into biomes: 0=Rock (35%), 1=Sand (40%), 2=Coral (25%)
        self.ground_truth_map = np.zeros((n, n), dtype=np.int8)
        self.ground_truth_map[base < 0.35] = 0  # Rock
        self.ground_truth_map[(base >= 0.35) & (base < 0.75)] = 1  # Sand
        self.ground_truth_map[base >= 0.75] = 2  # Coral Reef

        # Generate underwater rock obstacles
        self.obstacles = []
        for _ in range(12):
            ox = np.random.uniform(5, n - 5)
            oy = np.random.uniform(5, n - 5)
            orad = np.random.uniform(2.5, 5.0)
            self.obstacles.append((ox, oy, orad))

    def reset(self, seed: Optional[int] = None, options: Optional[dict] = None) -> Tuple[np.ndarray, dict]:
        if seed is not None:
            self._generate_terrain(seed=seed)
        return super().reset(seed=seed, options=options)

    def _step_physics(self, thrust: float, yaw: float) -> Tuple[bool, float]:
        """Simulates hydrodynamic AUV drag, thrust acceleration, and yaw."""
        dt = 0.2
        # Yaw rotation
        self.heading = (self.heading + yaw * 0.12) % (2 * math.pi)

        # Speed acceleration with quadratic water drag
        target_speed = (thrust + 1.0) * 0.75  # 0 to 1.5 m/s
        self.speed += (target_speed - self.speed) * 0.25
        self.speed = max(0.0, min(2.5, float(self.speed)))

        # Position update
        dx = math.cos(self.heading) * self.speed * dt * 5.0
        dy = math.sin(self.heading) * self.speed * dt * 5.0
        self.pos[0] += dx
        self.pos[1] += dy

        # Battery drain
        self.battery = max(0.0, self.battery - (0.005 + abs(thrust) * 0.004 + self.speed * 0.002))

        # Depth tracking with slight undulation
        target_depth = 8.0 + math.sin(self.step_count * 0.05) * 3.5
        self.depth += (target_depth - self.depth) * 0.1

        # Check collision with boundary or obstacles
        collision = False
        if self.pos[0] < 2 or self.pos[0] > self.grid_size - 2 or self.pos[1] < 2 or self.pos[1] > self.grid_size - 2:
            collision = True
            self.pos[0] = np.clip(self.pos[0], 2, self.grid_size - 2)
            self.pos[1] = np.clip(self.pos[1], 2, self.grid_size - 2)

        # Check obstacles
        for ox, oy, orad in self.obstacles:
            dist = math.hypot(self.pos[0] - ox, self.pos[1] - oy)
            if dist < orad:
                collision = True
                push_angle = math.atan2(self.pos[1] - oy, self.pos[0] - ox)
                self.pos[0] = ox + math.cos(push_angle) * (orad + 0.2)
                self.pos[1] = oy + math.sin(push_angle) * (orad + 0.2)
                break

        return collision, 0.0

    def _compute_obstacle_distance(self) -> float:
        """Raycasts forward from AUV position along heading direction."""
        ray_x, ray_y = float(self.pos[0]), float(self.pos[1])
        cos_h, sin_h = math.cos(self.heading), math.sin(self.heading)
        max_range = 25.0
        step_len = 0.5
        dist = 0.0

        while dist < max_range:
            ray_x += cos_h * step_len
            ray_y += sin_h * step_len
            dist += step_len

            # Boundary hit
            if ray_x <= 0 or ray_x >= self.grid_size or ray_y <= 0 or ray_y >= self.grid_size:
                return float(dist)

            # Obstacle hit
            for ox, oy, orad in self.obstacles:
                if math.hypot(ray_x - ox, ray_y - oy) <= orad:
                    return float(dist)

        return float(max_range)

    def _read_camera_frame(self) -> np.ndarray:
        """Generates realistic synthetic downward camera view of current seabed patch."""
        cx = int(np.clip(self.pos[0], 0, self.grid_size - 1))
        cy = int(np.clip(self.pos[1], 0, self.grid_size - 1))
        biome = self.ground_truth_map[cy, cx]

        img = np.zeros((224, 224, 3), dtype=np.uint8)
        # Background water color (blue/green attenuation)
        base_water = np.array([20, 45, 15], dtype=np.uint8)

        if biome == 0:  # Rock
            # Dark gray/brown rock textures with crevices
            noise = np.random.randint(40, 110, (224, 224), dtype=np.uint8)
            img[:, :, 0] = np.clip(noise * 0.5 + 20, 0, 255)  # Blue
            img[:, :, 1] = np.clip(noise * 0.7 + 35, 0, 255)  # Green
            img[:, :, 2] = np.clip(noise * 0.8 + 45, 0, 255)  # Red
            # Add boulder contours
            for _ in range(5):
                rx, ry = np.random.randint(20, 200, 2)
                rr = np.random.randint(15, 45)
                cv2.circle(img, (rx, ry), rr, (30, 50, 60), -1)
                cv2.circle(img, (rx, ry), rr, (15, 30, 40), 2)

        elif biome == 1:  # Sand
            # Smooth golden sand ripples with caustics
            x = np.linspace(0, 4 * math.pi, 224)
            y = np.linspace(0, 4 * math.pi, 224)
            xv, yv = np.meshgrid(x, y)
            ripples = (np.sin(xv * 2.0 + yv * 0.5) * 20 + 175).astype(np.uint8)
            grain = np.random.randint(-15, 15, (224, 224))
            sand_b = np.clip(ripples * 0.4 + grain, 0, 255)
            sand_g = np.clip(ripples * 0.85 + grain, 0, 255)
            sand_r = np.clip(ripples * 0.95 + grain, 0, 255)
            img[:, :, 0] = sand_b
            img[:, :, 1] = sand_g
            img[:, :, 2] = sand_r

        else:  # Coral Reef
            # Vibrant corals: purple, pink, turquoise branching colonies
            img[:, :, 0] = 70   # Blue
            img[:, :, 1] = 40   # Green
            img[:, :, 2] = 110  # Red
            # Draw coral clusters
            colors = [(180, 50, 130), (50, 190, 180), (140, 40, 200), (220, 100, 80), (40, 210, 100)]
            for _ in range(14):
                cx_c, cy_c = np.random.randint(20, 200, 2)
                cr = np.random.randint(10, 30)
                col = random.choice(colors)
                cv2.circle(img, (cx_c, cy_c), cr, col, -1)
                cv2.circle(img, (cx_c + 3, cy_c - 3), cr // 2, (min(255, col[0] + 40), min(255, col[1] + 40), min(255, col[2] + 40)), -1)

        # Add camera headlight illumination circle in center
        center_x, center_y = 112, 112
        y_c, x_c = np.ogrid[:224, :224]
        dist_from_center = np.sqrt((x_c - center_x)**2 + (y_c - center_y)**2)
        vignette = np.clip(1.3 - (dist_from_center / 110.0), 0.4, 1.3)
        for ch in range(3):
            img[:, :, ch] = np.clip(img[:, :, ch] * vignette, 0, 255).astype(np.uint8)

        # Convert to RGB (standard format)
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        return img_rgb

    def _read_chase_frame(self) -> np.ndarray:
        """Generates realistic 3D chase camera view looking over the AUV."""
        chase = np.zeros((224, 224, 3), dtype=np.uint8)

        # Deep underwater blue-green gradient background
        for y in range(224):
            factor = y / 224.0
            r = int(5 + factor * 25)
            g = int(20 + factor * 70)
            b = int(45 + factor * 85)
            chase[y, :, 0] = r
            chase[y, :, 1] = g
            chase[y, :, 2] = b

        # Seabed floor perspective plane
        seabed_y = 145
        for y in range(seabed_y, 224):
            frac = (y - seabed_y) / (224 - seabed_y)
            chase[y, :, 0] = int(20 + frac * 60)
            chase[y, :, 1] = int(40 + frac * 85)
            chase[y, :, 2] = int(25 + frac * 45)

        # Draw 3D AUV Submarine in center
        auv_cx, auv_cy = 112, 110
        # Main torpedo body (Bright Yellow/Orange)
        cv2.ellipse(chase, (auv_cx, auv_cy), (46, 15), 0, 0, 360, (245, 175, 25), -1)
        cv2.ellipse(chase, (auv_cx, auv_cy), (46, 15), 0, 0, 360, (180, 110, 10), 2)
        # Rounded nose cone
        cv2.ellipse(chase, (auv_cx + 34, auv_cy), (14, 13), 0, -90, 90, (255, 195, 35), -1)
        # Front camera lens / blue sensor dome
        cv2.circle(chase, (auv_cx + 42, auv_cy), 5, (40, 210, 255), -1)
        cv2.circle(chase, (auv_cx + 42, auv_cy), 2, (255, 255, 255), -1)
        # Rear propulsion thruster (Dark Metallic)
        cv2.rectangle(chase, (auv_cx - 48, auv_cy - 7), (auv_cx - 38, auv_cy + 7), (65, 75, 85), -1)
        # Propeller blades
        prop_angle = (self.step_count * 45) % 360
        rad = math.radians(prop_angle)
        px1 = int(auv_cx - 50 + math.cos(rad) * 9)
        py1 = int(auv_cy + math.sin(rad) * 9)
        px2 = int(auv_cx - 50 - math.cos(rad) * 9)
        py2 = int(auv_cy - math.sin(rad) * 9)
        cv2.line(chase, (px1, py1), (px2, py2), (210, 220, 230), 3)
        # Stabilizer fins
        cv2.fillPoly(chase, [np.array([[auv_cx - 25, auv_cy - 12], [auv_cx - 10, auv_cy - 24], [auv_cx - 5, auv_cy - 12]])], (210, 140, 15))
        cv2.fillPoly(chase, [np.array([[auv_cx - 25, auv_cy + 12], [auv_cx - 10, auv_cy + 24], [auv_cx - 5, auv_cy + 12]])], (210, 140, 15))

        # Twin front headlights projecting light beams forward
        pts_beam1 = np.array([[auv_cx + 38, auv_cy - 6], [auv_cx + 105, auv_cy - 28], [auv_cx + 105, auv_cy + 10]])
        overlay = chase.copy()
        cv2.fillPoly(overlay, [pts_beam1], (180, 240, 255))
        cv2.addWeighted(overlay, 0.25, chase, 0.75, 0, chase)

        return chase
