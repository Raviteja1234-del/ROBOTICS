"""
Environment factory and exports for Autonomous Underwater Robot Seabed Exploration.
"""

from .seabed_env import SeabedEnv
from .mock_env import MockSeabedEnv
from .holoocean_env import HoloOceanSeabedEnv


def make_seabed_env(mode: str = "mock", **kwargs) -> SeabedEnv:
    """
    Factory function to instantiate Seabed exploration environment.
    Supported modes:
      - 'mock': High-fidelity synthetic simulator (no GPU/Unreal Engine required).
      - 'holoocean': Unreal Engine HoloOcean simulator.
    """
    mode = mode.lower().strip()
    if mode == "holoocean":
        return HoloOceanSeabedEnv(**kwargs)
    return MockSeabedEnv(**kwargs)


__all__ = ["SeabedEnv", "MockSeabedEnv", "HoloOceanSeabedEnv", "make_seabed_env"]
