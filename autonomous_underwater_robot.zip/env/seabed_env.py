"""
Base Gymnasium Environment for Autonomous Underwater Robot Seabed Exploration.
"""

from __future__ import annotations
import math
from abc import ABC, abstractmethod
from typing import Tuple, Dict, Any, Optional
import numpy as np
import gymnasium as gym
from gymnasium import spaces

from cnn import SeabedClassifier, CLASS_NAMES


class SeabedEnv(gym.Env, ABC):
    """
    Gymnasium base environment for AUV seabed exploration.
    
    Observation Space (69 continuous values):
      - Normalized X position [0, 1]
      - Normalized Y position [0, 1]
      - sin(heading) [-1, 1]
      - cos(heading) [-1, 1]
      - Normalized obstacle range [0, 1]
      - Coarse 8x8 downsampled view of the explored grid map (64 values, [0, 1])
      
    Action Space (2 continuous values):
      - [thrust, yaw] in [-1, 1]
    """
    metadata = {"render_modes": ["rgb_array"]}

    def __init__(self, grid_size: int = 100, max_steps: int = 2000, cnn_weights: Optional[str] = "seabed_cnn.pt"):
        super().__init__()
        self.grid_size = grid_size
        self.max_steps = max_steps

        # Action: [thrust, yaw]
        self.action_space = spaces.Box(
            low=np.array([-1.0, -1.0], dtype=np.float32),
            high=np.array([1.0, 1.0], dtype=np.float32),
            dtype=np.float32,
        )

        # Observation: 2 (pos) + 2 (heading) + 1 (obstacle) + 64 (8x8 map) = 69
        self.observation_space = spaces.Box(
            low=-np.inf,
            high=np.inf,
            shape=(69,),
            dtype=np.float32,
        )

        # CNN Classifier instance
        self.classifier = SeabedClassifier(weights_path=cnn_weights)

        # Robot State variables
        self.pos = np.array([self.grid_size * 0.15, self.grid_size * 0.15], dtype=np.float32)
        self.heading = 0.0  # radians
        self.depth = 11.5   # meters
        self.speed = 0.0    # m/s
        self.battery = 100.0  # percentage
        self.step_count = 0
        self.total_reward = 0.0
        self.collisions = 0
        self.episode_count = 0

        # Exploration Grid & Classification Maps
        # 0: Rock, 1: Sand, 2: Coral Reef, -1: Unexplored
        self.ground_truth_map = np.zeros((self.grid_size, self.grid_size), dtype=np.int8)
        self.explored_mask = np.zeros((self.grid_size, self.grid_size), dtype=bool)
        self.classified_map = np.full((self.grid_size, self.grid_size), -1, dtype=np.int8)
        self.path_history = []

        # Latest Telemetry & Visuals
        self.latest_camera_frame = np.zeros((224, 224, 3), dtype=np.uint8)
        self.latest_chase_frame = np.zeros((224, 224, 3), dtype=np.uint8)
        self.latest_cnn_prediction = {
            "class_id": 0,
            "class_name": "Rock",
            "confidence": 0.0,
            "probabilities": {"Rock": 0.33, "Sand": 0.33, "Coral Reef": 0.34}
        }
        self.latest_obstacle_distance = 20.0

    def _get_coarse_map(self) -> np.ndarray:
        """Downsamples the 100x100 explored mask to 8x8 coarse view."""
        coarse = np.zeros((8, 8), dtype=np.float32)
        step_x = self.grid_size / 8.0
        step_y = self.grid_size / 8.0
        for i in range(8):
            for j in range(8):
                y0, y1 = int(i * step_y), int((i + 1) * step_y)
                x0, x1 = int(j * step_x), int((j + 1) * step_x)
                coarse[i, j] = float(self.explored_mask[y0:y1, x0:x1].mean())
        return coarse.flatten()

    def _build_observation(self) -> np.ndarray:
        """Constructs the 69-dimensional observation vector."""
        norm_x = float(self.pos[0] / self.grid_size)
        norm_y = float(self.pos[1] / self.grid_size)
        sin_h = math.sin(self.heading)
        cos_h = math.cos(self.heading)
        norm_obs = min(1.0, float(self.latest_obstacle_distance / 30.0))
        coarse_map = self._get_coarse_map()

        obs = np.array([norm_x, norm_y, sin_h, cos_h, norm_obs, *coarse_map], dtype=np.float32)
        return obs

    @abstractmethod
    def _read_camera_frame(self) -> np.ndarray:
        """Fetch live camera frame from simulator or mock generator."""
        pass

    @abstractmethod
    def _read_chase_frame(self) -> np.ndarray:
        """Fetch 3D chase camera view."""
        pass

    @abstractmethod
    def _compute_obstacle_distance(self) -> float:
        """Fetch or calculate forward obstacle distance."""
        pass

    @abstractmethod
    def _step_physics(self, thrust: float, yaw: float) -> Tuple[bool, float]:
        """Advance robot physics. Returns (collision_flag, delta_depth)."""
        pass

    def step(self, action: np.ndarray) -> Tuple[np.ndarray, float, bool, bool, Dict[str, Any]]:
        """
        Executes one control step in the environment:
        1. Updates physics
        2. Acquires camera frame & executes CNN prediction
        3. Updates explored & classified grid map
        4. Calculates reward & termination
        """
        action = np.clip(np.asarray(action, dtype=np.float32), -1.0, 1.0)
        thrust, yaw = float(action[0]), float(action[1])

        # 1. Advance simulator physics
        collision, delta_depth = self._step_physics(thrust, yaw)
        self.latest_obstacle_distance = self._compute_obstacle_distance()
        self.path_history.append(self.pos.copy())
        if len(self.path_history) > 800:
            self.path_history.pop(0)

        # 2. Acquire camera frames and classify with CNN
        self.latest_camera_frame = self._read_camera_frame()
        self.latest_chase_frame = self._read_chase_frame()
        cid, cname, conf, probs = self.classifier.predict(self.latest_camera_frame)
        self.latest_cnn_prediction = {
            "class_id": cid,
            "class_name": cname,
            "confidence": conf,
            "probabilities": probs,
        }

        # 3. Update explored area and map classifications around robot footprint
        cx, cy = int(np.clip(self.pos[0], 0, self.grid_size - 1)), int(np.clip(self.pos[1], 0, self.grid_size - 1))
        radius = 3
        y0, y1 = max(0, cy - radius), min(self.grid_size, cy + radius + 1)
        x0, x1 = max(0, cx - radius), min(self.grid_size, cx + radius + 1)

        newly_explored = ~self.explored_mask[y0:y1, x0:x1]
        new_cells_count = int(newly_explored.sum())
        self.explored_mask[y0:y1, x0:x1] = True
        self.classified_map[y0:y1, x0:x1] = cid

        # 4. Reward computation
        reward = 0.0
        # Positive exploration bonus
        reward += new_cells_count * 0.15
        # Forward speed incentive
        reward += max(0.0, self.speed) * 0.02
        # Collision / boundary penalty
        if collision:
            reward -= 5.0
            self.collisions += 1
        # Small step penalty to encourage efficient exploration
        reward -= 0.01

        self.step_count += 1
        self.total_reward += reward

        # 5. Check Termination
        explored_pct = float(self.explored_mask.sum() / (self.grid_size * self.grid_size))
        terminated = bool(explored_pct >= 0.98 or self.battery <= 5.0)
        truncated = bool(self.step_count >= self.max_steps)

        obs = self._build_observation()
        info = {
            "new_cells": new_cells_count,
            "explored_pct": explored_pct * 100.0,
            "collision": collision,
            "step": self.step_count,
            "depth": self.depth,
            "obstacle_distance": self.latest_obstacle_distance,
        }

        return obs, float(reward), terminated, truncated, info

    def reset(self, seed: Optional[int] = None, options: Optional[dict] = None) -> Tuple[np.ndarray, Dict[str, Any]]:
        super().reset(seed=seed)
        self.episode_count += 1
        self.step_count = 0
        self.total_reward = 0.0
        self.collisions = 0
        self.battery = 100.0
        self.speed = 0.0
        self.heading = 0.0
        self.depth = 11.5

        self.pos = np.array([self.grid_size * 0.15, self.grid_size * 0.15], dtype=np.float32)
        self.explored_mask.fill(False)
        self.classified_map.fill(-1)
        self.path_history = [self.pos.copy()]

        self.latest_camera_frame = self._read_camera_frame()
        self.latest_chase_frame = self._read_chase_frame()
        self.latest_obstacle_distance = self._compute_obstacle_distance()

        return self._build_observation(), {}
