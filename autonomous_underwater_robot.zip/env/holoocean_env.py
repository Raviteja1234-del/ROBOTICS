"""
HoloOcean Seabed Environment: Real HoloOcean underwater simulator integration.
Uses TorpedoAUV agent in 'SimpleUnderwater' world.
"""

from __future__ import annotations
import math
from typing import Tuple, Optional
import numpy as np

from .seabed_env import SeabedEnv
from .mock_env import MockSeabedEnv


class HoloOceanSeabedEnv(SeabedEnv):
    """
    HoloOcean Simulator environment wrapper for AUV exploration.
    Requires holoocean Python package and Unreal Engine 'Ocean' binary package.
    """
    def __init__(self, scenario_name: str = "SimpleUnderwater-TorpedoAUV", grid_size: int = 100, max_steps: int = 2000, cnn_weights: Optional[str] = "seabed_cnn.pt"):
        super().__init__(grid_size=grid_size, max_steps=max_steps, cnn_weights=cnn_weights)
        self.scenario_name = scenario_name
        self.holoocean_env = None
        self._fallback_env: Optional[MockSeabedEnv] = None

        try:
            import holoocean
            # Configuration definition for HoloOcean TorpedoAUV exploration scenario
            # VERIFY: World name "SimpleUnderwater" and agent name "auv0" with camera sensors
            scenario_config = {
                "name": "SeabedExploration",
                "world": "SimpleUnderwater", # VERIFY: Ocean world name
                "main_agent": "auv0",
                "agents": [
                    {
                        "agent_name": "auv0",
                        "agent_type": "TorpedoAUV", # VERIFY: HoloOcean TorpedoAUV agent type
                        "sensors": [
                            {
                                "sensor_type": "RGBCamera", # VERIFY: Downward seabed camera sensor
                                "socket": "CameraSocket",
                                "configuration": {"CaptureWidth": 224, "CaptureHeight": 224}
                            },
                            {
                                "sensor_type": "PoseSensor", # VERIFY: Location & orientation sensor
                            },
                            {
                                "sensor_type": "RangeFinderSensor", # VERIFY: Forward sonar obstacle distance
                            }
                        ],
                        "control_scheme": 0 # VERIFY: Control scheme 0 (thruster & fin commands)
                    }
                ]
            }
            self.holoocean_env = holoocean.make(scenario_cfg=scenario_config)
            print(f"[HoloOcean] Connected to HoloOcean simulator ({scenario_name})")
        except Exception as e:
            print(f"[HoloOcean WARNING] Could not initialize HoloOcean simulator: {e}")
            print("[HoloOcean INFO] Automatically falling back to high-fidelity Mock simulation.")
            self._fallback_env = MockSeabedEnv(grid_size=grid_size, max_steps=max_steps, cnn_weights=cnn_weights)

    def reset(self, seed: Optional[int] = None, options: Optional[dict] = None) -> Tuple[np.ndarray, dict]:
        if self._fallback_env is not None:
            obs, info = self._fallback_env.reset(seed=seed, options=options)
            self._sync_from_fallback()
            return obs, info

        if self.holoocean_env is not None:
            state = self.holoocean_env.reset()
            # VERIFY: HoloOcean state dictionary sensor keys
            self.step_count = 0
            self.total_reward = 0.0
            self.collisions = 0
            self.battery = 100.0
            self.speed = 0.0
            self.heading = 0.0
            self.depth = 11.5
            self.pos = np.array([self.grid_size * 0.15, self.grid_size * 0.15], dtype=np.float32)
            self.explored_mask.fill(False)
            self.classified_map.fill(-1)
            self.path_history = [self.pos.copy()]
            return self._build_observation(), {}

        return super().reset(seed=seed, options=options)

    def _sync_from_fallback(self) -> None:
        """Syncs internal state fields from mock fallback instance."""
        if self._fallback_env is not None:
            self.pos = self._fallback_env.pos
            self.heading = self._fallback_env.heading
            self.depth = self._fallback_env.depth
            self.speed = self._fallback_env.speed
            self.battery = self._fallback_env.battery
            self.step_count = self._fallback_env.step_count
            self.total_reward = self._fallback_env.total_reward
            self.collisions = self._fallback_env.collisions
            self.ground_truth_map = self._fallback_env.ground_truth_map
            self.explored_mask = self._fallback_env.explored_mask
            self.classified_map = self._fallback_env.classified_map
            self.path_history = self._fallback_env.path_history
            self.latest_camera_frame = self._fallback_env.latest_camera_frame
            self.latest_chase_frame = self._fallback_env.latest_chase_frame
            self.latest_cnn_prediction = self._fallback_env.latest_cnn_prediction
            self.latest_obstacle_distance = self._fallback_env.latest_obstacle_distance

    def _step_physics(self, thrust: float, yaw: float) -> Tuple[bool, float]:
        if self._fallback_env is not None:
            return self._fallback_env._step_physics(thrust, yaw)

        if self.holoocean_env is not None:
            # VERIFY: Control action mapping for TorpedoAUV [thruster, fins...]
            action_vec = np.array([thrust * 50.0, yaw * 0.5, 0.0, 0.0], dtype=np.float32)
            state = self.holoocean_env.step(action_vec)
            # Update position & heading from PoseSensor
            # VERIFY: Sensor key 'PoseSensor' returns 4x4 matrix or [x, y, z, roll, pitch, yaw]
            pose = state.get("PoseSensor", np.eye(4))
            self.pos[0] = float(pose[0, 3] + self.grid_size * 0.5)
            self.pos[1] = float(pose[1, 3] + self.grid_size * 0.5)
            self.depth = float(-pose[2, 3])
            return False, 0.0

        return False, 0.0

    def _read_camera_frame(self) -> np.ndarray:
        if self._fallback_env is not None:
            return self._fallback_env._read_camera_frame()
        if self.holoocean_env is not None:
            # VERIFY: Sensor key 'RGBCamera' returns [H, W, 4] BGRA or [H, W, 3] RGB
            raw = self.holoocean_env.get_sensor("RGBCamera")
            if raw is not None:
                if raw.shape[-1] == 4:
                    raw = raw[:, :, :3]
                return raw.astype(np.uint8)
        return np.zeros((224, 224, 3), dtype=np.uint8)

    def _read_chase_frame(self) -> np.ndarray:
        if self._fallback_env is not None:
            return self._fallback_env._read_chase_frame()
        return self._read_camera_frame()

    def _compute_obstacle_distance(self) -> float:
        if self._fallback_env is not None:
            return self._fallback_env._compute_obstacle_distance()
        if self.holoocean_env is not None:
            # VERIFY: RangeFinderSensor returns scalar or array of distances in meters
            sonar = self.holoocean_env.get_sensor("RangeFinderSensor")
            if sonar is not None:
                return float(np.min(sonar))
        return 20.0
