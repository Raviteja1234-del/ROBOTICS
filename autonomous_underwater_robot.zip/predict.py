# predict.py
"""Run inference on a single image using the trained CNN.
Usage:
    python predict.py <image_path>
The script loads the best model saved by `train_cnn.py`, applies the same evaluation
transforms as used during validation/testing, and prints the predicted class name
and confidence.
"""

import pathlib
import sys

import torch
from torchvision import transforms
from PIL import Image

# ---------------------------------------------------------------------------
# Configuration – must match train_cnn.py
ROOT = pathlib.Path(__file__).parent
MODELS_DIR = ROOT / "models"
MODEL_PATH = MODELS_DIR / "best_model.pth"
TRAIN_DIR = ROOT / "cnn_dataset" / "train"
BATCH_SIZE = 1
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# ---------------------------------------------------------------------------

def load_model():
    # Load class names from the training ImageFolder
    from torchvision import datasets
    dummy_dataset = datasets.ImageFolder(TRAIN_DIR)
    class_names = dummy_dataset.classes

    # Load a ResNet18 backbone (same architecture as training)
    from torchvision import models
    model = models.resnet18(pretrained=False)
    model.fc = torch.nn.Linear(model.fc.in_features, len(class_names))
    ckpt = torch.load(MODEL_PATH, map_location=DEVICE)
    if isinstance(ckpt, dict):
        ckpt = {k: v.float() if torch.is_tensor(v) and v.is_floating_point() else v for k, v in ckpt.items()}
    model.load_state_dict(ckpt)
    model = model.to(DEVICE)
    model.eval()
    return model, class_names

def get_transform():
    return transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225]),
    ])

def predict(image_path: pathlib.Path):
    if not image_path.is_file():
        print(f"Image not found: {image_path}")
        sys.exit(1)
    model, class_names = load_model()
    transform = get_transform()
    image = Image.open(image_path).convert("RGB")
    input_tensor = transform(image).unsqueeze(0).to(DEVICE)
    with torch.no_grad():
        outputs = model(input_tensor)
        probs = torch.nn.functional.softmax(outputs[0], dim=0)
        conf, idx = torch.max(probs, dim=0)
    pred_class = class_names[idx.item()]
    print(f"Predicted class: {pred_class} (confidence {conf.item():.4f})")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python predict.py <image_path>")
        sys.exit(1)
    img_path = pathlib.Path(sys.argv[1])
    predict(img_path)
