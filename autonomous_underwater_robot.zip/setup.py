from setuptools import setup, find_packages; setup(name="auv_robot", packages=find_packages())
