import pathlib
import sys
import pyarrow.parquet as pq

def inspect_parquet(file_path: pathlib.Path):
    if not file_path.exists():
        print(f"Parquet file not found: {file_path}")
        sys.exit(1)
    table = pq.read_table(file_path)
    print(f"Rows: {table.num_rows}")
    print(f"Columns: {list(table.column_names)}")
    if table.num_rows == 0:
        print("Empty parquet file")
        return
    # Inspect first row
    row = table.slice(0, 1).to_pydict()
    image = row['image'][0]
    label = row['label'][0]
    print("--- First row ---")
    # Image dict
    print(f"Image dict type: {type(image)}")
    if isinstance(image, dict):
        print(f"Image dict keys: {list(image.keys())}")
        if 'bytes' in image:
            print(f"Image bytes length: {len(image['bytes'])}")
        if 'path' in image:
            print(f"Image path: {image['path']}")
    # Label dict
    print(f"Label dict type: {type(label)}")
    if isinstance(label, dict):
        print(f"Label dict keys: {list(label.keys())}")
        for k, v in label.items():
            if isinstance(v, (bytes, bytearray)):
                print(f"Label key '{k}': <{type(v).__name__} of length {len(v)}>")
            else:
                print(f"Label key '{k}': {v}")
    else:
        print(f"Label value: {label}")

if __name__ == "__main__":
    # Adjust path as needed
    test_path = pathlib.Path(__file__).parent / "coralscapes" / "data" / "test-00000-of-00003.parquet"
    inspect_parquet(test_path)