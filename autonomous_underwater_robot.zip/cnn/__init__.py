"""
CNN package exports for seabed terrain classification.
"""

from __future__ import annotations
import os
import sys
from pathlib import Path
from typing import Tuple, Dict, Optional, Union
import numpy as np
import torch
import torch.nn as nn
from torchvision import models, transforms
from PIL import Image

CLASS_NAMES = ["Rock", "Sand", "Coral Reef"]
NUM_CLASSES = len(CLASS_NAMES)


def get_transforms(train: bool = False) -> transforms.Compose:
    """Standard ImageNet preprocessing pipeline."""
    if train:
        return transforms.Compose([
            transforms.RandomResizedCrop(224, scale=(0.8, 1.0)),
            transforms.RandomHorizontalFlip(),
            transforms.RandomRotation(15),
            transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225]),
        ])
    return transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225]),
    ])


def build_mobilenet(num_classes: int = NUM_CLASSES, pretrained: bool = True) -> nn.Module:
    """Build a MobileNetV3-Small classifier."""
    weights = models.MobileNet_V3_Small_Weights.DEFAULT if pretrained else None
    model = models.mobilenet_v3_small(weights=weights)
    in_features = model.classifier[3].in_features
    model.classifier[3] = nn.Linear(in_features, num_classes)
    return model


class SeabedClassifier:
    """
    Inference and heuristic fallback engine for seabed terrain classification.
    """
    def __init__(self, weights_path: Optional[Union[str, Path]] = "seabed_cnn.pt", device: Optional[str] = None):
        self.device = torch.device(device if device else ("cuda" if torch.cuda.is_available() else "cpu"))
        self.weights_path = Path(weights_path) if weights_path else None
        self.model: Optional[nn.Module] = None
        self.transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225]),
        ])
        self.has_weights = False
        self._load_model()

    def _load_model(self) -> None:
        """Load weights if present; otherwise fall back to heuristic."""
        if self.weights_path and self.weights_path.exists():
            try:
                self.model = build_mobilenet(num_classes=NUM_CLASSES, pretrained=False)
                checkpoint = torch.load(str(self.weights_path), map_location=self.device)
                if isinstance(checkpoint, dict) and "state_dict" in checkpoint:
                    self.model.load_state_dict(checkpoint["state_dict"])
                elif isinstance(checkpoint, dict) and "model_state_dict" in checkpoint:
                    self.model.load_state_dict(checkpoint["model_state_dict"])
                else:
                    self.model.load_state_dict(checkpoint)
                self.model.to(self.device)
                self.model.eval()
                self.has_weights = True
                print(f"[CNN] Loaded seabed weights from: {self.weights_path}")
            except Exception as e:
                print(f"[CNN WARNING] Failed loading {self.weights_path}: {e}. Using heuristic mode.")
                self.has_weights = False
                self.model = None
        else:
            print(f"[CNN INFO] No weights found at '{self.weights_path}'. Using color/texture heuristic classifier.")
            self.has_weights = False
            self.model = None

    def predict(self, image: Union[np.ndarray, Image.Image]) -> Tuple[int, str, float, Dict[str, float]]:
        """
        Classifies an RGB image (numpy uint8 [H, W, 3] or PIL Image).
        Returns:
            class_id: int (0=Rock, 1=Sand, 2=Coral Reef)
            class_name: str
            confidence: float
            probabilities: dict of {class_name: prob}
        """
        if isinstance(image, np.ndarray):
            if image.ndim == 2:
                image = np.stack([image] * 3, axis=-1)
            elif image.shape[2] == 4:
                image = image[:, :, :3]
            pil_img = Image.fromarray(image.astype(np.uint8))
        else:
            pil_img = image.convert("RGB")

        if self.has_weights and self.model is not None:
            tensor = self.transform(pil_img).unsqueeze(0).to(self.device)
            with torch.no_grad():
                logits = self.model(tensor)
                probs = torch.softmax(logits, dim=1).cpu().numpy()[0]
            class_id = int(np.argmax(probs))
            conf = float(probs[class_id])
            probs_dict = {CLASS_NAMES[i]: float(probs[i]) for i in range(NUM_CLASSES)}
            return class_id, CLASS_NAMES[class_id], conf, probs_dict

        # Heuristic classification based on RGB spectrum & variance
        return self._heuristic_predict(pil_img)

    def _heuristic_predict(self, pil_img: Image.Image) -> Tuple[int, str, float, Dict[str, float]]:
        """
        Color/texture heuristic fallback:
        - Coral: High red/violet / colorful variance.
        - Sand: High yellow / light golden / high brightness, low variance.
        - Rock: Dark grey / brownish / low green-blue dominance.
        """
        arr = np.array(pil_img.resize((64, 64)), dtype=np.float32)
        r, g, b = arr[:, :, 0], arr[:, :, 1], arr[:, :, 2]
        
        r_mean, g_mean, b_mean = float(r.mean()), float(g.mean()), float(b.mean())
        r_std = float(r.std())
        brightness = (r_mean + g_mean + b_mean) / 3.0

        # Score calculations
        sand_score = max(0.1, (r_mean * 0.4 + g_mean * 0.4 + brightness * 0.2) / 255.0 - (r_std / 150.0))
        coral_score = max(0.1, (r_mean * 0.5 + b_mean * 0.5 + r_std * 0.6) / 255.0)
        rock_score = max(0.1, (255.0 - brightness) / 255.0 + (abs(r_mean - g_mean) + abs(g_mean - b_mean)) / 100.0)

        total = sand_score + coral_score + rock_score
        p_rock = rock_score / total
        p_sand = sand_score / total
        p_coral = coral_score / total

        probs = {
            "Rock": round(float(p_rock), 3),
            "Sand": round(float(p_sand), 3),
            "Coral Reef": round(float(p_coral), 3),
        }
        class_id = int(np.argmax([p_rock, p_sand, p_coral]))
        conf = float([p_rock, p_sand, p_coral][class_id])
        return class_id, CLASS_NAMES[class_id], conf, probs


def train_cnn(data_dir: str = "data", output_path: str = "seabed_cnn.pt", epochs: int = 10, batch_size: int = 16, lr: float = 1e-3) -> None:
    """Train MobileNetV3-Small from dataset directory."""
    from torch.utils.data import DataLoader, Dataset
    from pathlib import Path

    class FolderDataset(Dataset):
        def __init__(self, root: str, transform=None):
            self.transform = transform
            self.samples = []
            class_map = {"0_rock": 0, "1_sand": 1, "2_coral": 2, "rock": 0, "sand": 1, "coral": 2}
            for folder_name, label in class_map.items():
                p = Path(root) / folder_name
                if p.exists():
                    for f in p.glob("*.*"):
                        if f.suffix.lower() in [".jpg", ".jpeg", ".png", ".bmp"]:
                            self.samples.append((str(f), label))

        def __len__(self):
            return len(self.samples)

        def __getitem__(self, idx):
            path, label = self.samples[idx]
            img = Image.open(path).convert("RGB")
            if self.transform:
                img = self.transform(img)
            return img, label

    dataset = FolderDataset(data_dir, transform=get_transforms(train=True))
    if len(dataset) == 0:
        print(f"[CNN TRAIN ERROR] No images found in {data_dir}/0_rock, 1_sand, 2_coral.")
        return

    loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = build_mobilenet(num_classes=NUM_CLASSES, pretrained=True).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)

    print(f"[CNN TRAIN] Starting training on {len(dataset)} images for {epochs} epochs on {device}...")
    for epoch in range(epochs):
        model.train()
        total_loss, correct, total = 0.0, 0, 0
        for images, labels in loader:
            images, labels = images.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            total_loss += loss.item() * len(labels)
            preds = outputs.argmax(dim=1)
            correct += (preds == labels).sum().item()
            total += len(labels)

        acc = correct / total if total > 0 else 0
        print(f"Epoch {epoch+1:02d}/{epochs:02d} - Loss: {total_loss/total:.4f} - Acc: {acc*100:.2f}%")

    torch.save({"model_state_dict": model.state_dict(), "classes": CLASS_NAMES}, output_path)
    print(f"[CNN TRAIN COMPLETE] Saved model weights to: {output_path}")


__all__ = ["SeabedClassifier", "CLASS_NAMES", "NUM_CLASSES", "build_mobilenet", "train_cnn", "get_transforms"]
