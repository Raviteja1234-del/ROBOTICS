# Autonomous Underwater Robot – Seabed Classification & Exploration

An end-to-end Python desktop application where an Autonomous Underwater Vehicle (AUV) explores a simulated seabed, classifies bottom terrain types (**Rock / Sand / Coral Reef**) with a real-time CNN (**MobileNetV3-Small**), learns optimal exploration behaviors using **Reinforcement Learning (PPO)**, and displays all telemetry live on a dark-themed **PyQt6 + PyQtGraph** desktop mission control dashboard.

---

## Architecture Overview

```
├── main.py                     # Application entry point, CLI arguments, background PPO thread
├── cnn.py                      # MobileNetV3-Small seabed classifier & heuristic fallback
├── dashboard.py                # PyQt6 + PyQtGraph mission control window
├── env/
│   ├── __init__.py             # make_seabed_env() factory
│   ├── seabed_env.py           # Gymnasium base environment (69 observations, [thrust, yaw] actions)
│   ├── mock_env.py             # High-fidelity synthetic seabed & bathymetry simulator (zero GPU/UE needed)
│   └── holoocean_env.py        # Unreal Engine HoloOcean simulator integration (TorpedoAUV agent)
├── requirements.txt            # Pinned dependencies
└── README.md                   # System documentation
```

---

## Features

1. **Dual Execution Modes**:
   - `--mode mock` *(Default)*: Lightweight standalone simulator generating synthetic bathymetry, 2D terrain biomes, underwater camera feeds, and sonar raycasts with no external engine required.
   - `--mode holoocean`: Real HoloOcean Unreal Engine simulator using the `TorpedoAUV` agent in the `SimpleUnderwater` ocean world.
2. **CNN Seabed Classifier**:
   - PyTorch `MobileNetV3-Small` classifying camera frames into **Rock (0)**, **Sand (1)**, and **Coral Reef (2)**.
   - Automatic color & texture heuristic fallback when weights file `seabed_cnn.pt` is not present.
   - Built-in training pipeline (`python main.py --train-cnn --data-dir data`).
3. **PPO Exploration Agent**:
   - Gymnasium continuous action space `[thrust, yaw] \in [-1, 1]^2`.
   - Observation space (69 continuous values): normalized position $(x, y)$, heading $(\sin, \cos)$, obstacle range, and coarse $8\times 8$ (64-cell) exploration state.
   - Stable-Baselines3 background training loop updating shared state every 100ms with thread-safe locking.
4. **PyQt6 Mission Control Dashboard**:
   - **Robot View**: Live downward camera feed.
   - **CNN Classification**: 3 color-coded probability bars (Rock `#ad6428`, Sand `#d4ad1b`, Coral Reef `#8135bd`) and predicted label badge.
   - **Robot Status**: Depth ($m$), Speed ($m/s$), Battery (%), Heading (°), Mode, Algorithm (PPO), Episode, Step.
   - **3D Environment View**: Chase-camera view showing AUV submarine, propeller animation, water lighting, and interactive controls (`START`, `PAUSE`, `RESET`, `NEW RANDOM ENVIRONMENT`, and `1× / 2× / 4× / 8×` speed multipliers).
   - **Seabed Classification Map (Top View)**: Real-time top-down 2D grid colored by classified biome with robot exploration trajectory overlay.
   - **RL Training (Live Plot)**: Auto-scaling live reward curve.
   - **Sensor Data**: Live Depth ($m$) plot and Distance to Obstacle ($m$) plot with dynamic Y-axis scaling.
   - **Exploration Summary**: Categorical percentages and interactive Donut Chart.
   - **System Log**: Timestamped status stream.

---

## Installation

### Prerequisites
- Python 3.10 or higher

### Install Dependencies
```bash
pip install -r requirements.txt
```

---

## Running the Application

### 1. Mock Simulator Mode (Recommended / Default)
Runs the desktop dashboard and simulation locally on CPU with zero external dependencies:
```bash
python main.py --mode mock
```

### 2. HoloOcean Mode
Runs with the HoloOcean Unreal Engine simulator:
```bash
# Ensure HoloOcean is installed (pip install holoocean)
python main.py --mode holoocean
```
*(If HoloOcean or Unreal Engine binaries are not found, the system automatically logs a warning and falls back to Mock mode).*

### 3. Adjusting Simulation Speed
Launch at customized initial speed multipliers:
```bash
python main.py --mode mock --speed 2.0
```

---

## Training the CNN Classifier

### Dataset Folder Structure
Organize your dataset into:
```
data/
  0_rock/
    img1.jpg, img2.png ...
  1_sand/
    img1.jpg, img2.png ...
  2_coral/
    img1.jpg, img2.png ...
```

### Run CNN Training
```bash
python main.py --train-cnn --data-dir data
```
This trains MobileNetV3-Small for 10 epochs and saves `seabed_cnn.pt` in the working directory.

---

## Known Limitations
1. In HoloOcean mode, Unreal Engine GPU rendering requires a dedicated GPU and the `Ocean` world asset package installed.
2. In mock mode, water lighting and terrain noise are procedurally generated via NumPy and OpenCV.
