"""
Headless / snapshot verification script for the Dashboard.
Runs the simulation runner, updates the dashboard for 25 frames, captures a window screenshot and saves to disk.
"""

import sys
import time
import threading

try:
    from PyQt6.QtWidgets import QApplication
    from PyQt6.QtCore import QTimer
    from PyQt6.QtGui import QPixmap
except Exception:
    from PyQt5.QtWidgets import QApplication
    from PyQt5.QtCore import QTimer
    from PyQt5.QtGui import QPixmap

from env import make_seabed_env
from main import SimulationRunner
from dashboard import DashboardWindow


def run_test():
    app = QApplication(sys.argv)
    runner = SimulationRunner(mode="mock", speed=2.0)
    sim_thread = threading.Thread(target=runner.run_loop, daemon=True)
    sim_thread.start()

    callbacks = {
        "start": runner.start,
        "pause": runner.pause,
        "reset": runner.reset,
        "new_env": runner.new_environment,
        "speed": runner.set_speed,
    }
    window = DashboardWindow(
        shared_state=runner.shared_state,
        state_lock=runner.state_lock,
        control_callbacks=callbacks
    )
    window.show()

    frames_count = 0
    def on_tick():
        nonlocal frames_count
        frames_count += 1
        if frames_count >= 25:
            # Capture screenshot
            pixmap = window.grab()
            pixmap.save("dashboard_snapshot.png")
            print("[TEST] Successfully captured dashboard snapshot to 'dashboard_snapshot.png'")
            runner.stop_requested = True
            app.quit()

    timer = QTimer()
    timer.timeout.connect(on_tick)
    timer.start(80)

    app.exec()


if __name__ == "__main__":
    run_test()
