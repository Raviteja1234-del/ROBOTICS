# train_cnn.py
"""Train a simple CNN on the extracted CoralScapes dataset.
Uses PyTorch, torchvision transforms, and ImageFolder dataset.
The script automatically detects classes from cnn_dataset/train and validates the
folder structure. It saves the best model (by validation accuracy) to
`best_model.pth` and prints training/validation metrics.
"""

import json
import pathlib
import sys
from collections import defaultdict

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, models, transforms

# ---------------------------------------------------------------------------
# Configuration
ROOT = pathlib.Path(__file__).parent
MODELS_DIR = ROOT / "models"
DATA_ROOT = ROOT / "cnn_dataset"
TRAIN_DIR = DATA_ROOT / "train"
VAL_DIR = DATA_ROOT / "validation"
TEST_DIR = DATA_ROOT / "test"
BATCH_SIZE = 32
NUM_EPOCHS = 5
LEARNING_RATE = 1e-3
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# ---------------------------------------------------------------------------

def get_dataloaders() -> dict:
    """Create train/val/test DataLoaders using ImageFolder."""
    # Standard ImageNet‑style transforms
    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(224),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225]),
    ])
    eval_transform = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225]),
    ])

    image_datasets = {
        "train": datasets.ImageFolder(TRAIN_DIR, transform=train_transform),
        "val": datasets.ImageFolder(VAL_DIR, transform=eval_transform),
        "test": datasets.ImageFolder(TEST_DIR, transform=eval_transform),
    }
    dataloaders = {x: DataLoader(image_datasets[x], batch_size=BATCH_SIZE,
                                 shuffle=(x == "train"), num_workers=4)
                   for x in ["train", "val", "test"]}
    return dataloaders, image_datasets["train"].classes

def train_model(model, dataloaders, criterion, optimizer, num_epochs=NUM_EPOCHS):
    best_acc = 0.0
    best_model_wts = model.state_dict()
    history = defaultdict(list)

    for epoch in range(num_epochs):
        print(f"Epoch {epoch+1}/{num_epochs}")
        print("-" * 20)
        # Each epoch has a training and validation phase
        for phase in ["train", "val"]:
            if phase == "train":
                model.train()
            else:
                model.eval()

            running_loss = 0.0
            running_corrects = 0
            total = 0

            for inputs, labels in dataloaders[phase]:
                inputs = inputs.to(DEVICE)
                labels = labels.to(DEVICE)

                optimizer.zero_grad()
                with torch.set_grad_enabled(phase == "train"):
                    outputs = model(inputs)
                    _, preds = torch.max(outputs, 1)
                    loss = criterion(outputs, labels)
                    if phase == "train":
                        loss.backward()
                        optimizer.step()
                running_loss += loss.item() * inputs.size(0)
                running_corrects += torch.sum(preds == labels.data).item()
                total += inputs.size(0)

            epoch_loss = running_loss / total
            epoch_acc = running_corrects / total
            history[phase + "_loss"].append(epoch_loss)
            history[phase + "_acc"].append(epoch_acc)
            print(f"{phase.capitalize()} Loss: {epoch_loss:.4f} Acc: {epoch_acc:.4f}")

            # deep copy the model
            if phase == "val" and epoch_acc > best_acc:
                best_acc = epoch_acc
                best_model_wts = model.state_dict()
        print()
    model.load_state_dict(best_model_wts)
    return model, history, best_acc

def main():
    dataloaders, class_names = get_dataloaders()
    num_classes = len(class_names)
    print(f"Found {num_classes} classes: {class_names}")

    # Use a pretrained ResNet18 backbone and replace the final FC layer
    model = models.resnet18(pretrained=True)
    model.fc = nn.Linear(model.fc.in_features, num_classes)
    model = model.to(DEVICE)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)

    model, history, best_val_acc = train_model(model, dataloaders, criterion, optimizer)
    # Save best model
    torch.save(model.state_dict(), MODELS_DIR / "best_model.pth")
    print(f"Best validation accuracy: {best_val_acc:.4f}")
    # Optional: evaluate on test set
    model.eval()
    test_loader = dataloaders["test"]
    correct = 0
    total = 0
    with torch.no_grad():
        for inputs, labels in test_loader:
            inputs = inputs.to(DEVICE)
            labels = labels.to(DEVICE)
            outputs = model(inputs)
            _, preds = torch.max(outputs, 1)
            correct += (preds == labels).sum().item()
            total += inputs.size(0)
    print(f"Test accuracy: {correct/total:.4f}")

if __name__ == "__main__":
    main()
