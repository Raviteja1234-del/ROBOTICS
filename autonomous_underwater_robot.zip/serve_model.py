import io
import pathlib
import torch
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import JSONResponse
from torchvision import models, transforms, datasets
from PIL import Image

app = FastAPI()

# ---------------------------------------------------------------------------
# Configuration (same as training script)
# ---------------------------------------------------------------------------
ROOT = pathlib.Path(__file__).parent
MODELS_DIR = ROOT / "models"
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
BATCH_SIZE = 1  # inference uses batch size 1

# Load class names from the training ImageFolder (ensures correct order)
TRAIN_DIR = ROOT / "cnn_dataset" / "train"
_dummy_dataset = datasets.ImageFolder(TRAIN_DIR)
CLASS_NAMES = _dummy_dataset.classes

# Build the model architecture and load weights
model = models.resnet18()
model.fc = torch.nn.Linear(model.fc.in_features, len(CLASS_NAMES))
model_path = MODELS_DIR / "best_model.pth"
ckpt = torch.load(model_path, map_location=DEVICE)
if isinstance(ckpt, dict):
    ckpt = {k: v.float() if torch.is_tensor(v) and v.is_floating_point() else v for k, v in ckpt.items()}
model.load_state_dict(ckpt)
model.to(DEVICE)
model.eval()

# ---------------------------------------------------------------------------
# Pre‑processing pipeline (identical to training/evaluation)
# ---------------------------------------------------------------------------
transform = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
])

def _predict_image(image_bytes: bytes) -> dict:
    """Run a single forward pass and return class name + confidence."""
    try:
        image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    except Exception as exc:
        raise HTTPException(status_code=400, detail="Invalid image file") from exc
    input_tensor = transform(image).unsqueeze(0).to(DEVICE)
    with torch.no_grad():
        logits = model(input_tensor)
        probs = torch.nn.functional.softmax(logits, dim=1)
        top_idx = torch.argmax(probs, dim=1).item()
        confidence = probs[0, top_idx].item()
    return {
        "class": CLASS_NAMES[top_idx],
        "confidence": round(confidence, 4),
        "all_probabilities": {cls: round(p.item(), 4) for cls, p in zip(CLASS_NAMES, probs.squeeze())},
    }

@app.post("/predict")
async def predict(file: UploadFile = File(...)) -> JSONResponse:
    """Accept an image file and return the predicted seabed class."""
    if file.content_type not in {"image/jpeg", "image/png", "image/jpg"}:
        raise HTTPException(status_code=415, detail="Unsupported media type")
    content = await file.read()
    result = _predict_image(content)
    return JSONResponse(content=result)

# ---------------------------------------------------------------------------
# Optional health‑check endpoint
# ---------------------------------------------------------------------------
@app.get("/health")
async def health() -> dict:
    return {"status": "ok", "device": str(DEVICE)}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
