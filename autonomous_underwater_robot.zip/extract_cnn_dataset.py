import argparse
import json
import pathlib
import sys
from collections import defaultdict
from typing import Dict, List, Optional

import numpy as np
import pyarrow.parquet as pq
from PIL import Image
import io

# ---------------------------------------------------------------------------
# Configuration (default values – can be overridden via CLI)
# ---------------------------------------------------------------------------
ROOT = pathlib.Path(__file__).parent
DATA_ROOT = ROOT / "coralscapes" / "data"
OUTPUT_ROOT = ROOT / "cnn_dataset"
ID2LABEL_PATH = ROOT / "coralscapes" / "id2label.json"

def load_id2label() -> Dict[int, str]:
    """Load id2label mapping, ensuring integer keys."""
    with open(ID2LABEL_PATH, "r", encoding="utf-8") as f:
        raw = json.load(f)
    return {int(k): v for k, v in raw.items()}

def most_common_label(mask: np.ndarray) -> int:
    """Return the most frequent non‑zero pixel value in a mask.
    CoralScapes masks store integer class IDs per pixel.
    """
    flat = mask.ravel()
    uniq, counts = np.unique(flat, return_counts=True)
    if 0 in uniq and len(uniq) > 1:
        keep = uniq != 0
        uniq = uniq[keep]
        counts = counts[keep]
    if len(uniq) == 0:
        return 0
    return int(uniq[counts.argmax()])

def process_parquet(
    parquet_path: pathlib.Path,
    split: str,
    id2label: Dict[int, str],
    per_class_limit: Optional[int],
    errors: List[str],
) -> (int, int, Dict[str, int]):
    """Extract images from a single parquet file.
    Returns (extracted, skipped, per‑class counts for this file).
    """
    try:
        table = pq.read_table(parquet_path)
    except Exception as e:
        errors.append(f"Failed to read {parquet_path.name}: {e}")
        return 0, 0, {}

    extracted = 0
    skipped = 0
    class_counts: Dict[str, int] = defaultdict(int)

    for row_idx in range(table.num_rows):
        try:
            row = table.slice(row_idx, 1).to_pydict()
            img_dict = row["image"][0]
            label_dict = row["label"][0]

            # ----- image -----
            img_bytes = img_dict.get("bytes")
            if img_bytes is None:
                raise ValueError("Image dict missing 'bytes'")
            image = Image.open(io.BytesIO(img_bytes)).convert("RGB")

            # ----- label mask -----
            mask_bytes = label_dict.get("bytes")
            if mask_bytes is None:
                raise ValueError("Label dict missing 'bytes'")
            mask = Image.open(io.BytesIO(mask_bytes))
            mask_arr = np.array(mask)
            label_id = most_common_label(mask_arr)
            class_name = id2label.get(label_id, f"unknown_{label_id}")

            # ----- per‑class limit (applied per split) -----
            if per_class_limit is not None and class_counts[class_name] >= per_class_limit:
                skipped += 1
                continue

            # ----- save image -----
            class_dir = OUTPUT_ROOT / split / class_name
            class_dir.mkdir(parents=True, exist_ok=True)
            stem = pathlib.Path(img_dict.get("path", f"img_{row_idx}")).stem
            out_path = class_dir / f"{stem}_{row_idx}.jpg"
            image.save(out_path, format="JPEG", quality=95)

            class_counts[class_name] += 1
            extracted += 1
        except Exception as exc:
            errors.append(f"{parquet_path.name} row {row_idx}: {exc}")
            skipped += 1
    return extracted, skipped, class_counts

def main():
    parser = argparse.ArgumentParser(description="Extract CoralScapes images for CNN training")
    parser.add_argument(
        "--splits",
        nargs="*",
        choices=["train", "validation", "test"],
        default=["train", "validation", "test"],
        help="Which dataset splits to process (default all).",
    )
    parser.add_argument(
        "--max_images_per_class",
        type=int,
        default=None,
        help="Maximum images to keep per class **per split** (None = unlimited).",
    )
    args = parser.parse_args()

    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    id2label = load_id2label()
    overall_errors: List[str] = []
    overall_summary: Dict[str, Dict[str, int]] = {}
    overall_class_counts: Dict[str, int] = defaultdict(int)

    # Build file lists per split
    split_files: Dict[str, List[pathlib.Path]] = {
        "train": sorted(DATA_ROOT.glob("train-*-of-*.parquet")),
        "validation": sorted(DATA_ROOT.glob("validation-*-of-*.parquet")),
        "test": sorted(DATA_ROOT.glob("test-*-of-*.parquet")),
    }

    for split in args.splits:
        files = split_files.get(split, [])
        if not files:
            print(f"[WARN] No parquet files found for split '{split}'. Skipping.")
            continue
        print(f"Processing split '{split}' ({len(files)} files)...")
        split_extracted = 0
        split_skipped = 0
        split_class_counts: Dict[str, int] = defaultdict(int)
        for p in files:
            extracted, skipped, file_class_counts = process_parquet(
                p, split, id2label, args.max_images_per_class, overall_errors
            )
            for cls, cnt in file_class_counts.items():
                split_class_counts[cls] += cnt
                overall_class_counts[cls] += cnt
            split_extracted += extracted
            split_skipped += skipped
        overall_summary[split] = {"extracted": split_extracted, "skipped": split_skipped}
        print(f"{split.upper()} – extracted: {split_extracted}, skipped: {split_skipped}")

    # Write JSON summary
    summary_path = OUTPUT_ROOT / "dataset_summary.json"
    full_summary = {
        "class_counts": dict(overall_class_counts),
        "splits": overall_summary,
        "errors": overall_errors,
        "max_images_per_class": args.max_images_per_class,
        "total_classes": len(overall_class_counts),
    }
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(full_summary, f, indent=2)
    print(f"Dataset summary written to {summary_path}")

if __name__ == "__main__":
    main()