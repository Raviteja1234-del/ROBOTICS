# run_all.ps1
# Launches the CNN inference server (:8000) and the AUV Mission Control backend (:8001) in the background.

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$innerDir = Join-Path $projectRoot "autonomous-underwater-robot"

$venvPython = Join-Path $projectRoot ".venv\Scripts\python.exe"
if (Test-Path $venvPython) {
    $pythonCmd = $venvPython
} else {
    $pythonCmd = (Get-Command python -ErrorAction SilentlyContinue).Source
    if (-not $pythonCmd) { $pythonCmd = "python" }
}

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  AUTONOMOUS UNDERWATER ROBOT - MISSION CONTROL STARTUP" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "Python Executable : $pythonCmd"
Write-Host "Project Root      : $projectRoot"
Write-Host "Backend Root      : $innerDir"

# Stop any existing processes on ports 8000 and 8001
$portsToClean = @(8000, 8001)
foreach ($p in $portsToClean) {
    $conns = Get-NetTCPConnection -LocalPort $p -ErrorAction SilentlyContinue
    if ($conns) {
        $pidsToKill = $conns.OwningProcess | Select-Object -Unique
        foreach ($procId in $pidsToKill) {
            if ($procId -gt 0 -and $procId -ne $PID) {
                Write-Host "Cleaning stale process on port $p (PID: $procId)..." -ForegroundColor DarkGray
                Stop-Process -Id $procId -Force -ErrorAction SilentlyContinue
            }
        }
    }
}
Start-Sleep -Milliseconds 600

# ------------------------------------------------------------
# 1. Start the CNN inference FastAPI server (serve_model.py :8000)
# ------------------------------------------------------------
Write-Host "`n[1/3] Starting CoralScapes CNN Inference Server on :8000..." -ForegroundColor Yellow
$serveScript = "Set-Location '$projectRoot'; & '$pythonCmd' serve_model.py"
$serveProc = Start-Process -FilePath "powershell" -ArgumentList "-NoProfile", "-WindowStyle", "Hidden", "-Command", $serveScript -PassThru

# ------------------------------------------------------------
# 2. Start the AUV Backend & Dashboard API (backend/main.py :8001)
# ------------------------------------------------------------
Write-Host "[2/3] Starting AUV Mission Control Backend on :8001..." -ForegroundColor Yellow
$backendScript = "Set-Location '$innerDir'; & '$pythonCmd' -m uvicorn backend.main:app --host 127.0.0.1 --port 8001"
$backendProc = Start-Process -FilePath "powershell" -ArgumentList "-NoProfile", "-WindowStyle", "Hidden", "-Command", $backendScript -PassThru

Write-Host "`nWaiting for servers to initialize..." -ForegroundColor Cyan
Start-Sleep -Seconds 3

# ------------------------------------------------------------
# 3. Health Checks
# ------------------------------------------------------------
Write-Host "`n=== CNN HEALTH ===" -ForegroundColor Cyan
$cnnOk = $false
for ($i = 0; $i -lt 5; $i++) {
    try {
        $res = Invoke-RestMethod -Uri "http://127.0.0.1:8000/health" -Method Get -TimeoutSec 3 -ErrorAction Stop
        Write-Host "CNN server online: status=$($res.status), device=$($res.device)" -ForegroundColor Green
        $cnnOk = $true
        break
    } catch {
        Start-Sleep -Seconds 1
    }
}
if (-not $cnnOk) {
    Write-Host "CNN health check failed (PID: $($serveProc.Id)). Check if dependencies or weights are loaded." -ForegroundColor Red
}

Write-Host "`n=== BACKEND HEALTH ===" -ForegroundColor Cyan
$backendOk = $false
for ($i = 0; $i -lt 5; $i++) {
    try {
        $res = Invoke-RestMethod -Uri "http://127.0.0.1:8001/health" -Method Get -TimeoutSec 3 -ErrorAction Stop
        Write-Host "Backend server online: status=$($res.status), cnn_ready=$($res.cnn_available)" -ForegroundColor Green
        $backendOk = $true
        break
    } catch {
        Start-Sleep -Seconds 1
    }
}
if (-not $backendOk) {
    Write-Host "Backend health check failed (PID: $($backendProc.Id)). Check backend logs." -ForegroundColor Red
}

# ------------------------------------------------------------
# 4. Launch Dashboard
# ------------------------------------------------------------
if ($backendOk) {
    Write-Host "`n=== DASHBOARDS READY ===" -ForegroundColor Green
    Write-Host "Main Mission Control : http://127.0.0.1:8001/" -ForegroundColor Green
    Write-Host "AquaVision-XAI Lab   : http://127.0.0.1:8001/cnn-analysis" -ForegroundColor Green
    Write-Host "FastAPI Docs         : http://127.0.0.1:8001/docs" -ForegroundColor Green
    Write-Host "Launching dashboard in browser..." -ForegroundColor Cyan
    Start-Process "http://127.0.0.1:8001/"
} else {
    Write-Host "`nMission Control URL : http://127.0.0.1:8001/" -ForegroundColor Yellow
    Write-Host "AquaVision-XAI URL  : http://127.0.0.1:8001/cnn-analysis" -ForegroundColor Yellow
}
