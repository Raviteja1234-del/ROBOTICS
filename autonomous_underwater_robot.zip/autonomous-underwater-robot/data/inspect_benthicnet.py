"""Inspect BenthicNet metadata and image layout without downloading or training."""
from __future__ import annotations

import argparse
import csv
import json
from collections import Counter
from pathlib import Path

import yaml

IMAGE_EXTS = {'.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff', '.webp'}


def load_mapping(path: Path):
    return yaml.safe_load(path.read_text(encoding='utf-8'))


def find_license_files(root: Path):
    return list(root.rglob('all_licenses_refs.csv')) + list(root.rglob('*license*.csv'))


def inspect(root: Path, mapping_path: Path):
    if not root.exists():
        raise FileNotFoundError(f'BenthicNet path does not exist: {root}')

    mapping = load_mapping(mapping_path)
    labels = Counter()
    sources = Counter()
    sites = Counter()
    total = 0

    for path in root.rglob('*'):
        if not path.is_file() or path.suffix.lower() not in IMAGE_EXTS:
            continue
        total += 1
        relative = path.relative_to(root)
        parts = relative.parts
        labels[parts[-2] if len(parts) >= 2 else 'unknown'] += 1
        sources[parts[0] if parts else 'unknown'] += 1
        sites[parts[1] if len(parts) >= 3 else (parts[0] if parts else 'unknown')] += 1

    licenses = []
    for file in find_license_files(root):
        try:
            with file.open(newline='', encoding='utf-8-sig') as handle:
                rows = list(csv.DictReader(handle))
            licenses.append({
                'file': str(file.relative_to(root)),
                'rows': len(rows),
                'columns': list(rows[0]) if rows else [],
            })
        except Exception as exc:
            licenses.append({'file': str(file.relative_to(root)), 'error': str(exc)})

    return {
        'root': str(root.resolve()),
        'total_images': total,
        'labels_by_directory': dict(labels),
        'source_by_directory': dict(sources),
        'sites_by_directory': dict(sites),
        'proposed_mapping': mapping,
        'licenses': licenses,
        'status': 'INSPECTED',
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', default=None)
    parser.add_argument('--mapping', default=str(Path(__file__).with_name('label_mapping.yaml')))
    parser.add_argument('--approve', action='store_true', help='Run inspection and explicitly approve the mapping; training is still started by cnn/train_cnn.py')
    args = parser.parse_args()

    root = Path(args.root) if args.root else Path(__import__('config').DATA_ROOT)
    result = inspect(root, Path(args.mapping))
    print(json.dumps(result, indent=2, default=str))
    if args.approve:
        print('\nExplicit inspection approval recorded. Run cnn/train_cnn.py --root <path> --approve to train.')
    else:
        print('\nReview the proposed mapping and counts before approving training.')


if __name__ == '__main__':
    main()
