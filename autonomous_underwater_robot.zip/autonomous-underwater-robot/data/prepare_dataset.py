"""Prepare BenthicNet labels into a source/site-aware 70/15/15 manifest split."""
from __future__ import annotations

import json
import random
from pathlib import Path

import pandas as pd
import yaml
from sklearn.model_selection import GroupShuffleSplit

EXTS = {'.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff', '.webp'}


def normalize(value: str) -> str:
    return ' '.join(str(value).strip().lower().replace('_', ' ').replace('-', ' ').split())


def prepare_dataset(root: Path, mapping_path: Path, out: Path, seed: int = 12345) -> dict:
    root = Path(root).resolve()
    mapping = yaml.safe_load(Path(mapping_path).read_text(encoding='utf-8'))

    lookup = {
        normalize(value): class_name
        for class_name, values in mapping.items()
        if class_name != 'Excluded'
        for value in values
    }
    excluded = {normalize(value) for value in mapping.get('Excluded', [])}

    rows = []
    for path in root.rglob('*'):
        if not path.is_file() or path.suffix.lower() not in EXTS:
            continue

        label = None
        for part in reversed(path.parts):
            normalized = normalize(part)
            if normalized in excluded:
                label = None
                break
            if normalized in lookup:
                label = lookup[normalized]
                break

        if label:
            relative = path.relative_to(root)
            source = relative.parts[0] if len(relative.parts) > 1 else 'unknown'
            site = relative.parts[1] if len(relative.parts) > 2 else source
            rows.append({
                'path': str(path),
                'label': label,
                'source': source,
                'site': site,
            })

    df = pd.DataFrame(rows)
    if df.empty:
        raise SystemExit(
            'No mapped images found. Check the BenthicNet directory structure and data/label_mapping.yaml.'
        )

    # Deterministic source/site-aware split. The two GroupShuffleSplit calls produce
    # approximately 70/15/15 while preventing images from the same site leaking across splits.
    groups = df['site'].astype(str)
    first = GroupShuffleSplit(n_splits=1, test_size=0.30, random_state=seed)
    train_idx, temp_idx = next(first.split(df, groups=groups))
    train = df.iloc[train_idx].copy()
    temp = df.iloc[temp_idx].copy()

    second = GroupShuffleSplit(n_splits=1, test_size=0.50, random_state=seed + 1)
    val_idx, test_idx = next(second.split(temp, groups=temp['site'].astype(str)))
    val = temp.iloc[val_idx].copy()
    test = temp.iloc[test_idx].copy()

    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    for name, frame in [('train', train), ('val', val), ('test', test)]:
        frame.to_csv(out / f'{name}.csv', index=False)

    summary = {
        'total_mapped_images': int(len(df)),
        'split_sizes': {'train': len(train), 'validation': len(val), 'test': len(test)},
        'class_counts': {
            name: frame['label'].value_counts().to_dict()
            for name, frame in [('train', train), ('validation', val), ('test', test)]
        },
        'source_counts': df['source'].value_counts().to_dict(),
        'site_count': int(df['site'].nunique()),
        'seed': seed,
        'split_strategy': 'GroupShuffleSplit by site, approximately 70/15/15',
    }
    (out / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    return summary


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--root', required=True)
    parser.add_argument('--mapping', default='data/label_mapping.yaml')
    parser.add_argument('--out', default='data/splits')
    parser.add_argument('--approved', action='store_true')
    parser.add_argument('--seed', type=int, default=12345)
    args = parser.parse_args()

    if not args.approved:
        raise SystemExit('Refusing to prepare dataset without --approved.')

    summary = prepare_dataset(Path(args.root), Path(args.mapping), Path(args.out), args.seed)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
