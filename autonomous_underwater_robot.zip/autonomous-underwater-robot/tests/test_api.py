from fastapi.testclient import TestClient
from backend.main import app

def test_health():
    c=TestClient(app); r=c.get('/api/health'); assert r.status_code==200; assert r.json()['status']=='ok'

def test_state():
    c=TestClient(app); r=c.get('/api/state'); assert r.status_code==200; assert 'robot' in r.json()
