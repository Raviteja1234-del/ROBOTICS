from cnn.model import build_model,CLASS_NAMES

def test_model_shape():
    import torch
    m=build_model(False); x=torch.randn(2,3,224,224); y=m(x); assert tuple(y.shape)==(2,3); assert len(CLASS_NAMES)==3

def test_probabilities():
    import torch
    m=build_model(False); p=torch.softmax(m(torch.randn(1,3,224,224)),1); assert abs(float(p.sum())-1)<1e-5
