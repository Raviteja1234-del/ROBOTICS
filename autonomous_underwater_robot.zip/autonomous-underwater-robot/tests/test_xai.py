import os
import sys
import numpy as np
import pytest
from PIL import Image
from fastapi.testclient import TestClient

# Ensure root paths are in sys.path
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from backend.xai_engine import xai_engine
from backend.main import app

@pytest.fixture
def test_image():
    # Synthetic RGB underwater frame 224x224x3
    img = np.zeros((224, 224, 3), dtype=np.uint8)
    img[:, :, 0] = 30   # Blue-green water
    img[:, :, 1] = 120
    img[:, :, 2] = 180
    # Add high texture region (coral/rock simulation)
    img[50:150, 50:150, :] = np.random.randint(50, 220, (100, 100, 3), dtype=np.uint8)
    return img

def test_xai_feature_extraction(test_image):
    features = xai_engine.extract_image_features(test_image)
    assert "texture" in features
    assert "edge_and_shape" in features
    assert "color" in features
    assert "structure" in features

    tex = features["texture"]
    assert "glcm_contrast" in tex
    assert "glcm_homogeneity" in tex
    assert "glcm_energy" in tex
    assert "glcm_correlation" in tex
    assert "texture_entropy" in tex

    edges = features["edge_and_shape"]
    assert "edge_density" in edges
    assert edges["edge_density"]["value"] >= 0.0

def test_xai_analyze_frame(test_image):
    result = xai_engine.analyze_frame(test_image)
    assert "frame_id" in result
    assert "prediction" in result
    assert "features" in result
    assert "cnn_activations" in result
    assert "gradcam" in result
    assert "explanation" in result

    # Check predictions format
    pred = result["prediction"]
    assert "environment" in pred
    assert "confidence" in pred
    assert "app_scores" in pred
    assert "Rock" in pred["app_scores"]
    assert "Sand" in pred["app_scores"]
    assert "Coral Reef" in pred["app_scores"]

    # Check activation maps
    activations = result["cnn_activations"]
    assert "conv1" in activations
    assert "layer1" in activations
    assert "layer2" in activations
    assert "layer3" in activations
    assert "layer4" in activations
    assert "avgpool" in activations

    # Check Grad-CAM
    assert "heatmap_base64" in result["gradcam"]
    assert "overlay_base64" in result["gradcam"]

def test_xai_occlusion_perturbation(test_image):
    # Run perturbation experiment on synthetic image
    res = xai_engine.run_occlusion_experiment(test_image)
    assert "target_class" in res
    assert "base_score" in res
    assert "sensitivity_grid" in res
    assert "overlay_base64" in res
    assert len(res["sensitivity_grid"]) == 3
    assert len(res["sensitivity_grid"][0]) == 3

def test_xai_fastapi_endpoints():
    client = TestClient(app)

    # 1. /api/model/info
    res = client.get("/api/model/info")
    assert res.status_code == 200
    info = res.json()
    assert "architecture" in info
    assert "checkpoint_status" in info
    assert "supported_application_classes" in info

    # 2. /api/dataset/stats
    res = client.get("/api/dataset/stats")
    assert res.status_code == 200
    stats = res.json()
    assert "dataset_name" in stats
    assert "macro_mapping" in stats

    # 3. /api/training/history
    res = client.get("/api/training/history")
    assert res.status_code == 200
    th = res.json()
    assert "epoch_history" in th
    assert "evaluation_metrics" in th

    # 4. /api/environment/live
    res = client.get("/api/environment/live")
    assert res.status_code == 200
    live = res.json()
    assert "frame_id" in live
    assert "prediction" in live

    # 5. /api/feature-validation
    res = client.get("/api/feature-validation")
    assert res.status_code == 200
    fv = res.json()
    assert "samples_analyzed" in fv
    assert "feature_benchmarks" in fv

    # 6. /api/environment/history
    res = client.get("/api/environment/history")
    assert res.status_code == 200
    h = res.json()
    assert "history" in h

    # 7. /api/perturbation
    res = client.post("/api/perturbation")
    assert res.status_code == 200
    p = res.json()
    assert "sensitivity_grid" in p

def test_original_dashboard_preserved():
    """Verify that original dashboard (GET /) remains intact with all panels from reference screenshot."""
    client = TestClient(app)
    res = client.get("/")
    assert res.status_code == 200
    html = res.text
    assert "ROBOT VIEW (Live Camera Feed)" in html
    assert "3D ENVIRONMENT VIEW" in html
    assert "SEABED CLASSIFICATION MAP" in html
    assert "CNN CLASSIFICATION (Current View)" in html
    assert "ROBOT STATUS" in html
    assert "RL TRAINING (Live Plot)" in html
    assert "SENSOR DATA" in html
    assert "EXPLORATION SUMMARY" in html
    assert "SYSTEM LOG (Latest)" in html
    assert "scene3d.js" in html
    assert "dashboard.js" in html

def test_new_dashboard_routes_and_endpoints():
    """Verify that the separate CNN Explainability Dashboard is accessible and all API endpoints function."""
    client = TestClient(app)

    # Separate dashboard frontend files
    res = client.get("/cnn-analysis")
    assert res.status_code == 200
    assert "CNN Training, Feature Extraction" in res.text

    assert client.get("/cnn_analysis.css").status_code == 200
    assert client.get("/cnn_analysis.js").status_code == 200

    # Separate API endpoints under /api/cnn-analysis/
    assert client.get("/api/cnn-analysis/model-info").status_code == 200
    assert client.get("/api/cnn-analysis/training-history").status_code == 200
    assert client.get("/api/cnn-analysis/dataset-stats").status_code == 200

    res_samples = client.get("/api/cnn-analysis/dataset-samples")
    assert res_samples.status_code == 200
    assert "samples" in res_samples.json()

    assert client.get("/api/cnn-analysis/live-frame").status_code == 200
    assert client.get("/api/cnn-analysis/history").status_code == 200
    assert client.post("/api/cnn-analysis/features").status_code == 200
    assert client.post("/api/cnn-analysis/perturbation").status_code == 200
    assert client.get("/api/cnn-analysis/feature-validation").status_code == 200
    assert client.get("/api/cnn-analysis/epoch-comparison").status_code == 200


def test_aquavision_21_features(test_image):
    """Verify that all 21 measurable image features are calculated according to specifications."""
    f21_data = xai_engine.extract_21_features(test_image)
    f_list = f21_data["features_list"]
    assert len(f_list) == 21
    assert len(f21_data["feature_vector_21"]) == 21

    # Verify 4 groups
    groups = {f["group"] for f in f_list}
    assert groups == {"Shape and Geometry", "Texture", "Edge and Surface", "Color and Intensity"}

    # Group counts
    shape_feats = [f for f in f_list if f["group"] == "Shape and Geometry"]
    tex_feats = [f for f in f_list if f["group"] == "Texture"]
    edge_feats = [f for f in f_list if f["group"] == "Edge and Surface"]
    color_feats = [f for f in f_list if f["group"] == "Color and Intensity"]

    assert len(shape_feats) == 7
    assert len(tex_feats) == 6
    assert len(edge_feats) == 4
    assert len(color_feats) == 4

    # Verify exact feature names
    names = [f["name"] for f in f_list]
    expected_names = [
        "Irregularity Index", "Circularity", "Compactness", "Aspect Ratio",
        "Contour Complexity", "Solidity", "Extent",
        "GLCM Contrast", "GLCM Homogeneity", "GLCM Energy", "GLCM Correlation",
        "Local Entropy", "Texture Variation",
        "Edge Density", "Mean Edge Magnitude", "Edge Orientation Distribution",
        "Local Surface-Texture Roughness",
        "Mean Brightness", "Intensity Contrast", "Color Distribution", "Color Variation",
    ]
    assert names == expected_names

    # Check fields present on every feature
    for f in f_list:
        assert "value" in f
        assert "unit_or_scale" in f
        assert "calculation" in f
        assert "scope" in f
        assert "seabed_relevance" in f
        assert "type" in f


def test_aquavision_12_pipeline_stages(test_image):
    """Verify that all 12 image processing pipeline stages are generated with intermediate visuals."""
    result = xai_engine.analyze_frame(test_image)
    stages = result["pipeline_stages"]
    assert len(stages) == 12

    stage_nums = [s["stage_num"] for s in stages]
    assert stage_nums == list(range(1, 13))

    for s in stages:
        assert "name" in s
        assert "category" in s
        assert "summary" in s
        assert "details" in s
        assert "image_base64" in s


def test_aquavision_3panel_comparison(test_image):
    """Verify that 3 parallel comparison panels analyze the identical frame."""
    result = xai_engine.analyze_frame(test_image)
    comp = result["comparison_3class"]
    assert "rock" in comp
    assert "sand" in comp
    assert "coral_reef" in comp

    for k in ["rock", "sand", "coral_reef"]:
        assert "score_pct" in comp[k]
        assert "key_features" in comp[k]
        assert "targeted_gradcam_base64" in comp[k]
        assert "rationale" in comp[k]


def test_aquavision_dataset_audit_and_benchmark():
    """Verify dataset audit, 4-class splits, and 100-sample benchmark curation."""
    audit = xai_engine.get_dataset_audit()
    assert "target_benchmark_distribution" in audit
    assert "actual_dataset_splits" in audit
    assert "class_imbalance_audit" in audit
    assert "benchmark_100_samples" in audit

    # Check target counts: 40 Rock, 10 Sand, 25 Coral Reef, 25 Other
    targets = audit["target_benchmark_distribution"]["targets"]
    assert targets["Rock"]["count"] == 40
    assert targets["Sand"]["count"] == 10
    assert targets["Coral Reef"]["count"] == 25
    assert targets["Other / Unknown"]["count"] == 25

    # Check 100 curated samples
    samples = audit["benchmark_100_samples"]
    assert len(samples) == 100


def test_aquavision_api_endpoints():
    """Verify new AquaVision-XAI REST endpoints."""
    client = TestClient(app)

    # 1. Live Frame
    res = client.get("/api/aquavision/live-frame")
    assert res.status_code == 200
    live = res.json()
    assert "features_21" in live
    assert len(live["features_21"]) == 21
    assert "pipeline_stages" in live
    assert len(live["pipeline_stages"]) == 12
    assert "comparison_3class" in live

    # 2. Dataset Audit
    res_audit = client.get("/api/aquavision/dataset-audit")
    assert res_audit.status_code == 200
    assert "benchmark_100_samples" in res_audit.json()

    # 3. Inside CNN Representative Class
    res_rep = client.get("/api/aquavision/inside-cnn/Rock")
    assert res_rep.status_code == 200
    rep = res_rep.json()
    assert rep["ok"] is True
    assert "cnn_activations" in rep

    # 4. Timeline
    res_time = client.get("/api/aquavision/timeline")
    assert res_time.status_code == 200
    assert "history" in res_time.json()

    # 5. Raw Camera Frame Endpoint
    res_cam = client.get("/api/aquavision/camera-frame")
    assert res_cam.status_code == 200
    assert res_cam.headers["content-type"] in ["image/jpeg", "image/png"]
    assert len(res_cam.content) > 100


def test_aquavision_image_base64_data_urls(test_image):
    """Verify all generated images have proper data:image/png;base64, scheme."""
    result = xai_engine.analyze_frame(test_image)

    # 1. Full image
    assert result["images"]["full_base64"].startswith("data:image/png;base64,")

    # 2. Pipeline stages
    for st in result["pipeline_stages"]:
        assert st["image_base64"].startswith("data:image/png;base64,")

    # 3. Hidden activations
    for layer_name in ["conv1", "layer1", "layer2", "layer3", "layer4", "avgpool"]:
        preview = result["cnn_activations"][layer_name]["preview_base64"]
        assert preview.startswith("data:image/png;base64,")

    # 4. Grad-CAM
    assert result["gradcam"]["heatmap_base64"].startswith("data:image/png;base64,")
    assert result["gradcam"]["overlay_base64"].startswith("data:image/png;base64,")

    # 5. 3-panel comparison
    comp = result["comparison_3class"]
    for cname in ["Rock", "Sand", "Coral Reef"]:
        panel = comp[cname]
        assert panel["targeted_gradcam_base64"].startswith("data:image/png;base64,")
        assert 0.0 <= panel["score"] <= 1.0
        assert not np.isnan(panel["score"])
        assert "key_features_dict" in panel


def test_aquavision_historical_frame_inspection(test_image):
    """Verify historical frames are cached in history_frames_map and retrievable."""
    result = xai_engine.analyze_frame(test_image)
    frame_id = result["frame_id"]

    # History lookup
    retrieved = xai_engine.get_history_frame(frame_id)
    assert retrieved is not None
    assert retrieved["frame_id"] == frame_id

    # API endpoint lookup
    client = TestClient(app)
    res = client.get(f"/api/cnn-analysis/history/{frame_id}")
    assert res.status_code == 200
    data = res.json()
    assert data["frame_id"] == frame_id



