from env.auv_env import UnderwaterExplorationEnv

def test_reset_step():
    e=UnderwaterExplorationEnv(seed=7); obs,_=e.reset(); assert obs.shape==(48,); obs,r,done,tr,info=e.step([.2,.1,0]); assert obs.shape==(48,); assert isinstance(r,float); assert 'new_tiles' in info

def test_reproducible():
    a=UnderwaterExplorationEnv(seed=9); b=UnderwaterExplorationEnv(seed=9); assert (a.terrain.grid['class']==b.terrain.grid['class']).all()
