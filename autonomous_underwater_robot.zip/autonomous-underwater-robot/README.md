# Autonomous Underwater Robot – Seabed Classification & Exploration

A mission-control application matching the supplied visual reference: dark technical dashboard, live Three.js underwater scene, AUV camera, CNN panel, top-down seabed map, PPO reward plot, sensor plots, exploration donut and event log.

## CNN training: one-command approval gate

The project does **not** fabricate CNN data, labels, probabilities or metrics. You provide the real BenthicNet dataset path.

You can now inspect, explicitly approve the proposed mapping, prepare the source/site-aware split, and train the real ResNet18 CNN with **one command**:

```powershell
python cnn/train_cnn.py --root "D:\datasets\BenthicNet" --approve --epochs 8
```

`--approve` is the explicit consent flag. Without it, training stops safely.

The command performs these stages automatically:

1. Inspects the supplied BenthicNet directory.
2. Saves `data/splits/benthicnet_inspection.json`.
3. Records explicit approval in `data/splits/approval.json`.
4. Applies the checked-in `data/label_mapping.yaml`.
5. Creates a source/site-aware approximately 70/15/15 split.
6. Saves `data/splits/train.csv`, `val.csv`, `test.csv` and `summary.json`.
7. Trains a real torchvision ResNet18.
8. Saves the best validation checkpoint to `models/cnn_seabed.pt`.
9. Saves training history and summary under `cnn/reports/`.

### Safer two-step review option

If you want to inspect first without training:

```powershell
python data/inspect_benthicnet.py --root "D:\datasets\BenthicNet"
```

Then review `data/label_mapping.yaml` and the printed counts. When satisfied, use the one-command training command above.

## Dataset mapping

The three CNN classes are exactly:

- Rock
- Sand
- Coral Reef

Ambiguous categories remain excluded unless you deliberately edit the mapping. Do not fabricate labels for an unlabeled dataset such as AURORA.

## Setup

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

Linux/macOS:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## CNN evaluation

After training:

```powershell
python cnn/evaluate.py
```

This evaluates the held-out test manifest and writes `cnn/reports/evaluation.json`.

## PPO training

```powershell
python rl/train_ppo.py --timesteps 100000
```

The learned policy is saved as `models/ppo_auv.zip`.

## Tests

```powershell
python -m pytest tests -q
```

## Dashboard Architecture: Two Independent Dashboards

The system provides two separate dashboards served from the same FastAPI backend:

### 1. Original Robot Mission Control Dashboard (Preserved Exactly)
* **URL:** [http://127.0.0.1:8001/](http://127.0.0.1:8001/)
* **Files:** `frontend/index.html`, `frontend/styles.css`, `frontend/dashboard.js`, `frontend/scene3d.js`
* **Features:**
  - Robot View (Live Camera Feed)
  - 3D Environment View (Three.js bathymetry, chase/top/free cams, AUV model)
  - Seabed Classification Map (Top View: Rock, Sand, Coral Reef, Unexplored)
  - CNN Classification (Current View)
  - Robot Status (Depth, Speed, Battery, Heading, Mode, RL Episode/Step)
  - RL Training (Live Plot: Episode Reward vs Steps)
  - Sensor Data (Depth and Obstacle Distance time-series)
  - Exploration Summary (Donut chart & coverage percentages)
  - System Log (Latest telemetry and decision events)

### 2. New CNN Explainability Dashboard (Independent)
* **Title:** CNN Training, Feature Extraction & Explainable Environment Classification
* **URL:** [http://127.0.0.1:8001/cnn-analysis](http://127.0.0.1:8001/cnn-analysis)
* **Files:** `frontend/cnn_analysis.html`, `frontend/cnn_analysis.css`, `frontend/cnn_analysis.js`
* **API Route Prefix:** `/api/cnn-analysis/...`
* **Features:**
  - **Live Image Analysis:** Real-time simulation frame ingestion, pause/resume streaming, manual image upload, dataset test image picker (`cnn_dataset/train`).
  - **Named Feature Extraction:** GLCM Texture (Contrast, Homogeneity, Energy, Correlation, Shannon Entropy, Variation), Canny Edge Density & Gradient Magnitude, Regional Edge Distributions (4 Quadrants), Morphological Shape Metrics (Irregularity, Compactness, Aspect Ratio, Area, Boundary Complexity with segmentation reliability assessment), RGB/HSV Color distributions.
  - **What the CNN Learned:** ResNet-18 layer activation explorer (`conv1`, `layer1`, `layer2`, `layer3`, `layer4`, `avgpool`), channel dimensions, sparsity, and top-variance activation previews.
  - **Why Predicted (Grad-CAM):** Visual trio (Original frame, Heatmap, Overlay), interactive target class switcher (recalculate for alternative classes), dynamic evidence-based explanation report, and 3x3 sliding occlusion perturbation experiment.
  - **CNN Training Process:** 15-epoch loss/accuracy progression curves, confusion matrix, per-class evaluation metrics table, epoch checkpoint representation comparison.
  - **Distinguishing Features & Benchmarks:** Empirical statistical comparison across Rock, Sand, and Coral Reef images with full CoralScapes class mapping.
  - **Classification History:** FIFO rolling cache of frames with time-travel inspection.

## Execution & Running

### Starting Both Services:
```powershell
.\run_all.ps1
```
Or manually:
```powershell
# Terminal 1: CNN Service
python serve_model.py

# Terminal 2: AUV Mission Control & Explainable AI Backend
cd autonomous-underwater-robot
python -m uvicorn backend.main:app --host 127.0.0.1 --port 8001
```

### Accessing the Dashboards:
* **Original Robot Mission Control:** `http://127.0.0.1:8001/`
* **New CNN Explainability Dashboard:** `http://127.0.0.1:8001/cnn-analysis`

## Running Tests
```powershell
cd autonomous-underwater-robot
python -m pytest tests -v
```
*(All 12 unit and integration tests covering RL, CNN, XAI engine, both dashboards, and all endpoints pass 100%).*

## Important

The supplied BenthicNet dataset is not bundled into this ZIP. Point `--root` at your local dataset. The project never downloads an entire dataset blindly and never fabricates missing images or labels.
