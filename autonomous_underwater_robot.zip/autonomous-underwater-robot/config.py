from pathlib import Path
import os

ROOT = Path(__file__).resolve().parent
DATA_ROOT = Path(os.getenv('BENTHICNET_ROOT', ROOT / 'datasets' / 'BenthicNet'))
MODEL_DIR = ROOT / 'models'
REPORT_DIR = ROOT / 'cnn' / 'reports'
SPLIT_DIR = ROOT / 'data' / 'splits'

SEED = int(os.getenv('AUV_SEED', '12345'))
GRID_SIZE = 100
DEPTH_LIMITS = (2.0, 30.0)
BATTERY_MIN = 10.0
MISSION_FPS = float(os.getenv('MISSION_FPS', '15'))

CLASSES = ['Rock', 'Sand', 'Coral Reef']
CLASS_COLORS = {'Rock': '#a86426', 'Sand': '#d4ae18', 'Coral Reef': '#7b36bd', 'Unexplored': '#111923'}

CNN_WEIGHTS = MODEL_DIR / 'cnn_seabed.pt'
PPO_WEIGHTS = MODEL_DIR / 'ppo_auv.zip'
