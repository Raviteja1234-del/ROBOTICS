from __future__ import annotations
import numpy as np

class FishSchool:
    def __init__(self,n=45,seed=12345,size=100):
        rng=np.random.default_rng(seed); self.rng=rng; self.pos=rng.uniform(5,size-5,(n,2)); self.vel=rng.normal(0,.35,(n,2)); self.size=size
    def step(self,dt,auv=None):
        p=self.pos; v=self.vel; n=len(p); new=[]
        for i in range(n):
            d=p-p[i]; dist=np.linalg.norm(d,axis=1)+1e-6; mask=(dist<7)&(dist>0)
            sep=(-d[mask]/dist[mask,None]).sum(0) if mask.any() else np.zeros(2)
            ali=v[mask].mean(0)-v[i] if mask.any() else np.zeros(2)
            coh=p[mask].mean(0)-p[i] if mask.any() else np.zeros(2)
            steer=1.2*sep+0.25*ali+0.06*coh
            if auv is not None:
                ad=np.array(auv[:2])-p[i]; adist=np.linalg.norm(ad)
                if adist<6: steer-=ad/(adist+1e-6)*(6-adist)*1.5
            new.append(v[i]+steer*dt)
        v=np.array(new); speed=np.linalg.norm(v,axis=1,keepdims=True); v=np.where(speed>.9,v/(speed+.0001)*.9,v)
        p=(p+v*dt)%self.size; self.pos,self.vel=p,v
