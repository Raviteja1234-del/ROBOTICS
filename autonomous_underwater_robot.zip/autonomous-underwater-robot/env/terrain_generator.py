from __future__ import annotations
from dataclasses import dataclass
import math
import numpy as np


@dataclass
class Tile:
    cls: int
    height: float


class Terrain:
    """
    Seabed Terrain Generator with Guaranteed Spatially Coherent Biome Distribution:
      - 60% Rock (class 0)
      - 30% Coral Reef (class 2)
      - 10% Sand (class 1)
    """
    def __init__(self, size: int = 100, seed: int = 12345):
        self.size = size
        self.seed = seed
        self.rng = np.random.default_rng(seed)
        self.grid = self._generate()

    def _smooth(self, a: np.ndarray, passes: int = 6) -> np.ndarray:
        for _ in range(passes):
            a = (a * 2.0 +
                 np.roll(a, 1, 0) + np.roll(a, -1, 0) +
                 np.roll(a, 1, 1) + np.roll(a, -1, 1) +
                 np.roll(np.roll(a, 1, 0), 1, 1) +
                 np.roll(np.roll(a, -1, 0), -1, 1)) / 8.0
        return a

    def _generate(self) -> dict:
        n = self.size

        # 1. Multi-scale procedural noise for geological region formation
        noise_macro = self._smooth(self.rng.random((n, n)), passes=8)
        noise_micro = self._smooth(self.rng.random((n, n)), passes=3)
        base = noise_macro * 0.75 + noise_micro * 0.25

        # Create natural local variation near starting area (12, 12) so all 3 biomes are visible early
        y_coords, x_coords = np.ogrid[:n, :n]
        start_dist = np.sqrt((x_coords - 14.0)**2 + (y_coords - 14.0)**2)
        start_blend = np.clip(1.0 - (start_dist / 22.0), 0.0, 1.0)
        start_wave = (np.sin(x_coords * 0.35) + np.cos(y_coords * 0.35)) * 0.18
        base += start_blend * start_wave

        # 2. Strict percentile thresholding: 60% Rock, 30% Coral Reef, 10% Sand
        # Rock: 0, Sand: 1, Coral Reef: 2
        flat = base.ravel()
        p60 = np.percentile(flat, 60.0)
        p90 = np.percentile(flat, 90.0)

        cls = np.zeros((n, n), dtype=np.int8)  # Default: 0 (Rock, 60%)
        cls[base >= p90] = 1                   # 10% Sand (top 10%)
        cls[(base >= p60) & (base < p90)] = 2  # 30% Coral Reef (60% to 90%)

        # 3. Morphological smoothing to avoid 1-cell noise and ensure contiguous geological zones
        for _ in range(3):
            nxt = cls.copy()
            for i in range(1, n - 1):
                for j in range(1, n - 1):
                    w = cls[i - 1:i + 2, j - 1:j + 2].ravel()
                    nxt[i, j] = np.bincount(w, minlength=3).argmax()
            cls = nxt

        # 4. Realistic bathymetric seabed elevation
        # Natural depth between 2m and 18m
        elevation = self._smooth(self.rng.random((n, n)), passes=5) * 5.0 + 2.0
        # Rocky crags have rugged vertical relief
        elevation += np.where(cls == 0, self._smooth(self.rng.random((n, n)), passes=2) * 4.2, 0.0)
        # Coral reefs form biological shelf mounds
        elevation += np.where(cls == 2, self._smooth(self.rng.random((n, n)), passes=3) * 2.5, 0.0)
        # Sand forms smooth gentle depressions
        elevation += np.where(cls == 1, -0.6, 0.0)

        return {"class": cls, "height": np.clip(elevation, 1.0, 25.0)}

    def sample(self, x: float, y: float) -> tuple[int, float]:
        i = int(np.clip(round(y), 0, self.size - 1))
        j = int(np.clip(round(x), 0, self.size - 1))
        return int(self.grid["class"][i, j]), float(self.grid["height"][i, j])

    def obstacle_distance(self, x: float, y: float, heading: float, max_range: float = 25.0, step: float = 0.5) -> float:
        dx, dy = math.cos(heading), math.sin(heading)
        for d in np.arange(step, max_range + step, step):
            xx = x + dx * d
            yy = y + dy * d
            if xx < 0 or yy < 0 or xx >= self.size or yy >= self.size:
                return float(d)
            c, h = self.sample(xx, yy)
            if c == 0 and h > 5.5:  # Large rock obstacle
                return float(d)
        return float(max_range)
