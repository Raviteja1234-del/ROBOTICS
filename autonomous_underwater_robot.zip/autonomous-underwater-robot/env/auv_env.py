from __future__ import annotations

import math
import numpy as np
import gymnasium as gym
from gymnasium import spaces

from .terrain_generator import Terrain
from .fish_boids import FishSchool


class UnderwaterExplorationEnv(gym.Env):
    """
    Autonomous Underwater Vehicle (AUV) exploration environment.

    Observation space:
        Exactly 48 floating-point values.

    Action space:
        [thrust, yaw, pitch], each in [-1, 1].
    """

    metadata = {"render_modes": []}

    def __init__(self, seed: int = 12345, size: int = 100):
        super().__init__()

        self.size = size
        self.seed_value = seed

        # ---------------------------------------------------------
        # ACTION SPACE
        # ---------------------------------------------------------
        # thrust, yaw, pitch
        self.action_space = spaces.Box(
            low=np.array([-1, -1, -1], dtype=np.float32),
            high=np.array([1, 1, 1], dtype=np.float32),
            dtype=np.float32,
        )

        # ---------------------------------------------------------
        # OBSERVATION SPACE
        # ---------------------------------------------------------
        # The project/test specification expects exactly 48 values.
        self.observation_space = spaces.Box(
            low=-np.inf,
            high=np.inf,
            shape=(48,),
            dtype=np.float32,
        )

        self.reset(seed=seed)

    # =============================================================
    # RESET
    # =============================================================

    def reset(
        self,
        seed: int | None = None,
        options: dict | None = None,
    ):
        if seed is not None:
            self.seed_value = seed

        # Generate deterministic terrain and fish when seed is fixed
        self.terrain = Terrain(
            self.size,
            self.seed_value,
        )

        self.fish = FishSchool(
            seed=self.seed_value,
            size=self.size,
        )

        # ---------------------------------------------------------
        # AUV INITIAL STATE
        # ---------------------------------------------------------

        self.pos = np.array(
            [
                self.size * 0.12,
                self.size * 0.12,
            ],
            dtype=float,
        )

        self.heading = 0.0
        self.depth = 12.0
        self.speed = 0.0
        self.battery = 100.0

        self.step_count = 0
        self.total_reward = 0.0
        self.collisions = 0

        # Explored map
        self.explored = np.zeros(
            (self.size, self.size),
            dtype=bool,
        )

        # CNN prediction map
        self.predicted = np.full(
            (self.size, self.size),
            -1,
            dtype=np.int8,
        )

        # AUV path
        self.path = [
            self.pos.copy()
        ]

        # Exploration goal
        self.goal = np.array(
            [
                self.size * 0.84,
                self.size * 0.82,
            ]
        )

        self.last_new = 0

        return self._obs(), {}

    # =============================================================
    # OBSERVATION
    # =============================================================

    def _obs(self) -> np.ndarray:
        """
        Build exactly 48 observation values.

        Components:
            Position                 = 2
            Heading                  = 2
            Depth/speed/battery      = 3
            Sonar/obstacle sensors   = 12
            Fish distance            = 1
            Local explored map       = 25
            Goal direction           = 2

        Total:
            2 + 2 + 3 + 12 + 1 + 25 + 2 = 47

        One zero padding value is added to obtain exactly 48.
        """

        # ---------------------------------------------------------
        # 1. OBSTACLE DISTANCE SENSORS
        # ---------------------------------------------------------

        sensors = [
            self.terrain.obstacle_distance(
                *self.pos,
                self.heading + angle,
            )
            for angle in np.linspace(
                -math.pi,
                math.pi,
                20,
                endpoint=False,
            )
        ]

        # We use the first 12 sensors
        sensors = sensors[:12]

        # ---------------------------------------------------------
        # 2. LOCAL EXPLORED MAP
        # ---------------------------------------------------------

        local = []

        cx, cy = map(
            int,
            self.pos,
        )

        for dy in (-2, -1, 0, 1, 2):
            for dx in (-2, -1, 0, 1, 2):

                x = np.clip(
                    cx + dx,
                    0,
                    self.size - 1,
                )

                y = np.clip(
                    cy + dy,
                    0,
                    self.size - 1,
                )

                local.append(
                    float(
                        self.explored[y, x]
                    )
                )

        # 5 x 5 = 25 values
        local = local[:25]

        # ---------------------------------------------------------
        # 3. DIRECTION TO GOAL
        # ---------------------------------------------------------

        goal_direction = self.goal - self.pos

        goal_direction = (
            goal_direction
            / (
                np.linalg.norm(goal_direction)
                + 1e-6
            )
        )

        # ---------------------------------------------------------
        # 4. DISTANCE TO FISH
        # ---------------------------------------------------------

        fish_distance = np.min(
            np.linalg.norm(
                self.fish.pos - self.pos,
                axis=1,
            )
        )

        # ---------------------------------------------------------
        # 5. BUILD OBSERVATION
        # ---------------------------------------------------------

        arr = np.array(
            [
                # Position: 2
                *(
                    self.pos
                    / self.size
                ),

                # Heading: 2
                math.sin(self.heading),
                math.cos(self.heading),

                # Depth: 1
                self.depth / 30.0,

                # Speed: 1
                self.speed,

                # Battery: 1
                self.battery / 100.0,

                # Obstacle sensors: 12
                *sensors,

                # Fish distance: 1
                fish_distance / self.size,

                # Local explored map: 25
                *local,

                # Goal direction: 2
                *goal_direction,
            ],
            dtype=np.float32,
        )

        # ---------------------------------------------------------
        # ENSURE EXACTLY 48 VALUES
        # ---------------------------------------------------------

        if len(arr) < 48:
            arr = np.pad(
                arr,
                (0, 48 - len(arr)),
                mode="constant",
                constant_values=0.0,
            )

        elif len(arr) > 48:
            arr = arr[:48]

        return arr.astype(
            np.float32
        )

    # =============================================================
    # STEP
    # =============================================================

    def step(self, action):

        # Convert action to numpy
        action = np.asarray(
            action,
            dtype=float,
        )

        # Make sure action has three values
        thrust, yaw, pitch = action

        # ---------------------------------------------------------
        # SAVE OLD POSITION
        # ---------------------------------------------------------

        old_position = self.pos.copy()

        # ---------------------------------------------------------
        # UPDATE HEADING
        # ---------------------------------------------------------

        self.heading = (
            self.heading
            + yaw * 0.08
        ) % (
            2 * math.pi
        )

        # ---------------------------------------------------------
        # UPDATE SPEED
        # ---------------------------------------------------------

        self.speed = float(
            np.clip(
                self.speed
                + thrust * 0.04,
                0,
                2.5,
            )
        )

        # ---------------------------------------------------------
        # UPDATE DEPTH
        # ---------------------------------------------------------

        self.depth = float(
            np.clip(
                self.depth
                + pitch * 0.12,
                2,
                30,
            )
        )

        # Simulation timestep
        dt = 0.2

        # ---------------------------------------------------------
        # MOVE AUV
        # ---------------------------------------------------------

        self.pos += (
            np.array(
                [
                    math.cos(self.heading),
                    math.sin(self.heading),
                ]
            )
            * self.speed
            * dt
        )

        # ---------------------------------------------------------
        # BOUNDARY COLLISION
        # ---------------------------------------------------------

        collision = not (
            0 < self.pos[0] < self.size
            and
            0 < self.pos[1] < self.size
        )

        if collision:

            self.pos = np.clip(
                self.pos,
                1,
                self.size - 2,
            )

            self.collisions += 1

        # ---------------------------------------------------------
        # UPDATE FISH
        # ---------------------------------------------------------

        self.fish.step(
            dt,
            self.pos,
        )

        # ---------------------------------------------------------
        # UPDATE EXPLORED AREA
        # ---------------------------------------------------------

        ix = int(self.pos[0])
        iy = int(self.pos[1])

        radius = 2

        y0 = max(
            0,
            iy - radius,
        )

        y1 = min(
            self.size,
            iy + radius + 1,
        )

        x0 = max(
            0,
            ix - radius,
        )

        x1 = min(
            self.size,
            ix + radius + 1,
        )

        newly = ~self.explored[
            y0:y1,
            x0:x1
        ]

        new_count = int(
            newly.sum()
        )

        self.explored[
            y0:y1,
            x0:x1
        ] = True

        self.last_new = new_count

        # ---------------------------------------------------------
        # BOOKKEEPING
        # ---------------------------------------------------------

        self.path.append(
            self.pos.copy()
        )

        self.step_count += 1

        # ---------------------------------------------------------
        # BATTERY CONSUMPTION
        # ---------------------------------------------------------

        self.battery = max(
            0.0,
            self.battery
            - (
                0.004
                + abs(thrust) * 0.003
                + self.speed * 0.001
            ),
        )

        # ---------------------------------------------------------
        # REWARD
        # ---------------------------------------------------------

        distance_before = np.linalg.norm(
            self.goal - old_position
        )

        distance_after = np.linalg.norm(
            self.goal - self.pos
        )

        reward = (
            new_count * 0.08
            + max(
                0,
                distance_before
                - distance_after,
            ) * 0.15
            - collision * 4
            - self.speed * 0.002
            - (100 - self.battery)
            * 0.0002
        )

        # Goal reached
        if distance_after < 3:
            reward += 10

        self.total_reward += reward

        # ---------------------------------------------------------
        # TERMINATION
        # ---------------------------------------------------------

        terminated = bool(
            self.explored.mean() >= 0.95
            or self.battery <= 10
            or distance_after < 3
            or self.step_count >= 10000
        )

        truncated = False

        # ---------------------------------------------------------
        # INFO
        # ---------------------------------------------------------

        info = {
            "new_tiles": new_count,
            "collision": collision,
            "distance_to_goal": float(
                distance_after
            ),
        }

        return (
            self._obs(),
            float(reward),
            terminated,
            truncated,
            info,
        )