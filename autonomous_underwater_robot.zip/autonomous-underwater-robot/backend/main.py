from __future__ import annotations

import asyncio
import io
from pathlib import Path
from typing import Optional, List, Dict, Any, Union

from fastapi import (
    FastAPI,
    WebSocket,
    WebSocketDisconnect,
    UploadFile,
    File,
    HTTPException,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel
from PIL import Image
import numpy as np

from .simulation_manager import manager
from .xai_engine import (
    xai_engine,
    PROJECT_ROOT,
    IMAGE_TRANSFORM,
    CORAL_CLASSES_SET,
    ROCK_CLASSES_SET,
    SAND_CLASSES_SET,
    OPEN_WATER_SET,
)


# ============================================================
# FASTAPI APPLICATION
# ============================================================

app = FastAPI(
    title="Autonomous Underwater Robot Mission Control",
    version="1.0.0",
)


# ============================================================
# CORS
# ============================================================

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================================
# REQUEST MODELS
# ============================================================

class SpeedRequest(BaseModel):
    value: float


# ============================================================
# STARTUP
# ============================================================

@app.on_event("startup")
async def startup():
    """
    Start the background AUV simulation loop and display mission console banner.
    """
    print("\n\033[1m\033[96m============================================================\033[0m", flush=True)
    print("\033[1m\033[96m  AUTONOMOUS UNDERWATER ROBOT (AUV) MISSION CONTROL  \033[0m", flush=True)
    print("\033[1m\033[96m  SEABED CLASSIFICATION & EXPLORATION (PPO + CNN)    \033[0m", flush=True)
    print("\033[1m\033[96m============================================================\033[0m", flush=True)
    print(f"\033[32m[SYSTEM] FastAPI Backend online at http://127.0.0.1:8001\033[0m", flush=True)
    print(f"\033[32m[SYSTEM] PPO Policy: {'AVAILABLE' if manager.policy is not None else 'UNAVAILABLE'}\033[0m", flush=True)
    print(f"\033[32m[SYSTEM] CoralScapes CNN: {'ONLINE (:8000)' if manager.cnn_available else 'SENSOR FALLBACK'}\033[0m", flush=True)
    print(f"\033[32m[SYSTEM] Real-time AI Decision Logging: ACTIVE\033[0m\n", flush=True)
    asyncio.create_task(manager.loop())


# ============================================================
# HEALTH
# ============================================================

@app.get("/health")
@app.get("/api/health")
def health():
    """
    Backend health and model availability.
    """

    return {
        "status": "ok",
        "cnn_available": manager.cnn_available,
        "ppo_available": manager.policy is not None,
        "coralscapes_images": len(manager.coral_images),
    }


# ============================================================
# CURRENT STATE
# ============================================================

@app.get("/api/state")
def state():
    """
    Return complete current AUV state.
    """

    return manager._state()


# ============================================================
# ENVIRONMENT
# ============================================================

@app.get("/api/environment")
def environment():
    """
    Return the current generated underwater environment.
    """

    return manager.environment()


# ============================================================
# START MISSION
# ============================================================

@app.post("/api/start")
def start():
    try:

        manager.start()

        return {
            "ok": True,
            "message": "AUV mission started",
        }

    except RuntimeError as e:

        raise HTTPException(
            status_code=409,
            detail=str(e),
        )


# ============================================================
# PAUSE MISSION
# ============================================================

@app.post("/api/pause")
def pause():

    manager.pause()

    return {
        "ok": True,
        "message": "AUV mission paused",
    }


# ============================================================
# RESET MISSION
# ============================================================

@app.post("/api/reset")
def reset():

    manager.reset()

    return {
        "ok": True,
        "message": "AUV mission reset",
    }


# ============================================================
# NEW ENVIRONMENT
# ============================================================

@app.post("/api/environment/new")
def new_environment():

    manager.reset(seed=None)

    return {
        "ok": True,
        "message": "New underwater environment generated",
    }


# ============================================================
# SPEED
# ============================================================

@app.post("/api/speed")
def speed(req: SpeedRequest):

    allowed = {
        0.25,
        0.5,
        1,
        1.5,
        2,
        3,
        4,
        5,
        8,
    }

    if req.value not in allowed and not (0.1 <= req.value <= 10.0):

        raise HTTPException(
            status_code=400,
            detail=(
                "Speed must be positive and <= 10 (supported presets: 0.5, 1, 2, 3, 5)"
            ),
        )

    manager.set_speed(req.value)

    return {
        "ok": True,
        "speed": req.value,
    }


# ============================================================
# REAL CORALSCAPES CNN PREDICTION
# ============================================================

@app.post("/api/cnn/predict")
async def cnn_predict(
    file: UploadFile = File(...)
):
    """
    Send an uploaded image to the real CoralScapes CNN.

    Flow:

        Dashboard
             |
             v
        AUV Backend :8001
             |
             v
        CNN Server :8000
             |
             v
        CoralScapes ResNet18
    """

    try:

        image_bytes = await file.read()

        if not image_bytes:

            raise HTTPException(
                status_code=400,
                detail="Uploaded file is empty",
            )

        image = Image.open(
            io.BytesIO(image_bytes)
        ).convert("RGB")

        result = manager.predict_image(
            image
        )

        return {
            "ok": True,
            "prediction": result,
        }

    except HTTPException:
        raise

    except RuntimeError as e:

        raise HTTPException(
            status_code=409,
            detail=str(e),
        )

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"CNN prediction failed: {e}",
        )


# ============================================================
# EXPLAINABLE AI & MODEL INSPECTION ENDPOINTS
# ============================================================

@app.get("/api/model/info")
def model_info():
    """Detailed CNN architecture, checkpoint status, and supported classes."""
    info = xai_engine.get_training_analysis()
    return {
        "ok": True,
        "architecture": info["model_metadata"]["architecture"],
        "backbone": info["model_metadata"]["backbone_weights"],
        "parameters": info["model_metadata"]["num_parameters"],
        "checkpoint_status": info["model_metadata"]["status"],
        "device": info["model_metadata"]["device"],
        "input_resolution": info["model_metadata"]["input_resolution"],
        "fine_grained_classes": xai_engine.class_names,
        "supported_application_classes": ["Rock", "Sand", "Coral Reef", "Open Water", "Unknown / Uncertain"],
        "note": "Trained on CoralScapes 22 benthic classes. Predictions are mapped to high-level benthic application classes."
    }


@app.get("/api/dataset/stats")
def dataset_stats():
    """CoralScapes dataset statistics, split counts, and class definitions."""
    info = xai_engine.get_training_analysis()
    return {
        "ok": True,
        "dataset_name": "CoralScapes Benthic Substrate",
        "splits": info["training_hyperparameters"]["splits"],
        "num_classes": len(xai_engine.class_names),
        "fine_classes": xai_engine.class_names,
        "macro_mapping": {
            "Coral Reef": sorted(list(CORAL_CLASSES_SET)),
            "Rock": sorted(list(ROCK_CLASSES_SET)),
            "Sand": sorted(list(SAND_CLASSES_SET)),
            "Open Water": sorted(list(OPEN_WATER_SET)),
        },
    }


@app.get("/api/training/history")
def training_history():
    """Complete training metrics, loss/accuracy curves, and confusion matrix."""
    return xai_engine.get_training_analysis()


@app.get("/api/environment/live")
def environment_live():
    """Get latest live analyzed frame, features, Grad-CAM, and dynamic explanation."""
    if manager.latest_xai_analysis is None:
        manager._run_initial_xai_analysis()
    return manager.latest_xai_analysis or {"error": "No live frame analyzed yet"}


@app.get("/api/environment/history")
def environment_history(limit: int = 50):
    """List recent classification history records for interactive timeline."""
    return {
        "ok": True,
        "count": len(xai_engine.history),
        "history": xai_engine.get_history(limit=limit),
    }


@app.get("/api/environment/history/{frame_id}")
def environment_history_frame(frame_id: str):
    """Retrieve the exact full analysis record for a specific historical frame."""
    record = xai_engine.get_history_frame(frame_id)
    if record is None:
        raise HTTPException(
            status_code=404,
            detail=f"Frame '{frame_id}' not found in classification history cache",
        )
    return record


@app.post("/api/classify")
async def classify_uploaded(
    file: UploadFile = File(...)
):
    """Analyze an uploaded underwater image through full XAI pipeline."""
    try:
        contents = await file.read()
        if not contents:
            raise HTTPException(status_code=400, detail="Uploaded file is empty")
        pil_img = Image.open(io.BytesIO(contents)).convert("RGB")
        result = xai_engine.analyze_frame(
            pil_img,
            source_name=file.filename or "Uploaded User Image",
        )
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Classification failed: {e}")


@app.post("/api/features")
async def compute_features_only(
    file: UploadFile = File(...)
):
    """Compute named image features (GLCM texture, edges, color, structure)."""
    try:
        contents = await file.read()
        if not contents:
            raise HTTPException(status_code=400, detail="Uploaded file is empty")
        pil_img = Image.open(io.BytesIO(contents)).convert("RGB")
        features = xai_engine.extract_image_features(pil_img)
        return {"ok": True, "features": features}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Feature calculation failed: {e}")


@app.post("/api/explain")
async def explain_target_class(
    target_class: Optional[str] = None,
    file: Optional[UploadFile] = None,
):
    """
    Compute Grad-CAM for a selected target class on the current live frame or an uploaded frame.
    """
    try:
        if file is not None:
            contents = await file.read()
            pil_img = Image.open(io.BytesIO(contents)).convert("RGB")
        elif manager.last_camera_image and manager.last_camera_image.exists():
            pil_img = Image.open(manager.last_camera_image).convert("RGB")
        else:
            arr = np.full((224, 224, 3), [18, 45, 62], dtype=np.uint8)
            pil_img = Image.fromarray(arr)

        target_idx = None
        if target_class:
            t_low = target_class.lower()
            for idx, cname in enumerate(xai_engine.class_names):
                if cname.lower() == t_low or t_low in cname.lower():
                    target_idx = idx
                    break

        img_np = np.array(pil_img)
        input_tensor = IMAGE_TRANSFORM(pil_img).unsqueeze(0).to(xai_engine.device)
        gradcam = xai_engine.compute_gradcam(
            input_tensor,
            img_np,
            target_class_index=target_idx,
        )
        return {"ok": True, "gradcam": gradcam}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Grad-CAM generation failed: {e}")


@app.get("/api/feature-validation")
def feature_validation():
    """Empirical feature benchmarks comparing Rock, Sand, and Coral Reef."""
    return xai_engine.get_feature_validation_stats()


@app.post("/api/perturbation")
async def perturbation_experiment(
    file: Optional[UploadFile] = None,
):
    """Run 3x3 sliding occlusion perturbation experiment to evaluate feature sensitivity."""
    try:
        if file is not None:
            contents = await file.read()
            pil_img = Image.open(io.BytesIO(contents)).convert("RGB")
        elif manager.last_camera_image and manager.last_camera_image.exists():
            pil_img = Image.open(manager.last_camera_image).convert("RGB")
        else:
            arr = np.full((224, 224, 3), [18, 45, 62], dtype=np.uint8)
            pil_img = Image.fromarray(arr)
        return xai_engine.run_occlusion_experiment(pil_img)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Perturbation experiment failed: {e}")


@app.get("/api/epoch-comparison")
def epoch_comparison():
    """Compare intermediate representations across early vs final training epochs."""
    if manager.last_camera_image and manager.last_camera_image.exists():
        pil_img = Image.open(manager.last_camera_image).convert("RGB")
    else:
        arr = np.full((224, 224, 3), [18, 45, 62], dtype=np.uint8)
        pil_img = Image.fromarray(arr)
    return xai_engine.get_epoch_comparison(pil_img)


@app.get("/api/robot/status")
def robot_status():
    """Current robot state, telemetry, and mission status."""
    st = manager._state()
    return {
        "robot": st["robot"],
        "mission": st["mission"],
        "sensors": st["sensors"],
        "map": st["map"],
    }


# ============================================================
# WEBSOCKET
# ============================================================

@app.websocket("/ws")
async def websocket(
    ws: WebSocket
):

    await ws.accept()

    queue = asyncio.Queue(
        maxsize=2
    )

    manager.subscribe(queue)

    try:

        # Send current state immediately.
        await ws.send_json(
            manager._state()
        )

        while True:

            current_state = await queue.get()

            await ws.send_json(
                current_state
            )

    except (
        WebSocketDisconnect,
        asyncio.CancelledError,
    ):

        pass

    finally:

        manager.unsubscribe(queue)


# ============================================================
# FRONTEND FILES
# ============================================================

FRONTEND_DIR = (
    Path(__file__).resolve()
    .parent
    .parent
    / "frontend"
)


@app.get("/")
def index():

    return FileResponse(
        FRONTEND_DIR / "index.html"
    )


@app.get("/dashboard.js")
def dashboard_js():

    return FileResponse(
        FRONTEND_DIR / "dashboard.js"
    )


@app.get("/styles.css")
def styles_css():

    return FileResponse(
        FRONTEND_DIR / "styles.css"
    )


@app.get("/scene3d.js")
def scene3d_js():

    return FileResponse(
        FRONTEND_DIR / "scene3d.js"
    )


@app.get("/three.min.js")
def three_min_js():

    return FileResponse(
        FRONTEND_DIR / "three.min.js"
    )


@app.get("/html2canvas.min.js")
def html2canvas_min_js():
    return FileResponse(
        FRONTEND_DIR / "html2canvas.min.js"
    )


# ------------------------------------------------------------
# SEPARATE CNN EXPLAINABILITY DASHBOARD ROUTES
# ------------------------------------------------------------

@app.get("/cnn-analysis")
def cnn_analysis_page():
    """Independent CNN Training, Feature Extraction & Explainable Classification Dashboard."""
    return FileResponse(FRONTEND_DIR / "cnn_analysis.html")


@app.get("/cnn_analysis.css")
def cnn_analysis_css():
    return FileResponse(FRONTEND_DIR / "cnn_analysis.css")


@app.get("/cnn_analysis.js")
def cnn_analysis_js():
    return FileResponse(FRONTEND_DIR / "cnn_analysis.js")


# ============================================================
# NEW CNN EXPLAINABILITY DASHBOARD API ENDPOINTS
# ============================================================

@app.get("/api/cnn-analysis/model-info")
def cnn_analysis_model_info():
    """ResNet-18 model architecture, parameters, layers, and checkpoint status."""
    return model_info()


@app.get("/api/cnn-analysis/training-history")
def cnn_analysis_training_history():
    """Loss/accuracy curves, confusion matrix, hyperparameters, and evaluation metrics."""
    return training_history()


@app.get("/api/cnn-analysis/dataset-stats")
def cnn_analysis_dataset_stats():
    """CoralScapes dataset statistics, class distribution, and macro mapping."""
    return dataset_stats()


@app.get("/api/cnn-analysis/dataset-samples")
def cnn_analysis_dataset_samples():
    """Actual sample crops from the CoralScapes dataset for user-selected inspection."""
    samples = xai_engine.get_dataset_samples(per_class_limit=6)
    return {
        "ok": True,
        "count": len(samples),
        "samples": samples,
    }


@app.get("/api/aquavision/camera-frame")
@app.get("/api/cnn-analysis/camera-frame")
def aquavision_camera_frame():
    """Return raw image bytes for live camera view with correct image/jpeg MIME type."""
    img_bytes = manager.get_current_camera_frame_bytes()
    return Response(content=img_bytes, media_type="image/jpeg")


@app.get("/api/aquavision/live-frame")
@app.get("/api/cnn-analysis/live-frame")
def cnn_analysis_live_frame():
    """
    Retrieve latest analyzed frame, 21 features, and pipeline data from active simulation.
    """
    if manager.latest_xai_analysis is not None:
        res = dict(manager.latest_xai_analysis)
        res["simulation_running"] = manager.running
        return res

    if manager.last_camera_image and manager.last_camera_image.exists():
        try:
            im = Image.open(manager.last_camera_image).convert("RGB")
            st = manager._state()
            analysis = xai_engine.analyze_frame(
                im,
                robot_telemetry=st["robot"],
                source_name="Simulation Camera Buffer",
            )
            analysis["simulation_running"] = manager.running
            return analysis
        except Exception:
            pass

    # Starter baseline so AquaVision-XAI dashboard opens instantly with live features
    try:
        arr = np.full((224, 224, 3), [18, 45, 62], dtype=np.uint8)
        analysis = xai_engine.analyze_frame(arr, source_name="Underwater Benthic Baseline")
        analysis["simulation_running"] = manager.running
        return analysis
    except Exception as e:
        return {
            "ok": False,
            "simulation_running": manager.running,
            "message": f"Frame unavailable: {e}",
        }


@app.get("/api/aquavision/timeline")
@app.get("/api/cnn-analysis/history")
def cnn_analysis_history(limit: int = 50):
    """Retrieve classification history list for time-travel frame selection."""
    return environment_history(limit=limit)


@app.get("/api/cnn-analysis/history/{frame_id}")
def cnn_analysis_history_frame(frame_id: str):
    """Retrieve full analysis snapshot for an exact historical frame."""
    return environment_history_frame(frame_id=frame_id)


@app.post("/api/aquavision/analyze")
@app.post("/api/cnn-analysis/classify")
async def cnn_analysis_classify(
    file: Optional[UploadFile] = None,
    dataset_sample_path: Optional[str] = None,
):
    """Run full AquaVision-XAI analysis pipeline on an uploaded image or selected dataset sample."""
    try:
        if file is not None:
            contents = await file.read()
            if not contents:
                raise HTTPException(status_code=400, detail="Uploaded file is empty")
            pil_img = Image.open(io.BytesIO(contents)).convert("RGB")
            src_name = file.filename or "Uploaded Image"
        elif dataset_sample_path:
            full_path = (PROJECT_ROOT / dataset_sample_path).resolve()
            if not full_path.exists():
                raise HTTPException(status_code=404, detail="Dataset sample not found")
            pil_img = Image.open(full_path).convert("RGB")
            src_name = f"Dataset: {full_path.name}"
        elif manager.last_camera_image and manager.last_camera_image.exists():
            pil_img = Image.open(manager.last_camera_image).convert("RGB")
            src_name = "Latest Simulation Frame"
        else:
            arr = np.full((224, 224, 3), [18, 45, 62], dtype=np.uint8)
            pil_img = Image.fromarray(arr)
            src_name = "Synthetic Baseline"

        result = xai_engine.analyze_frame(pil_img, source_name=src_name)
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Classification failed: {e}")


@app.get("/api/aquavision/dataset-audit")
@app.get("/api/cnn-analysis/dataset-audit")
def aquavision_dataset_audit():
    """Dataset audit with target 100-sample benchmark distribution and actual class counts."""
    return xai_engine.get_dataset_audit()


_INSIDE_CNN_CACHE: Dict[str, Any] = {}

@app.get("/api/aquavision/inside-cnn/{class_name}")
def aquavision_inside_cnn(class_name: str):
    """Return hidden layer activations for representative class (Rock, Sand, Coral Reef)."""
    key = class_name.lower().strip()
    if key in _INSIDE_CNN_CACHE:
        return _INSIDE_CNN_CACHE[key]

    samples = xai_engine.get_curated_100_benchmark()
    matching = [s for s in samples if s["target_class"].lower() == key or key in s["target_class"].lower()]
    if matching:
        sample_path = PROJECT_ROOT / matching[0]["relative_path"]
        if sample_path.exists():
            im = Image.open(sample_path).convert("RGB")
            analysis = xai_engine.analyze_frame(im, source_name=f"Representative {class_name}")
            resp = {
                "ok": True,
                "class_name": class_name,
                "sample_info": matching[0],
                "cnn_activations": analysis["cnn_activations"],
                "prediction": analysis["prediction"],
                "features_21": analysis["features_21"],
                "images": analysis["images"],
            }
            _INSIDE_CNN_CACHE[key] = resp
            return resp
    if manager.latest_xai_analysis:
        return {
            "ok": True,
            "class_name": class_name,
            "cnn_activations": manager.latest_xai_analysis["cnn_activations"],
            "prediction": manager.latest_xai_analysis["prediction"],
            "features_21": manager.latest_xai_analysis["features_21"],
            "images": manager.latest_xai_analysis["images"],
        }
    return {"ok": False, "message": f"Representative sample for {class_name} not found"}


@app.post("/api/aquavision/features")
@app.post("/api/cnn-analysis/features")
async def cnn_analysis_features(
    file: Optional[UploadFile] = None,
):
    """Extract all 21 measurable image features."""
    try:
        if file is not None:
            contents = await file.read()
            if not contents:
                raise HTTPException(status_code=400, detail="Uploaded file is empty")
            pil_img = Image.open(io.BytesIO(contents)).convert("RGB")
        elif manager.last_camera_image and manager.last_camera_image.exists():
            pil_img = Image.open(manager.last_camera_image).convert("RGB")
        else:
            arr = np.full((224, 224, 3), [18, 45, 62], dtype=np.uint8)
            pil_img = Image.fromarray(arr)

        f_data = xai_engine.extract_21_features(pil_img)
        return {"ok": True, "features_21": f_data["features_list"], "feature_vector_21": f_data["feature_vector_21"]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Feature extraction failed: {e}")


@app.post("/api/aquavision/explain")
@app.post("/api/cnn-analysis/explain")
async def cnn_analysis_explain(
    target_class: Optional[str] = None,
    file: Optional[UploadFile] = None,
):
    """Compute Grad-CAM for a selected target class."""
    return await explain_target_class(target_class=target_class, file=file)


@app.post("/api/cnn-analysis/perturbation")
async def cnn_analysis_perturbation(
    file: Optional[UploadFile] = None,
):
    """Run 3x3 sliding occlusion perturbation experiment."""
    return await perturbation_experiment(file=file)


@app.get("/api/cnn-analysis/feature-validation")
def cnn_analysis_feature_validation():
    """Empirical distribution statistics comparing Rock, Sand, and Coral Reef."""
    return feature_validation()


@app.get("/api/cnn-analysis/epoch-comparison")
def cnn_analysis_epoch_comparison():
    """Compare learned intermediate activations across early vs final training epochs."""
    return epoch_comparison()