from __future__ import annotations

import asyncio
import base64
import io
import json
import math
import random
import time
from collections import deque
from pathlib import Path

import httpx
import numpy as np
from PIL import Image

from env.auv_env import UnderwaterExplorationEnv
from backend.ai_logger import ai_logger
from backend.xai_engine import xai_engine


class SimulationManager:
    """
    Main AUV simulation manager.

    Architecture:

        CoralScapes image
              |
              v
        CNN Server :8000
              |
              v
        22-class seabed prediction
              |
              v
        AUV Simulation + PPO
              |
              v
        FastAPI :8001 / WebSocket
              |
              v
        Dashboard
    """

    def __init__(self):
        # -------------------------------------------------------------
        # Project paths
        # -------------------------------------------------------------
        self.PROJECT_ROOT = Path(__file__).resolve().parents[2]
        self.AUV_ROOT = Path(__file__).resolve().parents[1]

        self.PPO_MODEL = self.AUV_ROOT / "models" / "ppo_auv.zip"
        self.CNN_MODEL = self.PROJECT_ROOT / "models" / "best_model.pth"
        self.CNN_DATASET = self.PROJECT_ROOT / "cnn_dataset" / "train"

        self.CNN_URL = "http://127.0.0.1:8000/predict"

        # -------------------------------------------------------------
        # Environment
        # -------------------------------------------------------------
        self.env = UnderwaterExplorationEnv()

        # -------------------------------------------------------------
        # Mission state
        # -------------------------------------------------------------
        self.running = False
        self.paused = True
        self.speed_multiplier = 1.0
        self.start_time = None
        self.last_tick = time.time()

        # -------------------------------------------------------------
        # History
        # -------------------------------------------------------------
        self.logs = deque(maxlen=60)
        self.reward_history = []
        self.depth_history = []
        self.obstacle_history = []

        # -------------------------------------------------------------
        # WebSocket listeners
        # -------------------------------------------------------------
        self.listeners = set()

        # -------------------------------------------------------------
        # Models
        # -------------------------------------------------------------
        self.policy = None

        # The CNN itself lives in the dedicated server on port 8000.
        self.cnn_available = False

        # -------------------------------------------------------------
        # CNN state
        # -------------------------------------------------------------
        self.cnn_result = {
            "available": False,
            "prediction": None,
            "confidence": 0.0,
            "probabilities": {},
            "source": None,
        }

        # -------------------------------------------------------------
        # CoralScapes image cache & XAI Analysis
        # -------------------------------------------------------------
        self.coral_images = []
        self._terrain_image_cache: Dict[str, List[Path]] = {"Rock": [], "Sand": [], "Coral Reef": []}
        self.last_camera_image = None
        self.last_cnn_time = 0.0
        self.cnn_interval = 1.0
        self.latest_xai_analysis: Optional[Dict[str, Any]] = None
        self._substep_accumulator = 0.0
        self._xai_in_progress = False

        # -------------------------------------------------------------
        # Load everything
        # -------------------------------------------------------------
        self._discover_coral_images()
        self._load_models()
        self._check_cnn_server()
        self._run_initial_xai_analysis()

        self.log("System initialized")

    # =================================================================
    # LOGGING
    # =================================================================

    def log(self, msg: str):
        self.logs.append(
            {
                "time": time.strftime("%H:%M:%S"),
                "message": msg,
            }
        )

    # =================================================================
    # CORALSCAPES DATASET
    # =================================================================

    def _discover_coral_images(self):
        """
        Find real CoralScapes images.

        These images act as the simulated AUV camera frames.
        No generated/dummy image is used.
        """

        if not self.CNN_DATASET.exists():
            self.log(
                f"CoralScapes dataset not found: {self.CNN_DATASET}"
            )
            return

        extensions = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}

        try:
            self.coral_images = [
                p
                for p in self.CNN_DATASET.rglob("*")
                if p.is_file() and p.suffix.lower() in extensions
            ]

            self._terrain_image_cache = {
                "Rock": [],
                "Sand": [],
                "Coral Reef": [],
            }
            coral_set = self._coral_classes()
            rock_set = self._rock_classes()
            for p in self.coral_images:
                f_low = p.parent.name.lower()
                if f_low in {"sand", "seagrass"}:
                    self._terrain_image_cache["Sand"].append(p)
                elif f_low in coral_set:
                    self._terrain_image_cache["Coral Reef"].append(p)
                elif f_low in rock_set:
                    self._terrain_image_cache["Rock"].append(p)

            self.log(
                f"CoralScapes camera images discovered: {len(self.coral_images)} "
                f"(Sand: {len(self._terrain_image_cache['Sand'])}, "
                f"Coral: {len(self._terrain_image_cache['Coral Reef'])}, "
                f"Rock: {len(self._terrain_image_cache['Rock'])})"
            )

        except Exception as e:
            self.log(f"CoralScapes image discovery failed: {e}")
            self.coral_images = []

    # =================================================================
    # MODEL LOADING
    # =================================================================

    def _load_models(self):
        """
        Load the trained PPO model.

        CNN is handled by the separate CNN FastAPI server on port 8000.
        """

        # -------------------------------------------------------------
        # PPO
        # -------------------------------------------------------------
        try:
            from stable_baselines3 import PPO

            if self.PPO_MODEL.exists():

                self.policy = PPO.load(
                    str(self.PPO_MODEL),
                    env=self.env,
                )

                self.log(
                    f"PPO policy loaded: {self.PPO_MODEL}"
                )

            else:
                self.log(
                    f"PPO model not found: {self.PPO_MODEL}"
                )

        except Exception as e:
            self.policy = None
            self.log(f"PPO load failed: {e}")

        # -------------------------------------------------------------
        # CNN model file
        # -------------------------------------------------------------
        if self.CNN_MODEL.exists():

            self.log(
                f"CoralScapes CNN checkpoint found: "
                f"{self.CNN_MODEL}"
            )

        else:

            self.log(
                f"CoralScapes CNN checkpoint not found: "
                f"{self.CNN_MODEL}"
            )

    # =================================================================
    # CNN SERVER CHECK
    # =================================================================

    def _check_cnn_server(self):
        """
        Check the real CNN inference server.

        The CNN server is:
            http://127.0.0.1:8000
        """

        try:
            import urllib.request

            with urllib.request.urlopen(
                "http://127.0.0.1:8000/health",
                timeout=3,
            ) as response:

                data = json.loads(
                    response.read().decode("utf-8")
                )

                if data.get("status") == "ok":

                    self.cnn_available = True

                    self.log(
                        "CoralScapes CNN server connected"
                    )

                else:

                    self.cnn_available = False

                    self.log(
                        "CNN server responded but status is not OK"
                    )

        except Exception as e:

            self.cnn_available = False

            self.log(
                f"CNN server unavailable: {e}"
            )

    # =================================================================
    # MISSION CONTROL
    # =================================================================

    def start(self):

        if self.policy is None:
            raise RuntimeError(
                "PPO model is required. "
                f"Expected: {self.PPO_MODEL}"
            )

        if not self.cnn_available:
            self._check_cnn_server()

        if self.start_time is None:
            self.start_time = time.time()

        self.running = True
        self.paused = False

        self.log("Mission started")
        ai_logger.log_mission_event("START", "AUV autonomous exploration mission started")

    def pause(self):

        self.paused = True

        self.log("Mission paused")
        ai_logger.log_mission_event("PAUSE", "AUV mission paused")

    def reset(self, seed=None):

        self.env.reset(
            seed=seed
            if seed is not None
            else int(time.time()) % 1_000_000
        )

        self.start_time = None
        self.running = False
        self.paused = True

        self.reward_history.clear()
        self.depth_history.clear()
        self.obstacle_history.clear()

        self.cnn_result = {
            "available": self.cnn_available,
            "prediction": None,
            "confidence": 0.0,
            "probabilities": {},
            "source": None,
        }

        self.last_camera_image = None
        self.last_cnn_time = 0.0
        self._substep_accumulator = 0.0
        self._xai_in_progress = False

        self.log(
            "Mission reset and new environment generated"
        )
        ai_logger.log_mission_event("RESET", "AUV mission reset — new seabed environment generated")

    def set_speed(self, x):

        self.speed_multiplier = float(x)

        self.log(
            f"Speed multiplier set to {x:g}x"
        )
        ai_logger.log_mission_event("SPEED", f"Speed multiplier set to {x:g}x")

    # =================================================================
    # WEBSOCKET
    # =================================================================

    def subscribe(self, q):
        self.listeners.add(q)

    def unsubscribe(self, q):
        self.listeners.discard(q)

    # =================================================================
    # CORALSCAPES CLASS MAPPING
    # =================================================================

    @staticmethod
    def _coral_classes():

        return {
            "acropora alive",
            "branching bleached",
            "branching dead",
            "massive",
            "meandering alive",
            "meandering dead",
            "millepora",
            "other coral alive",
            "other coral bleached",
            "other coral dead",
            "pocillopora alive",
            "table acropora alive",
            "table acropora dead",
            "turbinaria",
        }

    @staticmethod
    def _rock_classes():

        return {
            "rubble",
            "unknown hard substrate",
        }

    @staticmethod
    def _environment_class_from_coralscapes(
        prediction: str,
    ):
        """
        Convert only defensible CoralScapes labels into the
        AUV's three environment categories.

        Other CoralScapes classes remain unmapped rather than
        being falsely classified.
        """

        p = prediction.strip().lower()

        if p == "sand":
            return "Sand"

        if p in SimulationManager._coral_classes():
            return "Coral Reef"

        if p in SimulationManager._rock_classes():
            return "Rock"

        return None

    # =================================================================
    # CAMERA IMAGE SELECTION
    # =================================================================

    def _select_camera_image(self):

        if not self.coral_images:
            return None

        # -------------------------------------------------------------
        # Try to use current terrain class to select a semantically
        # related real CoralScapes image.
        # -------------------------------------------------------------
        try:
            x, y = map(int, self.env.pos)
            terrain_class_id = int(self.env.terrain.grid["class"][y, x])
            terrain_names = ["Rock", "Sand", "Coral Reef"]
            if 0 <= terrain_class_id < len(terrain_names):
                target = terrain_names[terrain_class_id]
                pool = self._terrain_image_cache.get(target)
                if pool:
                    return random.choice(pool)
        except Exception as e:
            self.log(f"Terrain-aware camera selection failed: {e}")

        # -------------------------------------------------------------
        # Fallback: real CoralScapes image
        # -------------------------------------------------------------
        return random.choice(self.coral_images) if self.coral_images else None

    # =================================================================
    # CNN PREDICTION
    # =================================================================

    async def _predict_camera_image(
        self,
        image_path: Path,
    ):

        if not self.cnn_available:
            return None

        if not image_path.exists():
            return None

        try:

            image_bytes = image_path.read_bytes()

            files = {
                "file": (
                    image_path.name,
                    image_bytes,
                    "image/jpeg",
                )
            }

            t0 = time.perf_counter()
            async with httpx.AsyncClient(
                timeout=15.0
            ) as client:

                response = await client.post(
                    self.CNN_URL,
                    files=files,
                )

                response.raise_for_status()

                result = response.json()
            t_ms = (time.perf_counter() - t0) * 1000.0

            prediction = result.get(
                "class"
            )

            confidence = float(
                result.get(
                    "confidence",
                    0.0,
                )
            )

            probabilities = {
                str(k): float(v)
                for k, v in result.get(
                    "all_probabilities",
                    {},
                ).items()
            }

            self.cnn_result = {
                "available": True,
                "prediction": prediction,
                "confidence": confidence,
                "probabilities": probabilities,
                "source": str(image_path.relative_to(
                    self.PROJECT_ROOT
                )),
            }

            # ---------------------------------------------------------
            # Update AUV semantic map only when the mapping is safe.
            # ---------------------------------------------------------
            environment_class = (
                self._environment_class_from_coralscapes(
                    prediction
                )
            )

            if environment_class is not None:

                class_index = {
                    "Rock": 0,
                    "Sand": 1,
                    "Coral Reef": 2,
                }[
                    environment_class
                ]

                try:

                    ix, iy = map(
                        int,
                        self.env.pos,
                    )

                    if (
                        0 <= iy < self.env.size
                        and 0 <= ix < self.env.size
                    ):

                        self.env.predicted[
                            iy,
                            ix,
                        ] = class_index

                except Exception:
                    pass

            self.log(
                f"CNN: {prediction} "
                f"({confidence * 100:.2f}%)"
            )
            ai_logger.log_cnn_prediction(
                source=str(image_path.relative_to(self.PROJECT_ROOT)),
                prediction=str(prediction),
                confidence=confidence,
                inference_time_ms=t_ms,
            )

            return result

        except Exception as e:

            self.cnn_available = False

            self.log(
                f"CNN inference failed: {e}"
            )

            return None

    # =================================================================
    # PUBLIC CNN IMAGE PREDICTION
    # =================================================================

    def predict_image(self, image):

        """
        Predict an uploaded PIL image through the real CNN server.
        """

        if not self.cnn_available:
            self._check_cnn_server()

        if not self.cnn_available:
            raise RuntimeError(
                "CNN server is not available on port 8000."
            )

        try:

            buffer = io.BytesIO()

            image.convert("RGB").save(
                buffer,
                format="JPEG",
            )

            files = {
                "file": (
                    "uploaded.jpg",
                    buffer.getvalue(),
                    "image/jpeg",
                )
            }

            import requests

            t0 = time.perf_counter()
            response = requests.post(
                self.CNN_URL,
                files=files,
                timeout=15,
            )

            response.raise_for_status()

            result = response.json()
            t_ms = (time.perf_counter() - t0) * 1000.0

            prediction = result.get(
                "class"
            )

            confidence = float(
                result.get(
                    "confidence",
                    0.0,
                )
            )

            probabilities = {
                str(k): float(v)
                for k, v in result.get(
                    "all_probabilities",
                    {},
                ).items()
            }

            self.cnn_result = {
                "available": True,
                "prediction": prediction,
                "confidence": confidence,
                "probabilities": probabilities,
                "source": "uploaded image",
            }

            environment_class = (
                self._environment_class_from_coralscapes(
                    prediction
                )
            )

            if environment_class is not None:

                class_index = {
                    "Rock": 0,
                    "Sand": 1,
                    "Coral Reef": 2,
                }[
                    environment_class
                ]

                ix, iy = map(
                    int,
                    self.env.pos,
                )

                if (
                    0 <= iy < self.env.size
                    and 0 <= ix < self.env.size
                ):

                    self.env.predicted[
                        iy,
                        ix,
                    ] = class_index

            self.log(
                f"Uploaded image CNN: "
                f"{prediction} "
                f"({confidence * 100:.2f}%)"
            )
            ai_logger.log_cnn_prediction(
                source="uploaded image",
                prediction=str(prediction),
                confidence=confidence,
                inference_time_ms=t_ms,
            )

            return result

        except Exception as e:

            raise RuntimeError(
                f"CNN prediction failed: {e}"
            ) from e

    def _run_initial_xai_analysis(self):
        """Perform initial XAI analysis on startup so the dashboard immediately has live data."""
        try:
            image_path = self._select_camera_image()
            if image_path and image_path.exists():
                self.last_camera_image = image_path
                pil_img = Image.open(image_path).convert("RGB")
            else:
                # Synthetic underwater starter frame
                arr = np.full((224, 224, 3), [18, 45, 62], dtype=np.uint8)
                pil_img = Image.fromarray(arr)

            ix = int(np.clip(self.env.pos[0], 0, self.env.size - 1))
            iy = int(np.clip(self.env.pos[1], 0, self.env.size - 1))
            cur_cls_id = int(self.env.terrain.grid["class"][iy, ix])
            class_names = ["Rock", "Sand", "Coral Reef"]
            terrain_str = class_names[cur_cls_id] if 0 <= cur_cls_id < len(class_names) else "Benthic"
            source_display = f"Live Simulation Buffer (Terrain: {terrain_str})"

            robot_telemetry = {
                "x": float(self.env.pos[0]),
                "y": float(self.env.pos[1]),
                "depth": float(self.env.depth),
                "heading": float(math.degrees(self.env.heading) % 360),
                "speed": float(self.env.speed),
            }

            analysis = xai_engine.analyze_frame(
                pil_img,
                robot_telemetry=robot_telemetry,
                source_name=source_display,
            )
            self.latest_xai_analysis = analysis
            env_class = analysis["prediction"]["environment"]
            self.cnn_result = {
                "available": True,
                "prediction": env_class,
                "confidence": analysis["prediction"]["confidence"],
                "probabilities": analysis["prediction"]["app_scores"],
                "alternative": analysis["prediction"]["alternative_environment"],
                "margin": analysis["prediction"]["margin"],
                "is_uncertain": analysis["prediction"]["is_uncertain"],
                "source": source_display,
                "frame_id": analysis["frame_id"],
                "inference_duration_ms": analysis["inference_duration_ms"],
            }
        except Exception as e:
            self.log(f"Initial XAI setup warning: {e}")

    # =================================================================
    # AUTOMATIC CAMERA + CNN & EXPLAINABLE AI
    # =================================================================

    # =================================================================
    # DECOUPLED ASYNCHRONOUS CAMERA + CNN & EXPLAINABLE AI
    # =================================================================

    def _trigger_background_xai_if_needed(self):
        """
        Trigger non-blocking background camera analysis.
        Runs independently of the physics tick loop so simulation movement
        never slows down or stutters during CNN or Grad-CAM inference.
        """
        now = time.time()
        if now - self.last_cnn_time < self.cnn_interval:
            return
        if self._xai_in_progress:
            return

        self.last_cnn_time = now
        self._xai_in_progress = True
        asyncio.create_task(self._run_async_xai_step())

    async def _run_async_xai_step(self):
        """
        Background task: run CPU-intensive CNN & XAI pipeline in a worker thread.
        """
        try:
            image_path = self._select_camera_image()
            if not image_path or not image_path.exists():
                ix = int(np.clip(self.env.pos[0], 0, self.env.size - 1))
                iy = int(np.clip(self.env.pos[1], 0, self.env.size - 1))
                terrain_id = int(self.env.terrain.grid["class"][iy, ix])
                self.env.predicted[iy, ix] = terrain_id
                return

            self.last_camera_image = image_path
            ix = int(np.clip(self.env.pos[0], 0, self.env.size - 1))
            iy = int(np.clip(self.env.pos[1], 0, self.env.size - 1))
            cur_cls_id = int(self.env.terrain.grid["class"][iy, ix])
            class_names = ["Rock", "Sand", "Coral Reef"]
            terrain_str = class_names[cur_cls_id] if 0 <= cur_cls_id < len(class_names) else "Benthic"
            source_display = f"Live Simulation Buffer (Terrain: {terrain_str})"

            robot_telemetry = {
                "x": float(self.env.pos[0]),
                "y": float(self.env.pos[1]),
                "depth": float(self.env.depth),
                "heading": float(math.degrees(self.env.heading) % 360),
                "speed": float(self.env.speed),
            }

            # Offload heavy forward/backward passes and GLCM to background thread
            analysis = await asyncio.to_thread(
                self._compute_xai_in_thread,
                image_path,
                robot_telemetry,
                source_display,
            )

            if analysis is not None:
                self.latest_xai_analysis = analysis
                env_class = analysis["prediction"]["environment"]

                ix = int(np.clip(robot_telemetry["x"], 0, self.env.size - 1))
                iy = int(np.clip(robot_telemetry["y"], 0, self.env.size - 1))
                if env_class in {"Rock", "Sand", "Coral Reef"}:
                    cls_id = {"Rock": 0, "Sand": 1, "Coral Reef": 2}[env_class]
                    self.env.predicted[iy, ix] = cls_id

                self.cnn_result = {
                    "available": True,
                    "prediction": env_class,
                    "confidence": analysis["prediction"]["confidence"],
                    "probabilities": analysis["prediction"]["app_scores"],
                    "alternative": analysis["prediction"]["alternative_environment"],
                    "margin": analysis["prediction"]["margin"],
                    "is_uncertain": analysis["prediction"]["is_uncertain"],
                    "source": source_display,
                    "frame_id": analysis["frame_id"],
                    "inference_duration_ms": analysis["inference_duration_ms"],
                }

                ai_logger.log_cnn_prediction(
                    source=source_display,
                    prediction=env_class,
                    confidence=analysis["prediction"]["confidence"],
                    inference_time_ms=analysis["inference_duration_ms"],
                )
        except Exception as e:
            self.log(f"Background camera frame analysis error: {e}")
        finally:
            self._xai_in_progress = False

    def _compute_xai_in_thread(
        self,
        image_path: Path,
        robot_telemetry: Dict[str, Any],
        source_name: str,
    ) -> Optional[Dict[str, Any]]:
        """Worker thread function: loads image and runs complete XAI pipeline."""
        try:
            pil_img = Image.open(image_path).convert("RGB")
            return xai_engine.analyze_frame(
                pil_img,
                robot_telemetry=robot_telemetry,
                source_name=source_name,
            )
        except Exception as e:
            self.log(f"XAI thread computation failed: {e}")
            return None

    def get_current_camera_frame_bytes(self) -> bytes:
        """Return raw JPEG/PNG bytes of the latest simulated camera image."""
        if self.last_camera_image and self.last_camera_image.exists():
            try:
                return self.last_camera_image.read_bytes()
            except Exception:
                pass
        arr = np.full((224, 224, 3), [18, 45, 62], dtype=np.uint8)
        pil_img = Image.fromarray(arr)
        buf = io.BytesIO()
        pil_img.save(buf, format="JPEG")
        return buf.getvalue()

    # =================================================================
    # ENVIRONMENT
    # =================================================================

    def environment(self):

        e = self.env

        return {
            "size": e.size,
            "seed": e.seed_value,
            "classes": e.terrain.grid[
                "class"
            ].tolist(),
            "heights": np.round(
                e.terrain.grid["height"],
                2,
            ).tolist(),
            "goal": e.goal.tolist(),
        }

    # =================================================================
    # STATE FOR DASHBOARD
    # =================================================================

    def _state(self):

        e = self.env

        explored = e.explored

        gt = e.terrain.grid["class"]

        counts = {
            c: int(
                (
                    (gt == i)
                    & explored
                ).sum()
            )
            for i, c in enumerate(
                [
                    "Rock",
                    "Sand",
                    "Coral Reef",
                ]
            )
        }

        total = e.size * e.size

        explored_n = int(
            explored.sum()
        )

        total_explored = max(1, explored_n)

        pct = {
            "Rock": round(counts["Rock"] / total_explored * 100, 1),
            "Sand": round(counts["Sand"] / total_explored * 100, 1),
            "Coral Reef": round(counts["Coral Reef"] / total_explored * 100, 1),
            "Unexplored": round((total - explored_n) / total * 100, 1),
        }

        obstacle = e.terrain.obstacle_distance(
            *e.pos,
            e.heading,
        )

        ix = int(np.clip(e.pos[0], 0, e.size - 1))
        iy = int(np.clip(e.pos[1], 0, e.size - 1))
        cur_cls_id = int(gt[iy, ix])
        class_names = ["Rock", "Sand", "Coral Reef"]
        current_terrain_str = class_names[cur_cls_id] if 0 <= cur_cls_id < 3 else "Rock"

        return {
            "robot": {
                "x": float(e.pos[0]),
                "y": float(e.pos[1]),
                "depth": float(e.depth),
                "speed": float(e.speed),
                "battery": float(e.battery),
                "heading": float(
                    math.degrees(
                        e.heading
                    ) % 360
                ),
                "mode":
                    "Autonomous"
                    if (
                        self.running
                        and not self.paused
                    )
                    else "Paused",
                "episode": 1,
                "step": int(
                    e.step_count
                ),
                "collisions": e.collisions,
                "current_terrain": current_terrain_str,
            },

            "dynamic": {
                "fish": np.round(
                    e.fish.pos,
                    2,
                ).tolist(),

                "explored_bits":
                    self._pack_bool(
                        explored
                    ),

                "predicted_bytes":
                    self._pack_pred(
                        e.predicted
                    ),

                "path":
                    np.round(
                        np.asarray(
                            e.path[-600:]
                        ),
                        2,
                    ).tolist(),

                "planned_path": [
                    np.round(
                        e.pos,
                        2,
                    ).tolist(),

                    np.round(
                        e.goal,
                        2,
                    ).tolist(),
                ],
            },

            "map": {
                "explored_pct":
                    float(
                        explored_n
                        / total
                        * 100
                    ),

                "class_pct": pct,
                "current_terrain": current_terrain_str,
                "distribution": {
                    "Rock": 60.0,
                    "Coral Reef": 30.0,
                    "Sand": 10.0,
                },
            },

            "sensors": {
                "depth":
                    float(e.depth),

                "obstacle_distance":
                    float(obstacle),

                "depth_history":
                    self.depth_history[
                        -300:
                    ],

                "obstacle_history":
                    self.obstacle_history[
                        -300:
                    ],
            },

            "rl": {
                "reward":
                    float(
                        e.total_reward
                    ),

                "history":
                    self.reward_history[
                        -300:
                    ],
            },

            "mission": {
                "running":
                    self.running,

                "paused":
                    self.paused,

                "elapsed":
                    float(
                        0
                        if self.start_time
                        is None
                        else
                        time.time()
                        - self.start_time
                    ),

                "speed_multiplier":
                    self.speed_multiplier,
            },

            "logs":
                list(self.logs),

            "cnn":
                self.cnn_result,

            "fusion":
                self.cnn_result,

            "xai":
                {
                    "available": self.latest_xai_analysis is not None,
                    "frame_id": self.latest_xai_analysis.get("frame_id") if self.latest_xai_analysis else None,
                    "environment": self.latest_xai_analysis.get("prediction", {}).get("environment") if self.latest_xai_analysis else None,
                    "confidence": self.latest_xai_analysis.get("prediction", {}).get("confidence") if self.latest_xai_analysis else 0.0,
                } if self.latest_xai_analysis else None,
        }

    # =================================================================
    # BINARY ENCODING
    # =================================================================

    @staticmethod
    def _pack_bool(a):

        bits = np.packbits(
            np.asarray(
                a,
                dtype=np.uint8,
            ).reshape(-1)
        )

        return base64.b64encode(
            bits.tobytes()
        ).decode("ascii")

    @staticmethod
    def _pack_pred(a):

        vals = (
            np.asarray(
                a,
                dtype=np.int8,
            ).reshape(-1)
            + 1
        ).astype(np.uint8)

        return base64.b64encode(
            vals.tobytes()
        ).decode("ascii")

    # =================================================================
    # SIMULATION TICK
    # =================================================================

    async def tick(self):

        if (
            self.running
            and not self.paused
            and self.policy is not None
        ):

            self._substep_accumulator += self.speed_multiplier
            steps_to_run = int(self._substep_accumulator)

            if steps_to_run > 0:
                self._substep_accumulator -= steps_to_run
                steps_to_run = min(steps_to_run, 10)

                for _ in range(steps_to_run):

                    # -----------------------------------------------------
                    # PPO reads the real environment observation.
                    # -----------------------------------------------------
                    obs = self.env._obs()

                    # -----------------------------------------------------
                    # PPO chooses the action.
                    # -----------------------------------------------------
                    action, _ = (
                        self.policy.predict(
                            obs,
                            deterministic=True,
                        )
                    )

                    # -----------------------------------------------------
                    # Environment executes action.
                    # -----------------------------------------------------
                    obs, rew, done, _, info = (
                        self.env.step(
                            action
                        )
                    )

                    self.reward_history.append(
                        {
                            "step": self.env.step_count,
                            "reward": float(rew),
                        }
                    )

                    self.depth_history.append(
                        {
                            "t": self.env.step_count * 0.2,
                            "v": float(self.env.depth),
                        }
                    )

                    obstacle_dist = float(
                        self.env.terrain.obstacle_distance(
                            *self.env.pos,
                            self.env.heading,
                        )
                    )

                    self.obstacle_history.append(
                        {
                            "t": self.env.step_count * 0.2,
                            "v": obstacle_dist,
                        }
                    )

                    if info.get("collision"):
                        self.log("Obstacle collision detected")
                        ai_logger.log_collision_event(
                            float(self.env.pos[0]),
                            float(self.env.pos[1]),
                            self.env.collisions,
                        )
                    elif obstacle_dist < 2.2:
                        ai_logger.log_obstacle_event(
                            obstacle_dist,
                            float(self.env.pos[0]),
                            float(self.env.pos[1]),
                        )

                    if info.get("new_tiles", 0) >= 3:
                        ai_logger.log_exploration_event(
                            int(info["new_tiles"]),
                            float(self.env.explored.mean() * 100.0),
                        )

                    # -----------------------------------------------------
                    # Non-blocking decoupled background CNN/XAI update
                    # -----------------------------------------------------
                    self._trigger_background_xai_if_needed()

                    # -----------------------------------------------------
                    # Real-Time AI Decision Logging to Backend Console
                    # -----------------------------------------------------
                    current_live_state = self._state()
                    ai_logger.log_live_step(
                        step=self.env.step_count,
                        observation=obs,
                        action=action,
                        state=current_live_state,
                        step_reward=float(rew),
                        info=info,
                    )
                    ai_logger.log_decision_summary(
                        state=current_live_state,
                        action=action,
                        step_reward=float(rew),
                    )

                    if done:
                        self.running = False
                        self.paused = True
                        self.log("Mission ended")
                        ai_logger.log_mission_event(
                            "END",
                            f"Mission ended at step {self.env.step_count} (Total Reward: {self.env.total_reward:+.2f}, Explored: {self.env.explored.mean() * 100:.1f}%)"
                        )
                        break

        # -------------------------------------------------------------
        # Broadcast lightweight state to dashboard clients.
        # -------------------------------------------------------------
        state = self._state()

        for q in list(
            self.listeners
        ):
            try:
                q.put_nowait(
                    state
                )
            except asyncio.QueueFull:
                pass

    # =================================================================
    # MAIN LOOP
    # =================================================================

    async def loop(self):

        while True:

            await self.tick()

            await asyncio.sleep(
                1 / 25
            )


# =====================================================================
# GLOBAL MANAGER
# =====================================================================

manager = SimulationManager()