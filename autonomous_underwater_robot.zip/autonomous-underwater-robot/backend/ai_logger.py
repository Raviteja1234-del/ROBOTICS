from __future__ import annotations

import math
import sys
import time
from typing import Any, Dict, List, Optional, Tuple
import numpy as np

try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass


class Colors:
    """ANSI color formatting for terminal output."""
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    
    CYAN = "\033[36m"
    BRIGHT_CYAN = "\033[96m"
    GREEN = "\033[32m"
    BRIGHT_GREEN = "\033[92m"
    YELLOW = "\033[33m"
    BRIGHT_YELLOW = "\033[93m"
    BLUE = "\033[34m"
    BRIGHT_BLUE = "\033[94m"
    MAGENTA = "\033[35m"
    BRIGHT_MAGENTA = "\033[95m"
    RED = "\033[31m"
    BRIGHT_RED = "\033[91m"
    WHITE = "\033[37m"
    BG_BLUE = "\033[44m"


def explain_action(
    observation: np.ndarray,
    action: np.ndarray,
    state: Dict[str, Any],
    info: Optional[Dict[str, Any]] = None,
    reward: float = 0.0,
) -> Tuple[str, str, Dict[str, Any]]:
    """
    Produce a human-readable interpretation and causal explanation
    of the numerical PPO action based on real environment telemetry.

    Action definitions in auv_env.py:
        action[0] = thrust  (controls speed: speed + thrust * 0.04)
        action[1] = yaw     (controls heading: heading + yaw * 0.08)
        action[2] = pitch   (controls depth: depth + pitch * 0.12)
    
    Heading convention in auv_env.py:
        pos += [cos(heading), sin(heading)] * speed * dt
        yaw > 0  => +heading (counter-clockwise / Left turn)
        yaw < 0  => -heading (clockwise / Right turn)
    """
    act = np.asarray(action, dtype=float).flatten()
    thrust = float(act[0]) if len(act) > 0 else 0.0
    yaw = float(act[1]) if len(act) > 1 else 0.0
    pitch = float(act[2]) if len(act) > 2 else 0.0

    robot = state.get("robot", {})
    sensors = state.get("sensors", {})
    obstacle_dist = float(sensors.get("obstacle_distance", 10.0))
    heading_deg = float(robot.get("heading", 0.0))
    speed = float(robot.get("speed", 0.0))
    depth = float(robot.get("depth", 12.0))

    # -------------------------------------------------------------
    # 1. Parse Thrust Component
    # -------------------------------------------------------------
    if thrust > 0.25:
        thrust_desc = "FORWARD"
        thrust_detail = f"Thrust={thrust:+.2f} (Forward Acceleration)"
    elif thrust > 0.05:
        thrust_desc = "FORWARD"
        thrust_detail = f"Thrust={thrust:+.2f} (Forward Cruise)"
    elif thrust < -0.25:
        thrust_desc = "REVERSE"
        thrust_detail = f"Thrust={thrust:+.2f} (Active Deceleration / Reverse)"
    elif thrust < -0.05:
        thrust_desc = "SLOW FORWARD"
        thrust_detail = f"Thrust={thrust:+.2f} (Gentle Braking)"
    else:
        thrust_desc = "STOP / CRUISE"
        thrust_detail = f"Thrust={thrust:+.2f} (Zero Thrust / Inertia)"

    # -------------------------------------------------------------
    # 2. Parse Yaw Component (Turning)
    # -------------------------------------------------------------
    if yaw > 0.35:
        yaw_desc = "TURN LEFT"
        yaw_detail = f"Yaw={yaw:+.2f} (Sharp Left Turn)"
    elif yaw > 0.08:
        yaw_desc = "TURN LEFT"
        yaw_detail = f"Yaw={yaw:+.2f} (Left Turn)"
    elif yaw > 0.02:
        yaw_desc = "SMALL LEFT TURN"
        yaw_detail = f"Yaw={yaw:+.2f} (Slight Left Trim)"
    elif yaw < -0.35:
        yaw_desc = "TURN RIGHT"
        yaw_detail = f"Yaw={yaw:+.2f} (Sharp Right Turn)"
    elif yaw < -0.08:
        yaw_desc = "TURN RIGHT"
        yaw_detail = f"Yaw={yaw:+.2f} (Right Turn)"
    elif yaw < -0.02:
        yaw_desc = "SMALL RIGHT TURN"
        yaw_detail = f"Yaw={yaw:+.2f} (Slight Right Trim)"
    else:
        yaw_desc = "STRAIGHT"
        yaw_detail = f"Yaw={yaw:+.2f} (Maintain Heading)"

    # -------------------------------------------------------------
    # 3. Parse Pitch Component (Depth)
    # -------------------------------------------------------------
    if pitch > 0.2:
        pitch_detail = f"Pitch={pitch:+.2f} (Dive / Descend)"
    elif pitch < -0.2:
        pitch_detail = f"Pitch={pitch:+.2f} (Ascend / Surface)"
    else:
        pitch_detail = f"Pitch={pitch:+.2f} (Level Depth)"

    # -------------------------------------------------------------
    # 4. Synthesize Combined Movement Decision
    # -------------------------------------------------------------
    if yaw_desc == "STRAIGHT":
        decision = thrust_desc
    else:
        decision = f"{thrust_desc} + {yaw_desc}"

    # -------------------------------------------------------------
    # 5. Formulate Causal Reason based on Real Environment State
    # -------------------------------------------------------------
    reasons = []
    
    # Check obstacle closeness
    if obstacle_dist < 2.0:
        if "LEFT" in yaw_desc:
            reasons.append(
                f"Obstacle detected in close proximity ({obstacle_dist:.2f} m). "
                f"The policy applied a positive yaw ({yaw:+.2f}) to steer left around the obstacle while maintaining forward momentum."
            )
        elif "RIGHT" in yaw_desc:
            reasons.append(
                f"Obstacle detected in close proximity ({obstacle_dist:.2f} m). "
                f"The policy applied a negative yaw ({yaw:+.2f}) to steer right away from the obstruction."
            )
        else:
            reasons.append(
                f"Obstacle detected ({obstacle_dist:.2f} m). The policy maintains forward movement while aligning sensor orientation."
            )
    elif obstacle_dist < 4.0 and yaw_desc != "STRAIGHT":
        turn_dir = "left" if "LEFT" in yaw_desc else "right"
        reasons.append(
            f"Sonar indicates bathymetric obstacle within {obstacle_dist:.2f} m. "
            f"Policy initiated preemptive {turn_dir} steering ({yaw:+.2f}) to navigate open water."
        )
    elif info and info.get("new_tiles", 0) > 0:
        new_cnt = info.get("new_tiles")
        reasons.append(
            f"AUV is mapping previously unexplored seabed grid cells (+{new_cnt} new tiles). "
            f"Policy sustains forward thrust ({thrust:+.2f}) to expand survey coverage."
        )
    elif info and info.get("distance_to_goal") is not None:
        dist_g = info.get("distance_to_goal")
        reasons.append(
            f"Policy selected thrust={thrust:+.2f}, yaw={yaw:+.2f} advancing toward exploration waypoint (distance: {dist_g:.1f} m)."
        )
    else:
        reasons.append(
            f"Policy generated thrust={thrust:+.2f}, yaw={yaw:+.2f} based on 48-dimensional observation vector (sonar sensors + local 5x5 occupancy grid)."
        )

    reason_str = " ".join(reasons)

    details = {
        "thrust_desc": thrust_desc,
        "thrust_detail": thrust_detail,
        "yaw_desc": yaw_desc,
        "yaw_detail": yaw_detail,
        "pitch_detail": pitch_detail,
        "thrust": thrust,
        "yaw": yaw,
        "pitch": pitch,
        "obstacle_dist": obstacle_dist,
        "heading_deg": heading_deg,
        "speed": speed,
        "depth": depth,
    }

    return decision, reason_str, details


class AIDecisionLogger:
    """
    Professional real-time AI decision logger for the AUV backend console.
    Logs comprehensive state, CNN classifications, PPO inferences, and critical mission events.
    """

    def __init__(self, log_interval_sec: float = 0.8, summary_interval_sec: float = 6.0):
        self.log_interval_sec = log_interval_sec
        self.summary_interval_sec = summary_interval_sec
        
        self.last_full_log_time = 0.0
        self.last_summary_log_time = 0.0
        self.last_cnn_log_time = 0.0
        self.last_logged_prediction = None
        self.last_obstacle_warning_time = 0.0
        
        self.total_steps_logged = 0

    # =============================================================
    # FULL LIVE AI DECISION LOG BLOCK
    # =============================================================

    def log_live_step(
        self,
        step: int,
        observation: np.ndarray,
        action: np.ndarray,
        state: Dict[str, Any],
        step_reward: float,
        info: Optional[Dict[str, Any]] = None,
        force: bool = False,
    ):
        """
        Print the comprehensive LIVE AI LOG block to terminal if interval has elapsed.
        """
        now = time.time()
        if not force and (now - self.last_full_log_time < self.log_interval_sec):
            return

        self.last_full_log_time = now
        self.total_steps_logged += 1

        robot = state.get("robot", {})
        sensors = state.get("sensors", {})
        map_data = state.get("map", {})
        mission = state.get("mission", {})
        cnn = state.get("cnn", {})
        rl = state.get("rl", {})

        x = float(robot.get("x", 0.0))
        y = float(robot.get("y", 0.0))
        depth = float(robot.get("depth", 0.0))
        speed = float(robot.get("speed", 0.0))
        heading = float(robot.get("heading", 0.0))
        battery = float(robot.get("battery", 100.0))
        obstacle = float(sensors.get("obstacle_distance", 0.0))
        explored_pct = float(map_data.get("explored_pct", 0.0))

        # CNN details
        cnn_pred = cnn.get("prediction") or "ROCK"
        cnn_conf = float(cnn.get("confidence", 0.0)) * 100.0
        cnn_src = cnn.get("source") or "Live Camera Frame"

        # Action & Explanation
        decision, reason, details = explain_action(
            observation, action, state, info, step_reward
        )
        act = np.asarray(action, dtype=float).flatten()
        thrust = float(act[0]) if len(act) > 0 else 0.0
        yaw = float(act[1]) if len(act) > 1 else 0.0
        pitch = float(act[2]) if len(act) > 2 else 0.0

        # Reward stats
        total_rew = float(rl.get("reward", 0.0))
        new_tiles = info.get("new_tiles", 0) if info else 0
        collision = bool(info.get("collision", False)) if info else False

        # Status
        running_str = "RUNNING" if mission.get("running") and not mission.get("paused") else ("PAUSED" if mission.get("paused") else "STOPPED")
        speed_mult = float(mission.get("speed_multiplier", 1.0))
        episode = int(robot.get("episode", 1))

        # Build clean formatted block
        lines = [
            f"{Colors.BOLD}{Colors.BRIGHT_CYAN}============================================================{Colors.RESET}",
            f"{Colors.BOLD}{Colors.BRIGHT_CYAN}AUV AUTONOMOUS MISSION - LIVE AI LOG{Colors.RESET}",
            f"{Colors.BOLD}{Colors.BRIGHT_CYAN}============================================================{Colors.RESET}",
            f"",
            f"{Colors.BOLD}STEP:{Colors.RESET} {Colors.BRIGHT_YELLOW}{step}{Colors.RESET}",
            f"",
            f"{Colors.BOLD}{Colors.WHITE}ROBOT STATE{Colors.RESET}",
            f"Position       : X={x:.2f} Y={y:.2f}",
            f"Depth          : {depth:.2f} m",
            f"Speed          : {speed:.2f} m/s",
            f"Heading        : {heading:.1f}°",
            f"Battery        : {battery:.1f}%",
            f"Obstacle Dist. : {obstacle:.2f} m",
            f"Explored       : {explored_pct:.1f}%",
            f"",
            f"{Colors.DIM}------------------------------------------------------------{Colors.RESET}",
            f"{Colors.BOLD}{Colors.BRIGHT_MAGENTA}CNN CLASSIFICATION{Colors.RESET}",
            f"{Colors.DIM}------------------------------------------------------------{Colors.RESET}",
            f"Terrain        : {Colors.BOLD}{Colors.MAGENTA}{cnn_pred.upper()}{Colors.RESET}",
            f"Confidence     : {cnn_conf:.1f}%",
            f"Source         : {cnn_src}",
            f"",
            f"{Colors.DIM}------------------------------------------------------------{Colors.RESET}",
            f"{Colors.BOLD}{Colors.BRIGHT_GREEN}PPO DECISION{Colors.RESET}",
            f"{Colors.DIM}------------------------------------------------------------{Colors.RESET}",
            f"Raw Action     : [{thrust:+.3f}, {yaw:+.3f}, {pitch:+.3f}]",
            f"Action[0]      : {thrust:+.3f} (Thrust)",
            f"Action[1]      : {yaw:+.3f} (Yaw)",
            f"Action[2]      : {pitch:+.3f} (Pitch)",
            f"Thrust         : {details['thrust_detail']}",
            f"Yaw            : {details['yaw_detail']}",
            f"Pitch          : {details['pitch_detail']}",
            f"",
            f"{Colors.DIM}------------------------------------------------------------{Colors.RESET}",
            f"{Colors.BOLD}{Colors.BRIGHT_YELLOW}MOVEMENT DECISION{Colors.RESET}",
            f"{Colors.DIM}------------------------------------------------------------{Colors.RESET}",
            f"{Colors.BOLD}{Colors.BRIGHT_GREEN}{decision}{Colors.RESET}",
            f"",
            f"{Colors.DIM}------------------------------------------------------------{Colors.RESET}",
            f"{Colors.BOLD}{Colors.CYAN}WHY THIS ACTION?{Colors.RESET}",
            f"{Colors.DIM}------------------------------------------------------------{Colors.RESET}",
            f"Obstacle dist. : {obstacle:.2f} m",
            f"Current heading: {heading:.1f}°",
            f"Yaw action     : {yaw:+.2f}",
            f"Speed action   : {thrust:+.2f}",
            f"",
            f"{Colors.BOLD}Decision:{Colors.RESET} {decision}",
            f"{Colors.BOLD}Reason:{Colors.RESET}   {reason}",
            f"",
            f"{Colors.DIM}------------------------------------------------------------{Colors.RESET}",
            f"{Colors.BOLD}{Colors.BRIGHT_YELLOW}REWARD{Colors.RESET}",
            f"{Colors.DIM}------------------------------------------------------------{Colors.RESET}",
            f"Step Reward    : {Colors.BOLD}{step_reward:+.3f}{Colors.RESET}",
            f"Episode Reward : {total_rew:+.2f}",
            f"Cumulative     : {total_rew:+.2f}",
        ]

        # Reward Breakdown
        breakdown_items = []
        if new_tiles > 0:
            breakdown_items.append(f"New area explored (+{new_tiles} tiles: +{new_tiles * 0.08:.2f})")
        if collision:
            breakdown_items.append("Collision penalty (-4.00)")
        if speed > 0.01:
            breakdown_items.append(f"Speed cost (-{speed * 0.002:.4f})")
        if battery < 99.9:
            breakdown_items.append(f"Battery penalty (-{(100 - battery) * 0.0002:.4f})")
        if not breakdown_items:
            breakdown_items.append("Normal exploration survey")
        
        lines.append(f"Reward Reason  : {', '.join(breakdown_items)}")
        lines.extend([
            f"",
            f"{Colors.DIM}------------------------------------------------------------{Colors.RESET}",
            f"{Colors.BOLD}{Colors.WHITE}MISSION STATUS{Colors.RESET}",
            f"{Colors.DIM}------------------------------------------------------------{Colors.RESET}",
            f"Episode        : {episode}",
            f"Step           : {step}",
            f"Mission        : {Colors.BOLD}{running_str}{Colors.RESET}",
            f"Speed Multiplier: {speed_mult:g}x",
            f"{Colors.BOLD}{Colors.BRIGHT_CYAN}============================================================{Colors.RESET}",
            f"",
        ])

        print("\n".join(lines), flush=True)

    # =============================================================
    # PERIODIC AI DECISION SUMMARY
    # =============================================================

    def log_decision_summary(self, state: Dict[str, Any], action: np.ndarray, step_reward: float):
        """
        Periodically print the compact AI DECISION SUMMARY block.
        """
        now = time.time()
        if now - self.last_summary_log_time < self.summary_interval_sec:
            return

        self.last_summary_log_time = now

        robot = state.get("robot", {})
        sensors = state.get("sensors", {})
        map_data = state.get("map", {})
        cnn = state.get("cnn", {})

        cnn_pred = cnn.get("prediction") or "ROCK"
        cnn_conf = float(cnn.get("confidence", 0.0)) * 100.0

        act = np.asarray(action, dtype=float).flatten()
        thrust = float(act[0]) if len(act) > 0 else 0.0
        yaw = float(act[1]) if len(act) > 1 else 0.0

        speed = float(robot.get("speed", 0.0))
        heading = float(robot.get("heading", 0.0))
        obstacle = float(sensors.get("obstacle_distance", 0.0))
        explored = float(map_data.get("explored_pct", 0.0))

        decision, _, _ = explain_action(np.zeros(48), action, state, reward=step_reward)

        lines = [
            f"{Colors.BOLD}{Colors.BRIGHT_CYAN}============================================================{Colors.RESET}",
            f"{Colors.BOLD}{Colors.BRIGHT_CYAN}AI DECISION SUMMARY{Colors.RESET}",
            f"{Colors.BOLD}{Colors.BRIGHT_CYAN}============================================================{Colors.RESET}",
            f"",
            f"{Colors.BOLD}{Colors.MAGENTA}CNN:{Colors.RESET}",
            f"Terrain      = {cnn_pred.upper()}",
            f"Confidence   = {cnn_conf:.1f}%",
            f"",
            f"{Colors.BOLD}{Colors.GREEN}PPO:{Colors.RESET}",
            f"Thrust       = {thrust:+.2f}",
            f"Yaw          = {yaw:+.2f}",
            f"",
            f"{Colors.BOLD}{Colors.WHITE}Robot:{Colors.RESET}",
            f"Speed        = {speed:.2f} m/s",
            f"Heading      = {heading:.1f}°",
            f"Obstacle     = {obstacle:.2f} m",
            f"",
            f"{Colors.BOLD}Decision:{Colors.RESET}   {Colors.BRIGHT_GREEN}{decision}{Colors.RESET}",
            f"{Colors.BOLD}Reward:{Colors.RESET}     {step_reward:+.2f}",
            f"{Colors.BOLD}Exploration:{Colors.RESET} {explored:.1f}%",
            f"{Colors.BOLD}{Colors.BRIGHT_CYAN}============================================================{Colors.RESET}",
            f"",
        ]
        print("\n".join(lines), flush=True)

    # =============================================================
    # IMMEDIATE EVENT LOGGERS
    # =============================================================

    def log_mission_event(self, event_type: str, message: str):
        """
        Log mission events like start, pause, reset, speed changes.
        """
        tag = f"{Colors.BOLD}{Colors.BRIGHT_CYAN}[MISSION]{Colors.RESET}"
        print(f"{tag} {message}", flush=True)

    def log_cnn_prediction(self, source: str, prediction: str, confidence: float, inference_time_ms: float = 0.0):
        """
        Log real CNN prediction event.
        """
        tag = f"{Colors.BOLD}{Colors.BRIGHT_MAGENTA}[CNN]{Colors.RESET}"
        conf_pct = confidence * 100.0 if confidence <= 1.0 else confidence
        time_str = f" | Time: {inference_time_ms:.1f} ms" if inference_time_ms > 0 else ""
        print(f"{tag} Image Source: {source} | Prediction: {Colors.BOLD}{prediction.upper()}{Colors.RESET} | Confidence: {conf_pct:.1f}%{time_str}", flush=True)

    def log_ppo_action(self, obs: np.ndarray, action: np.ndarray, step: int):
        """
        Log specific PPO step action details.
        """
        act = np.asarray(action, dtype=float).flatten()
        thrust = float(act[0]) if len(act) > 0 else 0.0
        yaw = float(act[1]) if len(act) > 1 else 0.0
        pitch = float(act[2]) if len(act) > 2 else 0.0

        yaw_direction = "Turn Left" if yaw > 0.05 else ("Turn Right" if yaw < -0.05 else "Straight")
        tag = f"{Colors.BOLD}{Colors.BRIGHT_GREEN}[PPO]{Colors.RESET}"
        print(f"{tag} Step {step} | Action: [Thrust={thrust:+.2f}, Yaw={yaw:+.2f}, Pitch={pitch:+.2f}] -> {yaw_direction}", flush=True)

    def log_obstacle_event(self, distance: float, x: float, y: float):
        """
        Log obstacle proximity warning.
        """
        now = time.time()
        if now - self.last_obstacle_warning_time < 1.5:
            return
        self.last_obstacle_warning_time = now
        tag = f"{Colors.BOLD}{Colors.BRIGHT_YELLOW}[OBSTACLE]{Colors.RESET}"
        print(f"{tag} Obstacle detected within {distance:.2f} m at X={x:.1f}, Y={y:.1f}!", flush=True)

    def log_collision_event(self, x: float, y: float, total_collisions: int):
        """
        Log boundary collision event.
        """
        tag = f"{Colors.BOLD}{Colors.BRIGHT_RED}[COLLISION]{Colors.RESET}"
        print(f"{tag} Boundary collision detected at X={x:.1f}, Y={y:.1f}! (Total: {total_collisions})", flush=True)

    def log_exploration_event(self, new_tiles: int, explored_pct: float):
        """
        Log discovery of new seabed tiles.
        """
        tag = f"{Colors.BOLD}{Colors.BRIGHT_BLUE}[EXPLORATION]{Colors.RESET}"
        print(f"{tag} New region discovered: +{new_tiles} tiles (Total Explored: {explored_pct:.1f}%)", flush=True)


# Global AI Decision Logger Instance
ai_logger = AIDecisionLogger()
