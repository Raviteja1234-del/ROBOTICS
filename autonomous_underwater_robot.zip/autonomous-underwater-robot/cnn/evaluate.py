from __future__ import annotations

# Allow direct execution such as: python cnn/train_cnn.py from the project root.
import sys
from pathlib import Path as _BootstrapPath
_PROJECT_ROOT = _BootstrapPath(__file__).resolve().parents[1]
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))
import argparse, json
from pathlib import Path
import pandas as pd, torch
from torch.utils.data import DataLoader
from sklearn.metrics import accuracy_score,precision_recall_fscore_support,confusion_matrix
from cnn.model import build_model, CLASS_NAMES
from cnn.train_cnn import ManifestDataset

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--data',default='data/splits'); ap.add_argument('--weights',default='models/cnn_seabed.pt'); args=ap.parse_args()
    if not Path(args.weights).exists(): raise SystemExit('CNN weights not found. Complete the approved training phase first.')
    device='cuda' if torch.cuda.is_available() else 'mps' if torch.backends.mps.is_available() else 'cpu'; model=build_model(False); model.load_state_dict(torch.load(args.weights,map_location=device,weights_only=True)); model.to(device).eval()
    ds=ManifestDataset(Path(args.data)/'test.csv',False); dl=DataLoader(ds,32,shuffle=False); ys=[]; ps=[]
    with torch.inference_mode():
        for x,y in dl: ps.extend(model(x.to(device)).argmax(1).cpu().tolist()); ys.extend(y.tolist())
    p,r,f,_=precision_recall_fscore_support(ys,ps,labels=list(range(3)),zero_division=0)
    out={'accuracy':accuracy_score(ys,ps),'precision':dict(zip(CLASS_NAMES,p)),'recall':dict(zip(CLASS_NAMES,r)),'f1':dict(zip(CLASS_NAMES,f)),'confusion_matrix':confusion_matrix(ys,ps,labels=list(range(3))).tolist()}
    Path('cnn/reports').mkdir(exist_ok=True); json.dump(out,open('cnn/reports/evaluation.json','w'),indent=2); print(json.dumps(out,indent=2))
if __name__=='__main__': main()
