from __future__ import annotations
import torch
from PIL import Image
from torchvision import transforms
from .model import build_model, CLASS_NAMES

_transform=transforms.Compose([transforms.Resize((224,224)),transforms.ToTensor(),transforms.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225])])

def load_predictor(weights_path, device=None):
    device=device or ('cuda' if torch.cuda.is_available() else 'mps' if torch.backends.mps.is_available() else 'cpu')
    model=build_model(pretrained=False)
    state=torch.load(weights_path,map_location=device,weights_only=True)
    if isinstance(state, dict):
        state = {k: v.float() if torch.is_tensor(v) and v.is_floating_point() else v for k, v in state.items()}
    model.load_state_dict(state)
    model.eval().to(device)
    def predict(image):
        if not isinstance(image,Image.Image): image=Image.open(image).convert('RGB')
        with torch.inference_mode():
            logits=model(_transform(image).unsqueeze(0).to(device)); probs=torch.softmax(logits,dim=1)[0]
        vals=probs.detach().cpu().tolist(); out={c:float(v) for c,v in zip(CLASS_NAMES,vals)}
        out['prediction']=CLASS_NAMES[int(torch.argmax(probs))]
        return out
    return predict
