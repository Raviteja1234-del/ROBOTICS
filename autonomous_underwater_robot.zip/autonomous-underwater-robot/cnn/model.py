from __future__ import annotations
import torch
from torch import nn
from torchvision.models import resnet18, ResNet18_Weights

CLASS_NAMES = ['Rock','Sand','Coral Reef']

def build_model(pretrained=True):
    weights = ResNet18_Weights.DEFAULT if pretrained else None
    model = resnet18(weights=weights)
    model.fc = nn.Linear(model.fc.in_features, len(CLASS_NAMES))
    return model
