"""Train the real three-class seabed CNN.

The normal one-command workflow is:
    python cnn/train_cnn.py --root "C:\\Datasets\\BenthicNet" --approve --epochs 8

--approve is an explicit user consent flag. When supplied, this script:
1. inspects the supplied BenthicNet tree;
2. records the inspection report and proposed mapping;
3. prepares a source/site-aware 70/15/15 split;
4. trains ResNet18;
5. saves the best validation checkpoint and training history.

No images, labels, probabilities, or metrics are fabricated.
"""
from __future__ import annotations

# Allow direct execution such as: python cnn/train_cnn.py from the project root.
import sys
from pathlib import Path as _BootstrapPath
_PROJECT_ROOT = _BootstrapPath(__file__).resolve().parents[1]
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

import argparse
import json
import random
from pathlib import Path

import pandas as pd
import torch
from PIL import Image
from torch import nn
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms

from cnn.model import CLASS_NAMES, build_model
from data.inspect_benthicnet import inspect
from data.prepare_dataset import prepare_dataset


class ManifestDataset(Dataset):
    def __init__(self, csv_path: Path, train: bool = False):
        self.df = pd.read_csv(csv_path)
        self.train = train
        self.label = {c: i for i, c in enumerate(CLASS_NAMES)}

        if train:
            aug = [
                transforms.Resize((256, 256)),
                transforms.RandomResizedCrop(224, scale=(0.75, 1.0)),
                transforms.RandomHorizontalFlip(),
                transforms.RandomVerticalFlip(),
                transforms.RandomRotation(15),
                transforms.ColorJitter(brightness=0.25, contrast=0.25, saturation=0.2, hue=0.05),
                transforms.RandomApply([transforms.GaussianBlur(kernel_size=3)], p=0.15),
                transforms.ToTensor(),
            ]
        else:
            aug = [
                transforms.Resize((224, 224)),
                transforms.ToTensor(),
            ]

        self.tf = transforms.Compose(
            aug
            + [transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])]
        )

    def __len__(self):
        return len(self.df)

    def __getitem__(self, index):
        row = self.df.iloc[index]
        with Image.open(row.path) as image:
            image = image.convert("RGB")
        return self.tf(image), self.label[row.label]


def _device() -> torch.device:
    if torch.cuda.is_available():
        return torch.device("cuda")
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def _save_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, default=str), encoding="utf-8")


def train(data_dir: Path, epochs: int, batch_size: int, lr: float, seed: int) -> dict:
    random.seed(seed)
    torch.manual_seed(seed)

    device = _device()
    print(f"Training device: {device}")

    train_ds = ManifestDataset(data_dir / "train.csv", train=True)
    val_ds = ManifestDataset(data_dir / "val.csv", train=False)

    if not len(train_ds) or not len(val_ds):
        raise SystemExit("Train/validation manifest is empty. Check the BenthicNet mapping and split.")

    train_loader = DataLoader(
        train_ds,
        batch_size=batch_size,
        shuffle=True,
        num_workers=0,
        pin_memory=device.type == "cuda",
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=batch_size,
        shuffle=False,
        num_workers=0,
        pin_memory=device.type == "cuda",
    )

    model = build_model(pretrained=True).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    loss_fn = nn.CrossEntropyLoss()

    use_amp = device.type == "cuda"
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp)

    best_val = -1.0
    history = []
    checkpoint = Path("models/cnn_seabed.pt")
    checkpoint.parent.mkdir(parents=True, exist_ok=True)

    for epoch in range(epochs):
        model.train()
        total = correct = 0
        loss_sum = 0.0

        for x, y in train_loader:
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad(set_to_none=True)

            with torch.autocast(device_type="cuda", enabled=use_amp):
                logits = model(x)
                loss = loss_fn(logits, y)

            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            loss_sum += loss.item() * len(y)
            total += len(y)
            correct += (logits.argmax(1) == y).sum().item()

        model.eval()
        val_total = val_correct = 0
        val_loss_sum = 0.0
        with torch.inference_mode():
            for x, y in val_loader:
                x, y = x.to(device), y.to(device)
                logits = model(x)
                loss = loss_fn(logits, y)
                val_loss_sum += loss.item() * len(y)
                val_total += len(y)
                val_correct += (logits.argmax(1) == y).sum().item()

        record = {
            "epoch": epoch + 1,
            "train_loss": loss_sum / total,
            "train_accuracy": correct / total,
            "val_loss": val_loss_sum / val_total,
            "val_accuracy": val_correct / val_total,
            "device": str(device),
        }
        history.append(record)
        print(json.dumps(record))

        if record["val_accuracy"] > best_val:
            best_val = record["val_accuracy"]
            torch.save(model.state_dict(), checkpoint)

    report_dir = Path("cnn/reports")
    _save_json(report_dir / "training_history.json", history)
    summary = {
        "checkpoint": str(checkpoint),
        "best_validation_accuracy": best_val,
        "epochs": epochs,
        "batch_size": batch_size,
        "learning_rate": lr,
        "device": str(device),
        "train_images": len(train_ds),
        "validation_images": len(val_ds),
    }
    _save_json(report_dir / "training_summary.json", summary)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description="Inspect, approve, prepare and train the BenthicNet CNN in one command.")
    parser.add_argument("--root", required=True, help="Path to the local BenthicNet dataset")
    parser.add_argument("--approve", action="store_true", help="Explicitly approve the proposed mapping and start training")
    parser.add_argument("--mapping", default="data/label_mapping.yaml")
    parser.add_argument("--data", default="data/splits")
    parser.add_argument("--epochs", type=int, default=8)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--seed", type=int, default=12345)
    args = parser.parse_args()

    if not args.approve:
        raise SystemExit(
            "Training is protected. Review the proposed mapping first, then rerun this same command with --approve."
        )

    root = Path(args.root).expanduser().resolve()
    mapping = Path(args.mapping)
    if not root.exists():
        raise SystemExit(f"BenthicNet path does not exist: {root}")

    print("=== BENTHICNET INSPECTION ===")
    inspection = inspect(root, mapping)
    _save_json(Path(args.data) / "benthicnet_inspection.json", inspection)
    print(json.dumps(inspection, indent=2, default=str))

    print("\n=== EXPLICIT APPROVAL ===")
    print("--approve supplied: the proposed label mapping is approved for this run.")
    _save_json(
        Path(args.data) / "approval.json",
        {
            "approved": True,
            "root": str(root),
            "mapping": str(mapping.resolve()),
            "approval_method": "explicit --approve command-line flag",
        },
    )

    print("\n=== DATASET PREPARATION ===")
    summary = prepare_dataset(root, mapping, Path(args.data), seed=args.seed)
    print(json.dumps(summary, indent=2))

    print("\n=== CNN TRAINING ===")
    result = train(Path(args.data), args.epochs, args.batch_size, args.lr, args.seed)
    print("\n=== TRAINING COMPLETE ===")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
