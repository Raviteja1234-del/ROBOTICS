import pathlib
from PIL import Image
from backend.xai_engine import xai_engine, DATASET_TRAIN_DIR

print('Model loaded:', xai_engine.is_loaded)
print('Status:', xai_engine.checkpoint_status)

for cls_folder in ['sand', 'acropora alive', 'rubble', 'background']:
    folder = DATASET_TRAIN_DIR / cls_folder
    if folder.exists():
        imgs = list(folder.glob('*.jpg'))
        if imgs:
            sample_img = imgs[0]
            im = Image.open(sample_img).convert('RGB')
            res = xai_engine.analyze_frame(im, source_name=str(sample_img.name))
            pred = res['prediction']
            print(f"Folder: {cls_folder:<20} -> Top: {pred['environment']:<15} Conf: {pred['confidence']:.3f} Scores: {pred['app_scores']}")
