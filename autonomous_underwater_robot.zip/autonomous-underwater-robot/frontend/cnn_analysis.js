// AquaVision-XAI: Real-Time Underwater Seabed Classification, 21-Feature Analysis & Explainable AI
(() => {
  "use strict";

  const $ = id => document.getElementById(id);

  // App State
  let currentFrameData = null;
  let isLiveStreaming = true;
  let pollIntervalId = null;
  let isFetchingLive = false;
  let selectedStageIndex = 0;
  let activeFeatureFilter = "all";
  let activeBenchmarkFilter = "all";
  let benchmarkSamplesCache = [];
  let currentTargetClass = null;
  let selectedInsideCnnRep = "live";
  let lastRenderedFrameId = null;

  // Four Target Application Classes
  const APP_CLASSES = ["Rock", "Sand", "Coral Reef", "Other / Unknown"];

  // Helper: Ensure valid data URL / URI for images
  function toDataUrl(val) {
    if (!val || typeof val !== "string") return "";
    val = val.trim();
    if (val.startsWith("data:image/") || val.startsWith("http://") || val.startsWith("https://") || val.startsWith("/")) {
      return val;
    }
    return `data:image/png;base64,${val}`;
  }

  // Helper: Clean up raw filesystem paths in labels
  function cleanSourceLabel(sourceStr) {
    if (!sourceStr) return "Simulation Camera Buffer";
    let s = String(sourceStr).trim();
    if (s.includes("\\") || s.includes("/") || s.includes("cnn_dataset")) {
      const parts = s.split(/[\\/]/).filter(Boolean);
      const folder = parts.length > 1 ? parts[parts.length - 2] : parts[0];
      return `Live Simulation Buffer (${folder})`;
    }
    return s;
  }

  // Helper: Format spec values cleanly without [object Object]
  function formatSpecValue(val) {
    if (val === null || val === undefined) return "—";
    if (typeof val === "boolean") return val ? "True" : "False";
    if (typeof val === "object") {
      if (Array.isArray(val)) {
        return "[" + val.map(x => (typeof x === "number" ? Number(x).toFixed(3) : x)).join(", ") + "]";
      }
      return Object.entries(val)
        .map(([k, v]) => `${k}: ${typeof v === "number" ? (v > 1 ? v.toFixed(1) : (v * 100).toFixed(1) + "%") : v}`)
        .join(" | ");
    }
    if (typeof val === "number") {
      return Number.isInteger(val) ? val.toString() : val.toFixed(4);
    }
    return String(val);
  }

  // Helper: Parse score safely without NaN%
  function parseScorePct(panelData) {
    if (!panelData) return "0.0%";
    if (typeof panelData.score === "number") {
      return `${(panelData.score * 100).toFixed(1)}%`;
    }
    if (panelData.score_pct) {
      const num = parseFloat(panelData.score_pct);
      if (!isNaN(num)) return `${num.toFixed(1)}%`;
    }
    return "0.0%";
  }

  // Helper: Render diagnostic features list
  function renderDiagFeaturesList(container, panelData) {
    if (!container || !panelData) return;
    if (Array.isArray(panelData.key_features) && panelData.key_features.length > 0) {
      container.innerHTML = panelData.key_features.slice(0, 3).map(f => `
        <li class="diag-item">
          <span>${f.name}:</span>
          <b class="${f.aligns ? 'text-success' : ''}">${Number(f.val || 0).toFixed(2)}</b>
        </li>
      `).join("");
      return;
    }
    const kfd = panelData.key_features_dict || panelData.key_features || {};
    const entries = Object.entries(kfd).slice(0, 3);
    if (entries.length > 0) {
      container.innerHTML = entries.map(([k, v]) => `
        <li class="diag-item">
          <span>${k.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}:</span>
          <b>${Number(v || 0).toFixed(2)}</b>
        </li>
      `).join("");
    }
  }

  // ============================================================
  // 1. INITIALIZATION
  // ============================================================
  function init() {
    initNavigation();
    initControls();
    initFeatureFilters();
    initInsideCnnControls();
    initGradcamTargets();
    initBenchmarkModal();

    // Initial Data Fetches
    fetchDatasetAudit();
    fetchPredictionHistory();
    fetchLiveFrame(true);

    // Controlled live polling: 2.5s interval
    startLivePolling(2500);
  }

  // ============================================================
  // 2. STICKY QUICK NAVIGATION
  // ============================================================
  function initNavigation() {
    const pills = document.querySelectorAll(".nav-pill");
    pills.forEach(pill => {
      pill.addEventListener("click", e => {
        pills.forEach(p => p.classList.remove("active"));
        pill.classList.add("active");
      });
    });

    // Update active nav pill on scroll
    window.addEventListener("scroll", () => {
      const sections = document.querySelectorAll(".aqua-section");
      let currentSecId = "";
      sections.forEach(sec => {
        const top = sec.offsetTop - 120;
        if (window.scrollY >= top) {
          currentSecId = sec.getAttribute("id");
        }
      });
      if (currentSecId) {
        pills.forEach(pill => {
          if (pill.getAttribute("href") === `#${currentSecId}`) {
            pill.classList.add("active");
          } else {
            pill.classList.remove("active");
          }
        });
      }
    }, { passive: true });
  }

  // ============================================================
  // 3. WORKSPACE CONTROLS & POLLING (ZERO RELOADS)
  // ============================================================
  function initControls() {
    // Live toggle
    $("btnToggleLive")?.addEventListener("click", () => {
      isLiveStreaming = !isLiveStreaming;
      updateLiveUi();
    });

    // Fetch latest simulation frame
    $("btnFetchLatest")?.addEventListener("click", () => {
      fetchLiveFrame(true);
    });

    // File upload
    const uploadInput = $("fileUploadInput");
    $("btnUploadImage")?.addEventListener("click", () => {
      uploadInput?.click();
    });

    uploadInput?.addEventListener("change", async e => {
      const file = e.target.files?.[0];
      if (!file) return;
      uploadCustomImage(file);
      uploadInput.value = "";
    });

    // Timeline refresh
    $("btnRefreshHistory")?.addEventListener("click", () => {
      fetchPredictionHistory();
    });

    // Theme toggle (Default: White / Light Theme)
    const themeBtn = $("btnThemeToggle");
    const applyTheme = (theme) => {
      document.documentElement.setAttribute("data-theme", theme);
      if (themeBtn) {
        themeBtn.textContent = theme === "dark" ? "🌙 Theme: Dark" : "☀️ Theme: White";
      }
      try { localStorage.setItem("aquavision-theme", theme); } catch (e) {}
    };

    const savedTheme = (() => {
      try { return localStorage.getItem("aquavision-theme") || "light"; } catch (e) { return "light"; }
    })();
    applyTheme(savedTheme);

    themeBtn?.addEventListener("click", () => {
      const current = document.documentElement.getAttribute("data-theme") || "light";
      const next = current === "dark" ? "light" : "dark";
      applyTheme(next);
    });

    // Save full screen as PNG
    const savePngBtn = $("btnSaveScreenPng");
    savePngBtn?.addEventListener("click", async () => {
      if (typeof html2canvas === "undefined") {
        alert("Screen capture library is loading, please try again in a moment.");
        return;
      }
      const origText = savePngBtn.textContent;
      try {
        savePngBtn.textContent = "⏳ Saving PNG...";
        savePngBtn.disabled = true;
        await new Promise(r => setTimeout(r, 80));

        const target = document.querySelector(".aqua-app") || document.body;
        const canvas = await html2canvas(target, {
          scale: 2,
          useCORS: true,
          allowTaint: true,
          logging: false,
          backgroundColor: getComputedStyle(document.body).backgroundColor || "#f8fafc",
          windowWidth: document.documentElement.scrollWidth,
          windowHeight: document.documentElement.scrollHeight
        });

        const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
        const link = document.createElement("a");
        link.download = `aquavision-xai-screen-${timestamp}.png`;
        link.href = canvas.toDataURL("image/png");
        link.click();
      } catch (err) {
        console.error("Screen capture error:", err);
        alert("Failed to save screen PNG: " + err.message);
      } finally {
        savePngBtn.textContent = origText;
        savePngBtn.disabled = false;
      }
    });
  }

  function updateLiveUi() {
    const dot = $("simLiveDot");
    const txt = $("simStatusText");
    const btn = $("btnToggleLive");

    if (isLiveStreaming) {
      dot?.classList.remove("paused");
      if (txt) txt.textContent = "LIVE EXPLORATION ACTIVE";
      if (btn) btn.textContent = "⏸ Pause Live Feed";
    } else {
      dot?.classList.add("paused");
      if (txt) txt.textContent = "ANALYSIS FEED PAUSED";
      if (btn) btn.textContent = "▶ Resume Live Feed";
    }
  }

  function startLivePolling(ms = 2500) {
    if (pollIntervalId) {
      clearInterval(pollIntervalId);
      pollIntervalId = null;
    }
    pollIntervalId = setInterval(() => {
      if (isLiveStreaming && !isFetchingLive) {
        fetchLiveFrame(false);
      }
    }, ms);
  }

  // ============================================================
  // 4. LIVE FRAME DATA FETCH & RENDER
  // ============================================================
  async function fetchLiveFrame(force = false) {
    if (isFetchingLive && !force) return;
    isFetchingLive = true;

    try {
      const res = await fetch("/api/aquavision/live-frame");
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();

      if (data.ok || data.prediction) {
        const frameChanged = data.frame_id && data.frame_id !== lastRenderedFrameId;
        lastRenderedFrameId = data.frame_id;
        currentFrameData = data;
        renderDashboard(data);
        if (frameChanged) {
          fetchPredictionHistory();
        }
        $("simStoppedBanner") && ($("simStoppedBanner").style.display = data.simulation_running === false ? "flex" : "none");
      }
    } catch (err) {
      console.warn("Live frame fetch:", err.message);
    } finally {
      isFetchingLive = false;
    }
  }

  async function uploadCustomImage(file) {
    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch("/api/aquavision/analyze", {
        method: "POST",
        body: formData,
      });
      if (!res.ok) throw new Error(`Upload failed: ${res.statusText}`);
      const data = await res.json();
      currentFrameData = data;
      renderDashboard(data);
    } catch (err) {
      alert(`Error analyzing image: ${err.message}`);
    }
  }

  async function analyzeDatasetSample(sample) {
    try {
      const res = await fetch(`/api/aquavision/analyze?dataset_sample_path=${encodeURIComponent(sample.relative_path)}`, {
        method: "POST",
      });
      if (!res.ok) throw new Error(`Analysis failed: ${res.statusText}`);
      const data = await res.json();
      currentFrameData = data;
      renderDashboard(data);
      closeBenchmarkModal();
    } catch (err) {
      alert(`Error analyzing benchmark sample: ${err.message}`);
    }
  }

  // ============================================================
  // 5. MASTER DASHBOARD RENDERER
  // ============================================================
  function renderDashboard(data) {
    if (!data) return;

    renderRibbon(data);
    renderSection1LiveVision(data);
    renderSection2Pipeline(data);
    renderSection3Features(data);
    renderSection4InsideCnn(data);
    renderSection5Comparison(data);
    renderSection6Gradcam(data);
  }

  function renderRibbon(data) {
    const meta = $("metaFrameId");
    if (meta) meta.textContent = data.frame_id || "FRAME-00000";
    const ts = $("metaTimestamp");
    if (ts) ts.textContent = data.timestamp || "—";
    const src = $("metaSource");
    if (src) src.textContent = cleanSourceLabel(data.source);
    const inf = $("metaInferenceMs");
    if (inf) inf.textContent = `${data.inference_duration_ms || 35.0} ms`;

    const tele = data.robot_telemetry || {};
    const pose = $("metaRobotPose");
    if (pose) {
      pose.textContent = `X: ${Number(tele.x || 0).toFixed(1)} | Y: ${Number(tele.y || 0).toFixed(1)} | Z: ${Number(tele.depth || 12.0).toFixed(1)}m`;
    }
  }

  // ------------------------------------------------------------
  // SECTION 1: LIVE ROBOT VISION
  // ------------------------------------------------------------
  function renderSection1LiveVision(data) {
    const pred = data.prediction || {};
    const topEnv = pred.environment || "Coral Reef";
    const topConf = pred.confidence ? (pred.confidence * 100).toFixed(1) : "0.0";

    // Top Classification Badges
    const badge = $("topEnvBadge");
    if (badge) {
      badge.textContent = topEnv.toUpperCase();
      badge.className = "env-badge-lg " + getEnvClassModifier(topEnv);
    }
    const confPill = $("topConfPct");
    if (confPill) confPill.textContent = `${topConf}%`;

    // Camera Image Feed
    const imgLive = $("imgLiveFrame");
    if (imgLive) {
      const liveSrc = toDataUrl(data.images?.full_base64) || "/api/aquavision/camera-frame";
      if (liveSrc) imgLive.src = liveSrc;
    }
    const overlayId = $("overlayFrameId");
    if (overlayId) overlayId.textContent = data.frame_id || "FRAME-00000";

    // Source badge
    const srcBadge = $("cameraSourceBadge");
    if (srcBadge) srcBadge.textContent = cleanSourceLabel(data.source);

    // Robot state
    const tele = data.robot_telemetry || {};
    const coords = $("robotCoords");
    if (coords) coords.textContent = `X: ${Number(tele.x || 0).toFixed(2)}, Y: ${Number(tele.y || 0).toFixed(2)}`;
    const depth = $("robotDepth");
    if (depth) depth.textContent = `${Number(tele.depth || 12.0).toFixed(1)} m`;
    const heading = $("robotHeading");
    if (heading) heading.textContent = `${Number(tele.heading || 0).toFixed(1)}°`;
    const speed = $("robotSpeed");
    if (speed) speed.textContent = `${Number(tele.speed || 0.45).toFixed(2)} m/s`;

    // 4-Class Probability Meters
    const appScores = pred.app_scores || {
      "Coral Reef": 0.45,
      "Rock": 0.35,
      "Sand": 0.12,
      "Other / Unknown": 0.08,
    };

    const metersList = $("classMetersList");
    if (metersList) {
      metersList.innerHTML = "";
      APP_CLASSES.forEach(cName => {
        const score = appScores[cName] || 0.0;
        const pct = (score * 100).toFixed(1);
        const row = document.createElement("div");
        row.className = `class-meter-row ${getMeterClassModifier(cName)}`;
        row.innerHTML = `
          <div class="meter-header">
            <span>${cName}</span>
            <span class="meter-pct">${pct}%</span>
          </div>
          <div class="meter-bar-track">
            <div class="meter-bar-fill" style="width: ${pct}%"></div>
          </div>
        `;
        metersList.appendChild(row);
      });
    }

    // Decision Logic Box
    const decTop = $("decTopClass");
    if (decTop) decTop.textContent = topEnv;
    const decRunner = $("decRunnerUp");
    if (decRunner) decRunner.textContent = `${pred.alternative_environment || "Rock"} (${pred.alternative_score ? (pred.alternative_score * 100).toFixed(1) : "0.0"}%)`;
    const decMargin = $("decMargin");
    if (decMargin) decMargin.textContent = `+${pred.margin ? (pred.margin * 100).toFixed(1) : "0.0"}%`;
    const decRel = $("decReliability");
    if (decRel) {
      if (pred.is_uncertain) {
        decRel.textContent = "Uncertain (Close Margin)";
        decRel.className = "text-accent";
      } else {
        decRel.textContent = "Robust & Confident";
        decRel.className = "text-green";
      }
    }
  }

  function getEnvClassModifier(envName) {
    const l = (envName || "").toLowerCase();
    if (l.includes("coral")) return "env-coral";
    if (l.includes("rock")) return "env-rock";
    if (l.includes("sand")) return "env-sand";
    return "env-other";
  }

  function getMeterClassModifier(cName) {
    const l = (cName || "").toLowerCase();
    if (l.includes("coral")) return "meter-coral";
    if (l.includes("rock")) return "meter-rock";
    if (l.includes("sand")) return "meter-sand";
    return "meter-other";
  }

  // ------------------------------------------------------------
  // SECTION 2: 12-STAGE PIPELINE
  // ------------------------------------------------------------
  function renderSection2Pipeline(data) {
    const stages = data.pipeline_stages || [];
    const stepper = $("pipelineStepper");
    if (!stepper) return;

    stepper.innerHTML = "";
    stages.forEach((st, idx) => {
      const chip = document.createElement("div");
      chip.className = `step-chip ${idx === selectedStageIndex ? "active" : ""}`;
      chip.innerHTML = `
        <span class="chip-num">STAGE ${st.stage_num}</span>
        <span class="chip-name">${st.name}</span>
      `;
      chip.addEventListener("click", () => {
        selectedStageIndex = idx;
        renderStageDetail(stages[idx]);
        document.querySelectorAll(".step-chip").forEach((c, i) => {
          c.classList.toggle("active", i === idx);
        });
      });
      stepper.appendChild(chip);
    });

    if (stages[selectedStageIndex]) {
      renderStageDetail(stages[selectedStageIndex]);
    }
  }

  function renderStageDetail(stage) {
    if (!stage) return;

    const badge = $("stageBadgePill");
    if (badge) badge.textContent = `STAGE ${stage.stage_num} OF 12`;
    const title = $("stageInspectorTitle");
    if (title) title.textContent = stage.name;
    const cat = $("stageInspectorCategory");
    if (cat) cat.textContent = stage.category || "Vision";
    const sum = $("stageInspectorSummary");
    if (sum) sum.textContent = stage.summary || "";

    const img = $("stageInspectorImg");
    if (img) {
      img.src = toDataUrl(stage.image_base64);
    }

    const table = $("stageSpecsTable");
    if (table) {
      table.innerHTML = "";
      const details = stage.details || {};
      for (const [k, v] of Object.entries(details)) {
        const entry = document.createElement("div");
        entry.className = "spec-entry";
        const formattedKey = k.replace(/_/g, " ").toUpperCase();
        entry.innerHTML = `
          <span class="spec-k">${formattedKey}</span>
          <span class="spec-v">${formatSpecValue(v)}</span>
        `;
        table.appendChild(entry);
      }
    }

    const deepDive = $("stageAlgoDeepDive");
    if (deepDive) {
      deepDive.innerHTML = getStageAlgorithmExplanation(stage.stage_num);
    }
  }

  function getStageAlgorithmExplanation(num) {
    switch (num) {
      case 1:
        return "<strong>Raw Acquisition:</strong> Photons captured by the AUV optical aperture buffer are converted into a 3-channel sRGB matrix representing benthic substrate radiance.";
      case 2:
        return "<strong>Integrity Validation:</strong> Validates pixel dynamic range [0, 255], checks for sensor blackouts, and guarantees non-zero variance before numerical feature calculation.";
      case 3:
        return "<strong>Color & Bilateral Denoising:</strong> Applies edge-preserving bilateral filtering to suppress high-frequency underwater turbidity noise while preserving sharp bedrock and coral borders.";
      case 4:
        return "<strong>Adaptive Region Masking:</strong> Otsu binarization separates foreground substrate features from ambient water column attenuation voids.";
      case 5:
        return "<strong>Morphological Geometry:</strong> Green's theorem computes contour perimeter and area; convex hull algorithms evaluate convexity and solidity.";
      case 6:
        return "<strong>Haralick Co-occurrence:</strong> 64-level Gray Level Co-occurrence Matrix (GLCM) evaluated at distances $d=1, 2$ across 4 angles (0°, 45°, 90°, 135°).";
      case 7:
        return "<strong>Gradient Profilometry:</strong> Canny double-threshold edge detector and Sobel 3×3 operator calculate edge density, mean magnitude, and angular orientation entropy.";
      case 8:
        return "<strong>Spectral Chromatic Balance:</strong> Evaluates differential wavelength absorption: calculates red attenuation vs blue-green backscatter.";
      case 9:
        return "<strong>21-Feature Numerical Vector:</strong> Concatenates all 21 measurable geometric, textural, edge, and chromatic descriptors into an ordered vector $\\mathbf{x} \\in \\mathbb{R}^{21}$.";
      case 10:
        return "<strong>Tensor Normalization:</strong> Resized to 224×224 and normalized using ImageNet channel parameters ($\\mu=[0.485, 0.456, 0.406]$, $\\sigma=[0.229, 0.224, 0.225]$).";
      case 11:
        return "<strong>Residual Feature Extraction:</strong> Forward pass through ResNet-18 residual blocks (conv1, layer1..4) propagating hierarchical convolutional representations.";
      case 12:
        return "<strong>Logits to Probability:</strong> Softmax mapping over 22 fine-grained classes aggregated into the 4 target application categories: Rock, Sand, Coral Reef, Other.";
      default:
        return "Stage execution completed.";
    }
  }

  // ------------------------------------------------------------
  // SECTION 3: 21-FEATURE MEASUREMENT LAB
  // ------------------------------------------------------------
  function initFeatureFilters() {
    const filterBtns = document.querySelectorAll(".filter-btn");
    filterBtns.forEach(btn => {
      btn.addEventListener("click", () => {
        filterBtns.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        activeFeatureFilter = btn.getAttribute("data-filter");
        if (currentFrameData) {
          renderSection3Features(currentFrameData);
        }
      });
    });
  }

  function renderSection3Features(data) {
    const fList = data.features_21 || [];
    const grid = $("featuresGrid21");
    if (!grid) return;

    grid.innerHTML = "";
    const filtered = fList.filter(f => {
      if (activeFeatureFilter === "all") return true;
      return f.group === activeFeatureFilter;
    });

    filtered.forEach(f => {
      const card = document.createElement("div");
      card.className = "feature-card";
      card.innerHTML = `
        <div class="feat-hdr">
          <div class="feat-id-name">
            <span class="feat-group-pill">${f.group} • #${f.id}</span>
            <span class="feat-title">${f.name}</span>
          </div>
          <span class="feat-type-badge">${f.type}</span>
        </div>
        <div class="feat-val-box">
          <span class="feat-num-val">${Number(f.value).toFixed(4)}</span>
          <span class="feat-scale">${f.unit_or_scale}</span>
        </div>
        <div class="feat-calc">
          <strong>Calculation:</strong> ${f.calculation}
        </div>
        <div class="feat-calc">
          <strong>Scope:</strong> <code>${f.scope}</code>
        </div>
        <div class="feat-relevance">
          <strong>Seabed Relevance:</strong> ${f.seabed_relevance}
        </div>
      `;
      grid.appendChild(card);
    });
  }

  // ------------------------------------------------------------
  // SECTION 4: INSIDE THE CNN
  // ------------------------------------------------------------
  function initInsideCnnControls() {
    const btns = document.querySelectorAll(".btn-rep");
    btns.forEach(btn => {
      btn.addEventListener("click", async () => {
        btns.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        selectedInsideCnnRep = btn.getAttribute("data-rep");

        if (selectedInsideCnnRep === "live") {
          if (currentFrameData) renderSection4InsideCnn(currentFrameData);
        } else {
          try {
            const res = await fetch(`/api/aquavision/inside-cnn/${encodeURIComponent(selectedInsideCnnRep)}`);
            if (!res.ok) throw new Error("Rep class fetch failed");
            const data = await res.json();
            if (data.ok) {
              renderInsideCnnLayers(data.cnn_activations);
            }
          } catch (err) {
            console.warn(err);
          }
        }
      });
    });
  }

  function renderSection4InsideCnn(data) {
    renderInsideCnnLayers(data.cnn_activations);
  }

  function renderInsideCnnLayers(activations) {
    const container = $("layersFlowContainer");
    if (!container || !activations) return;

    container.innerHTML = "";
    const layerKeys = ["conv1", "layer1", "layer2", "layer3", "layer4", "avgpool"];
    const descriptions = {
      conv1: "Early low-level Gabor-like edge filters and color gradients [64, 112, 112].",
      layer1: "BasicBlock residual layers detecting fine spatial micro-textures [64, 56, 56].",
      layer2: "Intermediate residual representations: branching ridges and fissures [128, 28, 28].",
      layer3: "Deeper structural assemblies: substrate motifs and coral heads [256, 14, 14].",
      layer4: "Deep semantic activation maps encoding high-level benthic morphology [512, 7, 7].",
      avgpool: "Spatial average pooling collapsing feature maps to 512-dim embedding [512, 1, 1].",
    };

    layerKeys.forEach(lName => {
      const act = activations[lName];
      if (!act) return;

      const card = document.createElement("div");
      card.className = "layer-chip-card";
      card.innerHTML = `
        <div class="layer-hdr">
          <span class="layer-name">${lName}</span>
          <span class="layer-shape">${act.shape ? `[${act.shape.join(", ")}]` : ""}</span>
        </div>
        <div class="layer-preview-box">
          <img src="${toDataUrl(act.preview_base64)}" alt="${lName} Activation Map">
        </div>
        <div class="layer-desc">
          ${descriptions[lName] || "Feature activations"}
        </div>
      `;
      container.appendChild(card);
    });

    // Draw 512-dim embedding canvas
    drawEmbeddingCanvas(activations.avgpool?.embedding_512 || []);
  }

  function drawEmbeddingCanvas(vec) {
    const canvas = $("canvasEmbedding");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const w = canvas.width;
    const h = canvas.height;

    ctx.fillStyle = "#03060a";
    ctx.fillRect(0, 0, w, h);

    if (!vec || vec.length === 0) {
      // Mock visually if empty
      vec = new Array(512).fill(0).map(() => Math.random() * 0.8);
    }

    const n = vec.length;
    const barW = Math.max(1, w / n);
    let maxVal = Math.max(...vec, 0.001);
    let sum = 0;
    let nonZero = 0;

    for (let i = 0; i < n; i++) {
      const val = vec[i];
      sum += val;
      if (val > 0.01) nonZero++;

      const barH = (val / maxVal) * (h - 8);
      const x = i * barW;
      const y = h - barH;

      const hue = 180 + (val / maxVal) * 50; // Cyan to Seafoam
      ctx.fillStyle = `hsl(${hue}, 100%, 50%)`;
      ctx.fillRect(x, y, barW, barH);
    }

    // Stats
    const l2 = Math.sqrt(vec.reduce((acc, v) => acc + v * v, 0));
    const mean = sum / n;
    const sparsity = ((1 - nonZero / n) * 100).toFixed(1);

    $("embL2Norm") && ($("embL2Norm").textContent = l2.toFixed(3));
    $("embMean") && ($("embMean").textContent = mean.toFixed(4));
    $("embMax") && ($("embMax").textContent = maxVal.toFixed(3));
    $("embSparsity") && ($("embSparsity").textContent = `${sparsity}%`);
  }

  // ------------------------------------------------------------
  // SECTION 5: 3-PANEL COMPARISON (ROCK vs SAND vs CORAL)
  // ------------------------------------------------------------
  function renderSection5Comparison(data) {
    const comp = data.comparison_3class || {};

    // Rock Panel
    const rData = comp.rock || comp.Rock || {};
    $("rockScoreBadge") && ($("rockScoreBadge").textContent = parseScorePct(rData));
    $("rockCamImg") && ($("rockCamImg").src = toDataUrl(rData.targeted_gradcam_base64 || rData.gradcam_overlay || data.gradcam?.overlay_base64 || data.gradcam?.heatmap_base64));
    renderDiagFeaturesList($("rockDiagFeatures"), rData);
    $("rockRationale") && ($("rockRationale").textContent = rData.rationale || rData.evaluation || "Sharp structural contours and elevated edge gradient magnitudes.");

    // Sand Panel
    const sData = comp.sand || comp.Sand || {};
    $("sandScoreBadge") && ($("sandScoreBadge").textContent = parseScorePct(sData));
    $("sandCamImg") && ($("sandCamImg").src = toDataUrl(sData.targeted_gradcam_base64 || sData.gradcam_overlay || data.gradcam?.overlay_base64 || data.gradcam?.heatmap_base64));
    renderDiagFeaturesList($("sandDiagFeatures"), sData);
    $("sandRationale") && ($("sandRationale").textContent = sData.rationale || sData.evaluation || "Smooth monotonic texture with low edge density and high local homogeneity.");

    // Coral Reef Panel
    const cData = comp.coral_reef || comp["Coral Reef"] || {};
    $("coralScoreBadge") && ($("coralScoreBadge").textContent = parseScorePct(cData));
    $("coralCamImg") && ($("coralCamImg").src = toDataUrl(cData.targeted_gradcam_base64 || cData.gradcam_overlay || data.gradcam?.overlay_base64 || data.gradcam?.heatmap_base64));
    renderDiagFeaturesList($("coralDiagFeatures"), cData);
    $("coralRationale") && ($("coralRationale").textContent = cData.rationale || cData.evaluation || "High structural complexity, branching silhouettes, and multi-channel color diversity.");
  }

  // ------------------------------------------------------------
  // SECTION 6: GRAD-CAM EXPLAINABILITY
  // ------------------------------------------------------------
  function initGradcamTargets() {
    const btns = document.querySelectorAll("#gradcamTargetBtns .btn-target");
    btns.forEach(btn => {
      btn.addEventListener("click", async () => {
        btns.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        currentTargetClass = btn.getAttribute("data-target");
        recalculateGradcam(currentTargetClass);
      });
    });
  }

  async function recalculateGradcam(targetClass) {
    try {
      const res = await fetch(`/api/aquavision/explain?target_class=${encodeURIComponent(targetClass)}`, {
        method: "POST",
      });
      if (!res.ok) throw new Error("Gradcam target recalculation failed");
      const data = await res.json();
      if (data.gradcam) {
        if (data.gradcam.heatmap_base64) $("imgTrioHeatmap").src = toDataUrl(data.gradcam.heatmap_base64);
        if (data.gradcam.overlay_base64) $("imgTrioOverlay").src = toDataUrl(data.gradcam.overlay_base64);
        if (data.gradcam.explanation) $("focalExplanationText").textContent = data.gradcam.explanation;
        $("focalTargetBadge").textContent = `Target: ${targetClass.toUpperCase()}`;
      }
    } catch (err) {
      console.warn("Recalculate Grad-CAM error:", err);
    }
  }

  function renderSection6Gradcam(data) {
    const gc = data.gradcam || {};
    if (data.images?.full_base64) $("imgTrioOriginal").src = toDataUrl(data.images.full_base64);
    if (gc.heatmap_base64) $("imgTrioHeatmap").src = toDataUrl(gc.heatmap_base64);
    if (gc.overlay_base64) $("imgTrioOverlay").src = toDataUrl(gc.overlay_base64);
    if (gc.explanation) $("focalExplanationText").textContent = gc.explanation;

    const topEnv = data.prediction?.environment || "CORAL REEF";
    $("focalTargetBadge").textContent = `Target: ${topEnv.toUpperCase()}`;

    // Update active target button
    document.querySelectorAll("#gradcamTargetBtns .btn-target").forEach(b => {
      b.classList.toggle("active", b.getAttribute("data-target") === topEnv);
    });
  }

  // ------------------------------------------------------------
  // SECTION 7: LIVE PREDICTION TIMELINE
  // ------------------------------------------------------------
  async function fetchPredictionHistory() {
    try {
      const res = await fetch("/api/aquavision/timeline?limit=30");
      if (!res.ok) throw new Error("History fetch failed");
      const data = await res.json();
      renderTimeline(data.history || []);
    } catch (err) {
      console.warn("Timeline fetch error:", err);
    }
  }

  function renderTimeline(records) {
    const tbody = $("timelineTableBody");
    const countBadge = $("historyCountBadge");
    if (countBadge) countBadge.textContent = `${records.length} Records`;
    if (!tbody) return;

    if (records.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" class="empty-state">No historical frames logged yet. Start mission to record frames.</td></tr>`;
      return;
    }

    tbody.innerHTML = "";
    records.forEach(rec => {
      const tr = document.createElement("tr");
      const confPct = rec.confidence ? (rec.confidence * 100).toFixed(1) : "—";
      const marginPct = rec.margin ? (rec.margin * 100).toFixed(1) : "—";
      const tele = rec.robot_telemetry || {};
      const poseStr = `(${Number(tele.x || 0).toFixed(1)}, ${Number(tele.y || 0).toFixed(1)}, ${Number(tele.depth || 12.0).toFixed(1)})`;

      tr.innerHTML = `
        <td><b>${rec.frame_id || "FRAME"}</b></td>
        <td>${rec.timestamp || "—"}</td>
        <td><span class="env-badge-sm ${getEnvClassModifier(rec.environment)}">${rec.environment || "—"}</span></td>
        <td>${confPct}%</td>
        <td>+${marginPct}%</td>
        <td>${poseStr}</td>
        <td><button class="btn-inspect" data-frameid="${rec.frame_id}">Inspect</button></td>
      `;

      tr.querySelector(".btn-inspect")?.addEventListener("click", () => {
        loadHistoricalFrame(rec.frame_id);
      });

      tbody.appendChild(tr);
    });
  }

  async function loadHistoricalFrame(frameId) {
    try {
      const res = await fetch(`/api/cnn-analysis/history/${encodeURIComponent(frameId)}`);
      if (!res.ok) throw new Error("Historical frame fetch failed");
      const data = await res.json();
      if (data) {
        currentFrameData = data;
        renderDashboard(data);
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
    } catch (err) {
      alert(`Could not load historical frame ${frameId}: ${err.message}`);
    }
  }

  // ------------------------------------------------------------
  // SECTION 8: DATASET AUDIT & 100-SAMPLE BENCHMARK MODAL
  // ------------------------------------------------------------
  async function fetchDatasetAudit() {
    try {
      const res = await fetch("/api/aquavision/dataset-audit");
      if (!res.ok) throw new Error("Dataset audit fetch failed");
      const data = await res.json();
      renderDatasetAudit(data);
      benchmarkSamplesCache = data.benchmark_100_samples || [];
    } catch (err) {
      console.warn("Dataset audit error:", err);
    }
  }

  function renderDatasetAudit(audit) {
    // Target 100-Sample Benchmark Distribution
    const tBars = $("targetDistBars");
    if (tBars) {
      tBars.innerHTML = `
        <div class="audit-bar-item">
          <div class="audit-bar-hdr"><span>Rock (Target: 40)</span> <span>40%</span></div>
          <div class="audit-bar-track"><div class="audit-bar-fill fill-rock" style="width: 40%"></div></div>
        </div>
        <div class="audit-bar-item">
          <div class="audit-bar-hdr"><span>Sand (Target: 10)</span> <span>10%</span></div>
          <div class="audit-bar-track"><div class="audit-bar-fill fill-sand" style="width: 10%"></div></div>
        </div>
        <div class="audit-bar-item">
          <div class="audit-bar-hdr"><span>Coral Reef (Target: 25)</span> <span>25%</span></div>
          <div class="audit-bar-track"><div class="audit-bar-fill fill-coral" style="width: 25%"></div></div>
        </div>
        <div class="audit-bar-item">
          <div class="audit-bar-hdr"><span>Other / Unknown (Target: 25)</span> <span>25%</span></div>
          <div class="audit-bar-track"><div class="audit-bar-fill fill-other" style="width: 25%"></div></div>
        </div>
      `;
    }

    // Actual Dataset Splits
    const trainData = audit.actual_dataset_splits?.train || {};
    const counts = trainData.counts || { Rock: 430, Sand: 130, "Coral Reef": 406, "Other / Unknown": 551 };
    const totalTrain = trainData.total || 1517;

    const aBars = $("actualDistBars");
    if (aBars) {
      aBars.innerHTML = "";
      for (const [cls, cnt] of Object.entries(counts)) {
        const pct = ((cnt / totalTrain) * 100).toFixed(1);
        const fillClass = cls.toLowerCase().includes("rock") ? "fill-rock" :
                          (cls.toLowerCase().includes("sand") ? "fill-sand" :
                          (cls.toLowerCase().includes("coral") ? "fill-coral" : "fill-other"));
        const item = document.createElement("div");
        item.className = "audit-bar-item";
        item.innerHTML = `
          <div class="audit-bar-hdr"><span>${cls} (${cnt} images)</span> <span>${pct}%</span></div>
          <div class="audit-bar-track"><div class="audit-bar-fill ${fillClass}" style="width: ${pct}%"></div></div>
        `;
        aBars.appendChild(item);
      }
    }
  }

  // ------------------------------------------------------------
  // MODAL: 100-SAMPLE BENCHMARK GALLERY
  // ------------------------------------------------------------
  function initBenchmarkModal() {
    const modal = $("benchmarkModal");
    const openBtn = $("btnOpenBenchmarkModal");
    const openBtnSec8 = $("btnOpenBenchmarkModalSec8");
    const closeBtn = $("btnCloseBenchmarkModal");
    const closeBtnFooter = $("btnCloseModalFooter");
    const backdrop = $("modalBackdrop");

    const openModal = () => {
      if (modal) modal.style.display = "flex";
      renderBenchmarkGallery(activeBenchmarkFilter);
    };

    openBtn?.addEventListener("click", openModal);
    openBtnSec8?.addEventListener("click", openModal);

    const closeModal = () => {
      if (modal) modal.style.display = "none";
    };

    closeBtn?.addEventListener("click", closeModal);
    closeBtnFooter?.addEventListener("click", closeModal);
    backdrop?.addEventListener("click", closeModal);

    // Filter tabs in modal
    const filterBtns = document.querySelectorAll(".modal-filter-btn");
    filterBtns.forEach(btn => {
      btn.addEventListener("click", () => {
        filterBtns.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        activeBenchmarkFilter = btn.getAttribute("data-modelfilter");
        renderBenchmarkGallery(activeBenchmarkFilter);
      });
    });
  }

  function closeBenchmarkModal() {
    const modal = $("benchmarkModal");
    if (modal) modal.style.display = "none";
  }

  function renderBenchmarkGallery(filter = "all") {
    const grid = $("benchmarkGalleryGrid");
    if (!grid) return;

    grid.innerHTML = "";
    const samples = benchmarkSamplesCache.filter(s => {
      if (filter === "all") return true;
      return s.target_class === filter;
    });

    if (samples.length === 0) {
      grid.innerHTML = `<div class="empty-state">No benchmark images found for filter: ${filter}</div>`;
      return;
    }

    samples.forEach(s => {
      const card = document.createElement("div");
      card.className = "sample-thumb-card";
      card.innerHTML = `
        <div class="thumb-img-wrapper">
          <img src="${toDataUrl(s.thumbnail_base64)}" alt="${s.filename}">
        </div>
        <span class="sample-target-tag ${getEnvClassModifier(s.target_class)}">${s.target_class}</span>
        <span class="sample-fine-tag" title="${s.fine_class}">${s.fine_class}</span>
      `;
      card.addEventListener("click", () => {
        analyzeDatasetSample(s);
      });
      grid.appendChild(card);
    });
  }

  // Run on DOM ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
