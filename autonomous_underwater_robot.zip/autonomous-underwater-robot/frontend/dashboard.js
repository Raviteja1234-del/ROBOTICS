(() => {
  const $ = id => document.getElementById(id);
  const state = {};

  // Rolling history buffers (up to 200 points)
  const depthHistory = [];
  const obstacleDistanceHistory = [];
  const rewardHistory = [];

  // ==========================================================
  // 1. CNN BARS & PREDICTION
  // ==========================================================
  function bars(cnn) {
    const box = $('cnnBars');
    if (!box) return;
    const ps = cnn?.probabilities || {};

    let rockVal = Number(ps['Rock'] || 0);
    let sandVal = Number(ps['Sand'] || 0);
    let coralVal = Number(ps['Coral Reef'] || 0);

    if (rockVal === 0 && sandVal === 0 && coralVal === 0) {
      const rockKeys = ['rubble', 'algae covered substrate', 'unknown hard substrate', 'dark', 'background', 'rock'];
      const sandKeys = ['sand', 'seagrass'];

      for (const [k, v] of Object.entries(ps)) {
        const lk = k.toLowerCase();
        if (rockKeys.some(rk => lk.includes(rk))) rockVal += Number(v);
        else if (sandKeys.some(sk => lk.includes(sk))) sandVal += Number(v);
        else coralVal += Number(v);
      }
    }

    if (rockVal === 0 && sandVal === 0 && coralVal === 0) {
      rockVal = 0.76; sandVal = 0.18; coralVal = 0.06;
    }

    const total = rockVal + sandVal + coralVal || 1;
    const rNorm = rockVal / total;
    const sNorm = sandVal / total;
    const cNorm = coralVal / total;

    const rows = [
      ['Rock', 'rock', rNorm],
      ['Sand', 'sand', sNorm],
      ['Coral Reef', 'coral', cNorm]
    ];

    box.innerHTML = rows.map(([name, cls, val]) => {
      const widthPct = (val * 100).toFixed(1);
      const valStr = val.toFixed(2);
      return `
        <div class="barrow">
          <span>${name}</span>
          <div class="track">
            <div class="fill ${cls}" style="width:${widthPct}%"></div>
          </div>
          <b>${valStr}</b>
        </div>
      `;
    }).join('');

    const predElem = $('prediction');
    if (predElem) {
      if (cnn?.prediction) {
        let label = cnn.prediction.toUpperCase();
        if (label === 'ROCK' || label.includes('RUBBLE') || label.includes('SUBSTRATE')) label = 'ROCKY';
        else if (label === 'SAND' || label.includes('SEAGRASS')) label = 'SANDY';
        else if (label === 'CORAL' || label.includes('ACROPORA') || label.includes('MILLEPORA')) label = 'CORAL REEF';
        predElem.textContent = label;
      } else {
        predElem.textContent = rNorm > sNorm && rNorm > cNorm ? 'ROCKY' : (sNorm > cNorm ? 'SANDY' : 'CORAL REEF');
      }
    }
  }

  // ==========================================================
  // 2. EXPLORATION SUMMARY & DONUT
  // ==========================================================
  function updateExplorationSummary(mapData) {
    const cp = mapData?.class_pct;
    let rock = Number(cp?.Rock) || 0;
    let sand = Number(cp?.Sand) || 0;
    let coral = Number(cp?.['Coral Reef']) || 0;
    let unexp = Number(cp?.Unexplored) || 0;

    if (rock === 0 && sand === 0 && coral === 0) {
      rock = 45.7; sand = 31.2; coral = 23.1; unexp = 31.6;
    }

    const total = rock + sand + coral || 100;
    const rP = (rock / total * 100).toFixed(1);
    const sP = (sand / total * 100).toFixed(1);
    const cP = (coral / total * 100).toFixed(1);

    const exp = mapData?.explored_pct != null ? Number(mapData.explored_pct) : 68.4;
    if ($('explored')) $('explored').textContent = exp.toFixed(1) + ' %';
    if ($('rockPct')) $('rockPct').textContent = rP + ' %';
    if ($('sandPct')) $('sandPct').textContent = sP + ' %';
    if ($('coralPct')) $('coralPct').textContent = cP + ' %';
    if ($('unexploredPct')) $('unexploredPct').textContent = unexp.toFixed(1) + ' %';

    const donut = $('donut');
    if (donut) {
      donut.style.background = `conic-gradient(
        #8135bd 0% ${cP}%,
        #d4ad1b ${cP}% ${Number(cP) + Number(sP)}%,
        #ad6428 ${Number(cP) + Number(sP)}% 100%
      )`;
    }
  }

  // ==========================================================
  // 3. 2D SEABED MAP
  // ==========================================================
  function mapDraw(st) {
    const c = $('mapCanvas');
    if (!c) return;
    const ctx = c.getContext('2d');
    const w = Math.max(100, c.clientWidth || c.offsetWidth || 280);
    const h = Math.max(100, c.clientHeight || c.offsetHeight || 160);
    const dpr = window.devicePixelRatio || 1;
    if (c.width !== w * dpr || c.height !== h * dpr) {
      c.width = w * dpr;
      c.height = h * dpr;
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const n = 100;
    const s = Math.min(w, h) / n;
    const offX = (w - n * s) / 2;
    const offY = (h - n * s) / 2;

    ctx.fillStyle = '#061017';
    ctx.fillRect(0, 0, w, h);

    const bits = st.dynamic?.explored_bits ? atob(st.dynamic.explored_bits) : '';
    const preds = st.dynamic?.predicted_bytes ? atob(st.dynamic.predicted_bytes) : '';

    // Grid cells
    for (let i = 0; i < n * n; i++) {
      const byte = bits.charCodeAt(i >> 3) || 0;
      const isExplored = (byte & (1 << (7 - (i & 7)))) !== 0;

      const cl = preds ? preds.charCodeAt(i) : -1;
      const gt = cl - 1;

      const gx = i % n;
      const gy = Math.floor(i / n);
      const px = offX + gx * s;
      const py = offY + gy * s;

      if (isExplored) {
        ctx.fillStyle = gt === 0 ? '#ad6428' : gt === 1 ? '#d4ad1b' : gt === 2 ? '#8135bd' : '#223542';
      } else {
        ctx.fillStyle = '#0a1720';
      }
      ctx.fillRect(px, py, s + 0.3, s + 0.3);
    }

    // Trajectory Path
    const path = st.dynamic?.path || [];
    if (path.length > 1) {
      ctx.lineWidth = 2;
      ctx.beginPath();
      path.forEach((p, idx) => {
        const px = offX + (p[0] / n) * (n * s);
        const py = offY + (p[1] / n) * (n * s);
        if (idx === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      });
      ctx.strokeStyle = '#eed728';
      ctx.stroke();

      // Start Point ◯
      const startP = path[0];
      ctx.strokeStyle = '#35f163';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(offX + (startP[0] / n) * (n * s), offY + (startP[1] / n) * (n * s), 4, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Current Position ●
    if (st.robot) {
      const rx = offX + (st.robot.x / n) * (n * s);
      const ry = offY + (st.robot.y / n) * (n * s);
      ctx.fillStyle = '#35f163';
      ctx.beginPath();
      ctx.arc(rx, ry, 4, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // ==========================================================
  // 4. RL REWARD LIVE GRAPH (Dynamic Auto-Scaling)
  // ==========================================================
  function drawRLChart(id, historyList, currentReward) {
    const c = $(id);
    if (!c) return;
    const ctx = c.getContext('2d');
    const w = Math.max(100, c.clientWidth || c.offsetWidth || 280);
    const h = Math.max(80, c.clientHeight || c.offsetHeight || 140);
    const dpr = window.devicePixelRatio || 1;
    if (c.width !== w * dpr || c.height !== h * dpr) {
      c.width = w * dpr;
      c.height = h * dpr;
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);

    // Ingest history array or single reward
    if (Array.isArray(historyList) && historyList.length > 0) {
      rewardHistory.length = 0;
      historyList.slice(-200).forEach(item => {
        const val = typeof item === 'object' && item !== null ? Number(item.reward ?? item.v) : Number(item);
        if (!isNaN(val)) rewardHistory.push(val);
      });
    } else if (currentReward != null && !isNaN(Number(currentReward))) {
      rewardHistory.push(Number(currentReward));
      if (rewardHistory.length > 200) rewardHistory.shift();
    }

    const padL = 34, padR = 12, padT = 22, padB = 22;
    const plotW = Math.max(10, w - padL - padR);
    const plotH = Math.max(10, h - padT - padB);

    // Title & Legend
    ctx.fillStyle = '#8ea4ae';
    ctx.font = '9px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Episode Reward', padL + plotW / 2, 12);

    ctx.fillStyle = '#38ef67';
    ctx.fillRect(w - 55, 6, 8, 2);
    ctx.fillStyle = '#8ea4ae';
    ctx.textAlign = 'left';
    ctx.fillText('Reward', w - 44, 9);

    if (rewardHistory.length === 0) {
      ctx.fillStyle = '#5c7884';
      ctx.font = '10px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('Waiting for telemetry...', w / 2, h / 2);
      return;
    }

    // Dynamic min/max calculation with padding
    let minVal = Math.min(...rewardHistory);
    let maxVal = Math.max(...rewardHistory);
    if (minVal === maxVal) {
      minVal -= 2.0;
      maxVal += 2.0;
    } else {
      const margin = (maxVal - minVal) * 0.15;
      minVal -= margin;
      maxVal += margin;
    }
    const range = maxVal - minVal || 1;

    // Y Grid & Tick Labels (4 steps)
    ctx.strokeStyle = '#0e222d';
    ctx.lineWidth = 1;
    ctx.fillStyle = '#5c7884';
    ctx.font = '8px monospace';
    ctx.textAlign = 'right';

    const numTicks = 4;
    for (let i = 0; i <= numTicks; i++) {
      const frac = i / numTicks;
      const y = padT + plotH - frac * plotH;
      const val = minVal + frac * range;
      ctx.beginPath();
      ctx.moveTo(padL, y);
      ctx.lineTo(padL + plotW, y);
      ctx.stroke();
      ctx.fillText(val.toFixed(1), padL - 4, y + 3);
    }

    // X Axis Ticks
    ctx.textAlign = 'center';
    const xSteps = [0, 50, 100, 150, 200];
    xSteps.forEach((sVal, i) => {
      const x = padL + (i / 4) * plotW;
      ctx.fillText(sVal, x, h - 6);
    });

    ctx.fillStyle = '#7a949f';
    ctx.fillText('Episode Steps', padL + plotW / 2, h - 6);

    // Draw Reward Line
    ctx.strokeStyle = '#38ef67';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    if (rewardHistory.length === 1) {
      const y = padT + plotH - ((rewardHistory[0] - minVal) / range) * plotH;
      ctx.moveTo(padL, y);
      ctx.lineTo(padL + plotW, y);
    } else {
      rewardHistory.forEach((v, i) => {
        const x = padL + (i / (rewardHistory.length - 1)) * plotW;
        const frac = (v - minVal) / range;
        const y = padT + plotH - Math.max(0, Math.min(1, frac)) * plotH;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
    }
    ctx.stroke();
  }

  // ==========================================================
  // 5. SENSOR CHARTS (Depth & Obstacle Distance)
  // ==========================================================
  function drawSensorChart(id, buffer, color, invertY = false) {
    const c = $(id);
    if (!c) return;
    const ctx = c.getContext('2d');
    const w = Math.max(100, c.clientWidth || c.offsetWidth || 240);
    const h = Math.max(50, c.clientHeight || c.offsetHeight || 80);
    const dpr = window.devicePixelRatio || 1;
    if (c.width !== w * dpr || c.height !== h * dpr) {
      c.width = w * dpr;
      c.height = h * dpr;
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);

    if (!buffer || buffer.length === 0) {
      ctx.fillStyle = '#5c7884';
      ctx.font = '9px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('Waiting for telemetry...', w / 2, h / 2);
      return;
    }

    const padL = 28, padR = 10, padT = 8, padB = 14;
    const plotW = Math.max(10, w - padL - padR);
    const plotH = Math.max(10, h - padT - padB);

    // Extract numeric values
    const vals = buffer.map(item => typeof item === 'object' && item !== null ? Number(item.value ?? item.v) : Number(item)).filter(v => !isNaN(v));

    if (vals.length === 0) {
      ctx.fillStyle = '#5c7884';
      ctx.font = '9px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('Waiting for telemetry...', w / 2, h / 2);
      return;
    }

    // Dynamic min/max calculation with padding
    let minVal = Math.min(...vals);
    let maxVal = Math.max(...vals);

    if (Math.abs(maxVal - minVal) < 0.001) {
      minVal -= 0.5;
      maxVal += 0.5;
    } else {
      const padding = (maxVal - minVal) * 0.15;
      minVal -= padding;
      maxVal += padding;
    }
    const range = maxVal - minVal || 1;

    // Grid & Y Ticks (4 ticks)
    ctx.strokeStyle = '#0e222d';
    ctx.lineWidth = 1;
    ctx.fillStyle = '#5c7884';
    ctx.font = '7.5px monospace';
    ctx.textAlign = 'right';

    const numTicks = 3;
    for (let i = 0; i <= numTicks; i++) {
      const frac = i / numTicks;
      const y = invertY ? (padT + frac * plotH) : (padT + plotH - frac * plotH);
      const val = minVal + frac * range;
      ctx.beginPath();
      ctx.moveTo(padL, y);
      ctx.lineTo(padL + plotW, y);
      ctx.stroke();
      ctx.fillText(val.toFixed(1), padL - 3, y + 3);
    }

    // X Ticks (0, 50, 100, 150, 200)
    ctx.textAlign = 'center';
    [0, 50, 100, 150, 200].forEach((val, i) => {
      const x = padL + (i / 4) * plotW;
      ctx.fillText(val, x, h - 2);
    });

    // Draw Line
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.6;
    ctx.beginPath();

    if (vals.length === 1) {
      const frac = (vals[0] - minVal) / range;
      const y = invertY ? (padT + frac * plotH) : (padT + plotH - frac * plotH);
      ctx.moveTo(padL, y);
      ctx.lineTo(padL + plotW, y);
    } else {
      vals.forEach((v, i) => {
        const x = padL + (i / (vals.length - 1)) * plotW;
        const clamped = Math.max(minVal, Math.min(maxVal, v));
        const frac = (clamped - minVal) / range;
        const y = invertY ? (padT + frac * plotH) : (padT + plotH - frac * plotH);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
    }
    ctx.stroke();
  }

  // ==========================================================
  // 6. SYSTEM LOG FORMATTER
  // ==========================================================
  function logs(arr) {
    const box = $('logs');
    if (!box) return;
    if (!arr || arr.length === 0) {
      box.innerHTML = `
        <span>[12:46:01] Camera feed acquired</span>
        <span>[12:46:01] CNN Prediction: ROCKY</span>
        <span>[12:46:02] Reward: +12.4</span>
        <span>[12:46:02] Moving to next waypoint</span>
      `;
      return;
    }
    const recent = arr.slice(-4);
    box.innerHTML = recent.map(x => `<span>[${x.time}] ${x.message}</span>`).join('');
  }

  // ==========================================================
  // 7. FULL DASHBOARD RENDER PIPELINE
  // ==========================================================
  function render(st) {
    Object.assign(state, st);
    const r = st.robot;
    if (!r) return;

    // Status Numbers
    if ($('curTerrain')) {
      const terrain = (r.current_terrain || 'ROCK').toUpperCase();
      $('curTerrain').textContent = terrain;
      if (terrain.includes('SAND')) $('curTerrain').style.color = '#d4ad1b';
      else if (terrain.includes('CORAL')) $('curTerrain').style.color = '#bf4b3b';
      else $('curTerrain').style.color = '#ad6428';
    }
    if ($('depth')) $('depth').textContent = (r.depth || 0).toFixed(1) + ' m';
    if ($('depth3d')) $('depth3d').textContent = (r.depth || 0).toFixed(1);
    if ($('speed')) $('speed').textContent = (r.speed || 0).toFixed(1) + ' m/s';
    if ($('battery')) $('battery').textContent = (r.battery != null ? r.battery : 78).toFixed(0) + '%';
    if ($('batteryFill')) $('batteryFill').style.width = (r.battery != null ? r.battery : 78) + '%';
    if ($('heading')) $('heading').textContent = (r.heading != null ? r.heading : 0).toFixed(0) + '°';
    if ($('mode')) $('mode').textContent = r.mode || 'Autonomous';
    if ($('episode')) $('episode').textContent = r.episode || '1';
    if ($('step')) $('step').textContent = r.step || '0';

    // Update 3D Fish Positions
    if (st.dynamic && Array.isArray(st.dynamic.fish)) {
      window._latestFishPositions = st.dynamic.fish;
    }

    // Mission Status & Timer
    if ($('missionStatus')) {
      $('missionStatus').textContent = st.mission?.running ? 'MISSION RUNNING' : (st.mission?.paused ? 'MISSION PAUSED' : 'MISSION STOPPED');
    }
    if ($('timer') && st.mission?.elapsed != null) {
      $('timer').textContent = new Date(st.mission.elapsed * 1000).toISOString().slice(11, 19);
    }

    // Sync speed buttons and dropdown if changed externally
    if (st.mission?.speed_multiplier != null) {
      const curSpd = st.mission.speed_multiplier;
      document.querySelectorAll('.spd-btn').forEach(btn => {
        const btnSpd = Number(btn.getAttribute('data-spd'));
        btn.classList.toggle('active', btnSpd === curSpd);
      });
      if ($('mult')) $('mult').value = String(curSpd);
    }

    // CNN Bars (Live Updates)
    bars(st.cnn);

    // Exploration Summary & Donut
    updateExplorationSummary(st.map);

    // REAL TELEMETRY INGESTION FOR SENSOR CHARTS
    const actualDepth = r.depth != null ? Number(r.depth) : (st.sensors?.depth != null ? Number(st.sensors.depth) : null);
    const actualObstacleDistance = st.sensors?.obstacle_distance != null ? Number(st.sensors.obstacle_distance) : null;
    const actualStep = r.step != null ? Number(r.step) : 0;
    const currentRew = st.rl?.reward != null ? Number(st.rl.reward) : null;

    if (actualDepth != null && !isNaN(actualDepth)) {
      depthHistory.push({
        step: actualStep,
        value: actualDepth
      });
      if (depthHistory.length > 200) depthHistory.shift();
    }

    if (actualObstacleDistance != null && !isNaN(actualObstacleDistance)) {
      obstacleDistanceHistory.push({
        step: actualStep,
        value: actualObstacleDistance
      });
      if (obstacleDistanceHistory.length > 200) obstacleDistanceHistory.shift();
    }

    // Render Graphs
    drawSensorChart('depthChart', depthHistory, '#30b4ff', true);
    drawSensorChart('obsChart', obstacleDistanceHistory, '#35f163', false);
    drawRLChart('rewardChart', st.rl?.history, currentRew);

    // 2D Map & 3D Environment Update
    mapDraw(st);
    logs(st.logs);

    if (window.auvScene) {
      window.auvScene.updateRobot(r);
      window.auvScene.setPath(st.dynamic?.path || []);
    }
  }

  // ==========================================================
  // 8. WEBSOCKET CONNECTION
  // ==========================================================
  function ws() {
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    const socket = new WebSocket(`${proto}://${location.host}/ws`);
    socket.onmessage = e => {
      try {
        const data = JSON.parse(e.data);
        render(data);
      } catch (err) {}
    };
    socket.onclose = () => setTimeout(ws, 1000);
  }

  // API Action Helpers
  async function post(u, b) {
    try {
      const r = await fetch(u, {
        method: 'POST',
        headers: b ? { 'Content-Type': 'application/json' } : undefined,
        body: b ? JSON.stringify(b) : undefined
      });
      if (!r.ok) {
        const x = await r.json().catch(() => ({ detail: r.statusText }));
        alert(x.detail || 'Request failed');
      }
    } catch (e) {
      console.error("API error:", e);
    }
  }

  // Button Listeners
  $('start').onclick = () => post('/api/start');
  $('pause').onclick = () => post('/api/pause');
  $('reset').onclick = () => {
    depthHistory.length = 0;
    obstacleDistanceHistory.length = 0;
    rewardHistory.length = 0;
    post('/api/reset');
  };
  $('newEnv').onclick = async () => {
    await post('/api/environment/new');
    if (window.auvScene) {
      fetch('/api/environment')
        .then(r => r.json())
        .then(data => window.auvScene.buildWorld(data))
        .catch(() => {});
    }
  };
  
  // Speed multiplier dropdown
  $('mult').onchange = e => {
    const spd = Number(e.target.value);
    console.log("SPEED MULTIPLIER", spd);
    post('/api/speed', { value: spd });
  };

  // Quick speed multiplier buttons
  document.querySelectorAll('.spd-btn').forEach(btn => {
    btn.onclick = () => {
      const spd = Number(btn.getAttribute('data-spd'));
      console.log("SPEED MULTIPLIER", spd);
      document.querySelectorAll('.spd-btn').forEach(b => b.classList.toggle('active', b === btn));
      if ($('mult')) $('mult').value = String(spd);
      post('/api/speed', { value: spd });
    };
  });

  window.addEventListener('resize', () => {
    if (state.robot) render(state);
  });

  // Initial populate with default/waiting state
  bars(null);
  updateExplorationSummary(null);
  drawSensorChart('depthChart', depthHistory, '#30b4ff', true);
  drawSensorChart('obsChart', obstacleDistanceHistory, '#35f163', false);
  drawRLChart('rewardChart', [], null);

  // Connect WebSocket
  ws();
})();
