(() => {
  const wrap = document.getElementById('scene');
  const camCanvas = document.getElementById('robotCamera');

  if (!wrap) {
    console.error("3D scene container #scene not found!");
    return;
  }

  const deg2rad = deg => ((Number(deg) || 0) * Math.PI) / 180;

  const getContainerSize = () => {
    const w = wrap.clientWidth || wrap.offsetWidth || 640;
    const h = wrap.clientHeight || wrap.offsetHeight || 420;
    return { w: Math.max(20, w), h: Math.max(20, h) };
  };

  const { w: initW, h: initH } = getContainerSize();

  // =========================================================================
  // 1. THREE.JS RENDERER & UNDERWATER ATMOSPHERE
  // =========================================================================
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance', preserveDrawingBuffer: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.setSize(initW, initH);
  if (renderer.outputColorSpace !== undefined && THREE.SRGBColorSpace !== undefined) {
    renderer.outputColorSpace = THREE.SRGBColorSpace;
  } else if (renderer.outputEncoding !== undefined && THREE.sRGBEncoding !== undefined) {
    renderer.outputEncoding = THREE.sRGBEncoding;
  }
  renderer.setClearColor(0x021622, 1);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  wrap.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0x031d2a, 0.02);

  // Main Perspective Camera
  const camera = new THREE.PerspectiveCamera(48, initW / initH, 0.1, 500);
  camera.position.set(16, 12, 20);

  // Mini Downward Robot Camera in Submarine Nose
  const miniW = (camCanvas && camCanvas.clientWidth) ? camCanvas.clientWidth : 220;
  const miniH = (camCanvas && camCanvas.clientHeight) ? camCanvas.clientHeight : 140;
  const cam = new THREE.PerspectiveCamera(65, miniW / miniH, 0.1, 150);

  let mini = null;
  if (camCanvas) {
    mini = new THREE.WebGLRenderer({ canvas: camCanvas, antialias: true, preserveDrawingBuffer: true });
    mini.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    mini.setSize(miniW, miniH);
    if (mini.outputColorSpace !== undefined && THREE.SRGBColorSpace !== undefined) {
      mini.outputColorSpace = THREE.SRGBColorSpace;
    } else if (mini.outputEncoding !== undefined && THREE.sRGBEncoding !== undefined) {
      mini.outputEncoding = THREE.sRGBEncoding;
    }
    mini.setClearColor(0x021824, 1);
  }

  // =========================================================================
  // 2. PROCEDURAL CAUSTICS TEXTURE
  // =========================================================================
  function createCausticsCanvas() {
    const c = document.createElement('canvas');
    c.width = 256; c.height = 256;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#021a24';
    ctx.fillRect(0, 0, 256, 256);
    return { canvas: c, ctx };
  }
  const causticsObj = createCausticsCanvas();
  const causticsTexture = new THREE.CanvasTexture(causticsObj.canvas);
  causticsTexture.wrapS = THREE.RepeatWrapping;
  causticsTexture.wrapT = THREE.RepeatWrapping;
  causticsTexture.repeat.set(6, 6);

  function updateCaustics(timeSec) {
    const ctx = causticsObj.ctx;
    ctx.fillStyle = 'rgba(2, 26, 36, 0.2)';
    ctx.fillRect(0, 0, 256, 256);
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = 'rgba(110, 235, 255, 0.35)';
    for (let i = 0; i < 7; i++) {
      ctx.beginPath();
      for (let x = 0; x <= 256; x += 16) {
        const y = 35 * i + Math.sin(x * 0.05 + timeSec * 2.0 + i) * 12 + Math.cos(x * 0.08 - timeSec * 1.5) * 8;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
    causticsTexture.needsUpdate = true;
  }

  // =========================================================================
  // 3. UNDERWATER LIGHTING SYSTEM
  // =========================================================================
  const ambientLight = new THREE.AmbientLight(0x082535, 0.9);
  scene.add(ambientLight);

  const hemiLight = new THREE.HemisphereLight(0x35a8c8, 0x010d14, 1.4);
  scene.add(hemiLight);

  // Sunlight filtering down through water surface
  const sunLight = new THREE.DirectionalLight(0x6ee2f8, 1.8);
  sunLight.position.set(20, 45, 15);
  sunLight.castShadow = true;
  sunLight.shadow.mapSize.width = 1024;
  sunLight.shadow.mapSize.height = 1024;
  sunLight.shadow.camera.near = 10;
  sunLight.shadow.camera.far = 100;
  sunLight.shadow.camera.left = -35;
  sunLight.shadow.camera.right = 35;
  sunLight.shadow.camera.top = 35;
  sunLight.shadow.camera.bottom = -35;
  scene.add(sunLight);

  // Groups
  const worldGroup = new THREE.Group(); scene.add(worldGroup);
  const fishGroup = new THREE.Group(); scene.add(fishGroup);
  const auvGroup = new THREE.Group(); auvGroup.name = "AUV_Robot"; scene.add(auvGroup);
  const pathGroup = new THREE.Group(); scene.add(pathGroup);
  const hudMarkersGroup = new THREE.Group(); scene.add(hudMarkersGroup);

  let envData = null;
  let robotState = { x: 12, y: 12, depth: 8.4, heading: 132, speed: 0.0 };
  let pathPoints = [];
  let propMesh = null;
  let startMarker = null;
  let curMarker = null;
  let particlePoints = null;
  let fishMeshes = [];

  // Camera Mode: 'chase', 'top', 'free'
  let cameraMode = 'chase';

  // =========================================================================
  // 4. DETAILED AUV SUBMARINE MODEL
  // =========================================================================
  function buildAUV() {
    auvGroup.clear();

    const hullMat = new THREE.MeshStandardMaterial({
      color: 0xf5b512,
      roughness: 0.28,
      metalness: 0.35
    });
    const darkMat = new THREE.MeshStandardMaterial({
      color: 0x141a20,
      roughness: 0.4,
      metalness: 0.8
    });
    const brassMat = new THREE.MeshStandardMaterial({
      color: 0xd9a832,
      roughness: 0.2,
      metalness: 0.9
    });
    const glassMat = new THREE.MeshStandardMaterial({
      color: 0x051d28,
      roughness: 0.05,
      metalness: 0.95
    });
    const stripeMat = new THREE.MeshStandardMaterial({
      color: 0x181e24,
      roughness: 0.4
    });

    // 1. Torpedo Main Hull
    const hullGeo = new THREE.CylinderGeometry(0.68, 0.68, 2.7, 32);
    hullGeo.rotateZ(Math.PI / 2);
    const hull = new THREE.Mesh(hullGeo, hullMat);
    hull.castShadow = true;
    auvGroup.add(hull);

    // Decorative High-Visibility Black Panel Ring
    const ringGeo = new THREE.CylinderGeometry(0.69, 0.69, 0.45, 32);
    ringGeo.rotateZ(Math.PI / 2);
    const ring = new THREE.Mesh(ringGeo, stripeMat);
    ring.position.set(-0.2, 0, 0);
    auvGroup.add(ring);

    // 2. Streamlined Front Nose Dome
    const noseGeo = new THREE.SphereGeometry(0.67, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2);
    noseGeo.rotateZ(-Math.PI / 2);
    const nose = new THREE.Mesh(noseGeo, darkMat);
    nose.position.set(1.35, 0, 0);
    nose.castShadow = true;
    auvGroup.add(nose);

    // Optical Camera Port Dome (Sapphire Glass)
    const lens = new THREE.Mesh(new THREE.SphereGeometry(0.28, 24, 16), glassMat);
    lens.position.set(1.82, -0.05, 0);
    auvGroup.add(lens);

    // Camera Bezel Ring
    const bezel = new THREE.Mesh(new THREE.TorusGeometry(0.28, 0.04, 12, 24), brassMat);
    bezel.rotateY(Math.PI / 2);
    bezel.position.set(1.8, -0.05, 0);
    auvGroup.add(bezel);

    // 3. Conning Tower / Sensor Mast
    const sail = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.6, 0.28), hullMat);
    sail.position.set(0.15, 0.82, 0);
    sail.castShadow = true;
    auvGroup.add(sail);

    const mastCap = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.85, 16), darkMat);
    mastCap.rotateZ(Math.PI / 2);
    mastCap.position.set(0.15, 1.12, 0);
    auvGroup.add(mastCap);

    // GPS Antenna
    const ant = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.5, 8), darkMat);
    ant.position.set(0.25, 1.4, 0);
    auvGroup.add(ant);

    // 4. Tapered Stern & Propulsion Shroud
    const tailConeGeo = new THREE.ConeGeometry(0.67, 1.1, 32);
    tailConeGeo.rotateZ(Math.PI / 2);
    const tailCone = new THREE.Mesh(tailConeGeo, hullMat);
    tailCone.position.set(-1.9, 0, 0);
    tailCone.castShadow = true;
    auvGroup.add(tailCone);

    const shroud = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.42, 24), darkMat);
    shroud.rotateZ(Math.PI / 2);
    shroud.position.set(-2.55, 0, 0);
    auvGroup.add(shroud);

    // 5. Hydrodynamic Fins
    [-0.9, 0.9].forEach(z => {
      const fin = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.08, 0.55), hullMat);
      fin.position.set(0.2, 0, z);
      fin.castShadow = true;
      auvGroup.add(fin);

      const trim = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.09, 0.08), darkMat);
      trim.position.set(0.2, 0, z > 0 ? z + 0.28 : z - 0.28);
      auvGroup.add(trim);
    });

    const vertFin = new THREE.Mesh(new THREE.BoxGeometry(0.6, 1.05, 0.08), hullMat);
    vertFin.position.set(-2.1, 0, 0);
    vertFin.castShadow = true;
    auvGroup.add(vertFin);

    const horizFin = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.08, 1.05), hullMat);
    horizFin.position.set(-2.1, 0, 0);
    horizFin.castShadow = true;
    auvGroup.add(horizFin);

    // 6. Propeller (4 Blades)
    const propGroup = new THREE.Group();
    propGroup.position.set(-2.8, 0, 0);

    const hub = new THREE.Mesh(new THREE.ConeGeometry(0.15, 0.3, 16), brassMat);
    hub.rotateZ(-Math.PI / 2);
    propGroup.add(hub);

    for (let b = 0; b < 4; b++) {
      const blade = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.55, 0.16), brassMat);
      blade.rotation.x = (b * Math.PI) / 2;
      blade.rotation.y = 0.35;
      blade.position.set(0, Math.sin(b * Math.PI / 2) * 0.22, Math.cos(b * Math.PI / 2) * 0.22);
      propGroup.add(blade);
    }
    auvGroup.add(propGroup);
    propMesh = propGroup;

    // 7. Dual Ultra-Bright Underwater Headlights
    const lightTarget = new THREE.Object3D();
    lightTarget.position.set(16, -3.5, 0);
    auvGroup.add(lightTarget);

    const spotLight = new THREE.SpotLight(0xc6f6ff, 5.5, 35, Math.PI / 4.2, 0.45, 1.4);
    spotLight.position.set(1.8, 0, 0);
    spotLight.target = lightTarget;
    spotLight.castShadow = true;
    auvGroup.add(spotLight);

    const bulbGlow = new THREE.PointLight(0x9ee8ff, 3.0, 10);
    bulbGlow.position.set(1.85, 0.05, 0);
    auvGroup.add(bulbGlow);

    auvGroup.scale.set(1.25, 1.25, 1.25);
    auvGroup.position.set(0, 1.2, 0);
  }
  buildAUV();

  // =========================================================================
  // 5. 3D SWIMMING FISH SCHOOL (Multiple Species)
  // =========================================================================
  function buildFishPool(count = 45) {
    fishGroup.clear();
    fishMeshes = [];

    const fishPalette = [
      { body: 0x3ab8d8, fin: 0x2280a0, scale: 0.25 }, // Silver-Blue Schooling Fish
      { body: 0xf2b528, fin: 0x1b2832, scale: 0.32 }, // Yellow Tang
      { body: 0xd95232, fin: 0xffffff, scale: 0.28 }, // Orange Clownfish
      { body: 0x7c38bd, fin: 0x3ae0a8, scale: 0.35 }  // Royal Gramma
    ];

    for (let i = 0; i < count; i++) {
      const type = fishPalette[i % fishPalette.length];
      const fGroup = new THREE.Group();

      // Fish Body (Streamlined Oval)
      const bGeo = new THREE.ConeGeometry(0.35, 1.2, 8);
      bGeo.rotateZ(-Math.PI / 2);
      const bMat = new THREE.MeshStandardMaterial({ color: type.body, roughness: 0.5, metalness: 0.3 });
      const body = new THREE.Mesh(bGeo, bMat);
      fGroup.add(body);

      // Tail Fin (Articulated Wagging)
      const tGeo = new THREE.BufferGeometry();
      const vertices = new Float32Array([
        -0.6, 0.0, 0.0,
        -1.1, 0.45, 0.0,
        -1.1, -0.45, 0.0
      ]);
      tGeo.setAttribute('position', new THREE.BufferAttribute(vertices, 3));
      tGeo.computeVertexNormals();
      const tail = new THREE.Mesh(tGeo, new THREE.MeshStandardMaterial({ color: type.fin, side: THREE.DoubleSide }));
      fGroup.add(tail);

      // Pectoral / Dorsal Fins
      const dFin = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.25, 0.04), new THREE.MeshStandardMaterial({ color: type.fin }));
      dFin.position.set(-0.1, 0.25, 0);
      fGroup.add(dFin);

      const s = type.scale * (0.8 + Math.random() * 0.4);
      fGroup.scale.set(s, s, s);
      fGroup.position.set((Math.random() - 0.5) * 50, -1.0 - Math.random() * 3.5, (Math.random() - 0.5) * 50);

      fishGroup.add(fGroup);
      fishMeshes.push({
        group: fGroup,
        tail: tail,
        offset: Math.random() * Math.PI * 2,
        speed: 0.8 + Math.random() * 0.5
      });
    }
  }
  buildFishPool(45);

  function updateFish(fishPosList, timeSec) {
    const gridW = 65.0;
    const n = envData?.size || 100;

    if (Array.isArray(fishPosList) && fishPosList.length > 0) {
      for (let i = 0; i < Math.min(fishPosList.length, fishMeshes.length); i++) {
        const p = fishPosList[i];
        const fm = fishMeshes[i];
        const wx = (p[0] / n - 0.5) * gridW;
        const wz = (p[1] / n - 0.5) * gridW;

        // Smooth translation
        const prevX = fm.group.position.x;
        const prevZ = fm.group.position.z;
        fm.group.position.x += (wx - prevX) * 0.12;
        fm.group.position.z += (wz - prevZ) * 0.12;

        // Heading direction from delta motion
        const dx = wx - prevX;
        const dz = wz - prevZ;
        if (Math.hypot(dx, dz) > 0.01) {
          const heading = Math.atan2(dz, dx);
          fm.group.rotation.y = -heading;
        }

        // Tail wagging animation
        fm.tail.rotation.y = Math.sin(timeSec * 8.0 * fm.speed + fm.offset) * 0.45;
      }
    } else {
      // Autonomous gentle wandering
      fishMeshes.forEach((fm, idx) => {
        fm.group.position.x += Math.sin(timeSec * 0.5 + fm.offset) * 0.03;
        fm.group.position.z += Math.cos(timeSec * 0.5 + fm.offset) * 0.03;
        fm.tail.rotation.y = Math.sin(timeSec * 7.0 + fm.offset) * 0.4;
      });
    }
  }

  // =========================================================================
  // 6. REALISTIC 3D SEABED BIOMES (60% Rock, 30% Coral, 10% Sand)
  // =========================================================================
  function buildWorld(data) {
    envData = data || { size: 100, heights: [], classes: [], goal: [75, 75] };
    worldGroup.clear();
    pathPoints = [];

    const n = envData.size || 100;
    const gridW = 65.0;
    const segments = 90;

    // Continuous Bathymetric Bedrock Geometry
    const geo = new THREE.PlaneGeometry(gridW, gridW, segments, segments);
    geo.rotateX(-Math.PI / 2);

    const pos = geo.attributes.position;
    const heights = envData.heights || [];
    const classes = envData.classes || [];

    for (let i = 0; i < pos.count; i++) {
      const gx = Math.min(Math.floor(i % (segments + 1)), n - 1);
      const gy = Math.min(Math.floor(i / (segments + 1)), n - 1);
      const h = (heights[gy] && heights[gy][gx] != null) ? heights[gy][gx] : 2;

      // Multi-scale procedural elevation (dunes, rocky shelves, ocean floor variation)
      const nx = (gx / n) * 9.0;
      const ny = (gy / n) * 9.0;
      const dunes = Math.sin(nx * 2.2) * Math.cos(ny * 2.2) * 0.45 + Math.sin(nx * 6.5 + ny * 4.2) * 0.18;
      const ridges = Math.cos(nx * 1.4 - ny * 1.8) * 0.35;
      pos.setY(i, -(h * 0.14 + dunes + ridges + 3.8));
    }
    geo.computeVertexNormals();

    // Biome Colors (Photorealistic Palette: 0=Rock 60%, 1=Sand 10%, 2=Coral 30%)
    const colors = new Float32Array(pos.count * 3);
    const biomePalette = [
      [0.22, 0.25, 0.28], // Rock: Dark Basalt / Marine Slate
      [0.68, 0.60, 0.42], // Sand: Natural Golden-Beige / Oceanic Silt
      [0.58, 0.26, 0.34]  // Coral Reef: Warm Terracotta / Violet / Coral Rose
    ];

    for (let i = 0; i < pos.count; i++) {
      const gx = Math.min(Math.floor(i % (segments + 1)), n - 1);
      const gy = Math.min(Math.floor(i / (segments + 1)), n - 1);
      const cIdx = (classes[gy] && classes[gy][gx] != null) ? classes[gy][gx] : (i % 3);
      const baseCol = biomePalette[cIdx] || biomePalette[0];
      const grain = ((gx * 43 + gy * 23) % 25) / 100.0 - 0.12;

      colors[i * 3] = Math.max(0.08, Math.min(0.85, baseCol[0] + grain * 0.4));
      colors[i * 3 + 1] = Math.max(0.08, Math.min(0.85, baseCol[1] + grain * 0.4));
      colors[i * 3 + 2] = Math.max(0.08, Math.min(0.85, baseCol[2] + grain * 0.4));
    }
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const terrainMat = new THREE.MeshStandardMaterial({
      vertexColors: true,
      roughness: 0.88,
      metalness: 0.12,
      map: causticsTexture
    });

    const terrainMesh = new THREE.Mesh(geo, terrainMat);
    terrainMesh.receiveShadow = true;
    worldGroup.add(terrainMesh);

    // =======================================================================
    // 6A. WEATHERED BASALT ROCKS & BOULDERS (60% Rock Area)
    // =======================================================================
    for (let k = 0; k < 220; k++) {
      const rx = (Math.random() - 0.5) * (gridW - 4);
      const rz = (Math.random() - 0.5) * (gridW - 4);
      const s = 0.4 + Math.random() * 1.6;
      
      const rockGeo = new THREE.DodecahedronGeometry(s, 2);
      const rPos = rockGeo.attributes.position;
      for (let vi = 0; vi < rPos.count; vi++) {
        const vx = rPos.getX(vi);
        const vy = rPos.getY(vi);
        const vz = rPos.getZ(vi);
        const deform = 1.0 + (Math.sin(vx * 4) + Math.cos(vy * 4) + Math.sin(vz * 4)) * 0.12;
        rPos.setXYZ(vi, vx * deform, vy * deform * 0.7, vz * deform);
      }
      rockGeo.computeVertexNormals();

      const rockMat = new THREE.MeshStandardMaterial({
        color: (k % 3 === 0) ? 0x222a2e : (k % 3 === 1 ? 0x2e363b : 0x1a2022),
        roughness: 0.95,
        metalness: 0.05
      });
      const rock = new THREE.Mesh(rockGeo, rockMat);
      rock.position.set(rx, -4.1 - Math.random() * 0.6, rz);
      rock.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);
      rock.castShadow = true;
      rock.receiveShadow = true;
      worldGroup.add(rock);
    }

    // =======================================================================
    // 6B. DIVERSE 3D CORAL REEF FORMATIONS (30% Coral Reef Area)
    // =======================================================================
    // 1. Branching Staghorn & Elkhorn Corals
    const coralHues = [0xbf4b3b, 0x8a3875, 0xd47535, 0x488a7c, 0xa13350, 0x6e2f69];
    for (let k = 0; k < 110; k++) {
      const cx = (Math.random() - 0.5) * (gridW - 4);
      const cz = (Math.random() - 0.5) * (gridW - 4);
      const col = coralHues[k % coralHues.length];
      const coralColony = new THREE.Group();
      coralColony.position.set(cx, -3.95, cz);

      const branchCount = 4 + Math.floor(Math.random() * 4);
      for (let b = 0; b < branchCount; b++) {
        const branchLen = 0.8 + Math.random() * 1.3;
        const branch = new THREE.Mesh(
          new THREE.ConeGeometry(0.16 + Math.random() * 0.12, branchLen, 8),
          new THREE.MeshStandardMaterial({ color: col, roughness: 0.78 })
        );
        const ang = (b / branchCount) * Math.PI * 2 + (Math.random() - 0.5) * 0.5;
        const tilt = 0.25 + Math.random() * 0.35;
        branch.position.set(Math.cos(ang) * 0.25, branchLen * 0.48, Math.sin(ang) * 0.25);
        branch.rotation.set(Math.sin(ang) * tilt, Math.random() * Math.PI, Math.cos(ang) * tilt);
        branch.castShadow = true;
        coralColony.add(branch);

        const tip = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 8), new THREE.MeshStandardMaterial({
          color: 0xffeedd,
          roughness: 0.6
        }));
        tip.position.set(0, branchLen / 2, 0);
        branch.add(tip);
      }
      worldGroup.add(coralColony);
    }

    // 2. Table / Shelf Coral Plates
    for (let k = 0; k < 45; k++) {
      const tx = (Math.random() - 0.5) * (gridW - 6);
      const tz = (Math.random() - 0.5) * (gridW - 6);
      const tableGroup = new THREE.Group();
      tableGroup.position.set(tx, -4.0, tz);

      const stem = new THREE.Mesh(
        new THREE.CylinderGeometry(0.18, 0.3, 0.9, 12),
        new THREE.MeshStandardMaterial({ color: 0x422d26, roughness: 0.9 })
      );
      stem.position.y = 0.45;
      tableGroup.add(stem);

      const plateRadius = 0.8 + Math.random() * 1.1;
      const plate = new THREE.Mesh(
        new THREE.CylinderGeometry(plateRadius, plateRadius * 0.85, 0.1, 16),
        new THREE.MeshStandardMaterial({ color: 0xa84a38, roughness: 0.75 })
      );
      plate.position.y = 0.9;
      plate.rotation.x = (Math.random() - 0.5) * 0.18;
      plate.rotation.z = (Math.random() - 0.5) * 0.18;
      plate.castShadow = true;
      tableGroup.add(plate);

      worldGroup.add(tableGroup);
    }

    // 3. Brain Corals
    for (let k = 0; k < 50; k++) {
      const bx = (Math.random() - 0.5) * (gridW - 6);
      const bz = (Math.random() - 0.5) * (gridW - 6);
      const rad = 0.5 + Math.random() * 0.6;
      const brainGeo = new THREE.SphereGeometry(rad, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2);
      const brainMat = new THREE.MeshStandardMaterial({
        color: (k % 2 === 0) ? 0x967c3b : 0x7a6345,
        roughness: 0.85
      });
      const brain = new THREE.Mesh(brainGeo, brainMat);
      brain.position.set(bx, -4.1, bz);
      brain.castShadow = true;
      worldGroup.add(brain);
    }

    // =======================================================================
    // 6C. UNDERWATER SEAGRASS
    // =======================================================================
    for (let k = 0; k < 70; k++) {
      const gx = (Math.random() - 0.5) * (gridW - 4);
      const gz = (Math.random() - 0.5) * (gridW - 4);
      const grassGroup = new THREE.Group();
      grassGroup.position.set(gx, -4.0, gz);

      for (let b = 0; b < 6; b++) {
        const bladeH = 0.7 + Math.random() * 0.9;
        const blade = new THREE.Mesh(
          new THREE.PlaneGeometry(0.08, bladeH, 1, 4),
          new THREE.MeshStandardMaterial({ color: 0x227848, side: THREE.DoubleSide, roughness: 0.7 })
        );
        blade.position.set((Math.random() - 0.5) * 0.3, bladeH / 2, (Math.random() - 0.5) * 0.3);
        blade.rotation.set((Math.random() - 0.5) * 0.25, Math.random() * Math.PI, (Math.random() - 0.5) * 0.25);
        grassGroup.add(blade);
      }
      worldGroup.add(grassGroup);
    }

    // =======================================================================
    // 6D. SUSPENDED MARINE SNOW PARTICLES
    // =======================================================================
    const pCount = 1200;
    const pPos = new Float32Array(pCount * 3);
    for (let i = 0; i < pCount * 3; i += 3) {
      pPos[i] = (Math.random() - 0.5) * gridW;
      pPos[i + 1] = -5.5 + Math.random() * 12;
      pPos[i + 2] = (Math.random() - 0.5) * gridW;
    }
    const pGeo = new THREE.BufferGeometry();
    pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
    const pMat = new THREE.PointsMaterial({ color: 0x92edff, size: 0.12, transparent: true, opacity: 0.45 });
    particlePoints = new THREE.Points(pGeo, pMat);
    worldGroup.add(particlePoints);

    buildHUDMarkers(envData);
  }

  function buildHUDMarkers(data) {
    hudMarkersGroup.clear();
    const n = data?.size || 100;
    const gridW = 65.0;

    // Start Point Ring (◯)
    const ringGeo = new THREE.RingGeometry(0.8, 1.1, 32);
    ringGeo.rotateX(-Math.PI / 2);
    startMarker = new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({ color: 0x38ef67, side: THREE.DoubleSide }));
    startMarker.position.set(0, -3.95, 0);
    hudMarkersGroup.add(startMarker);

    // Current Position Dot (●)
    const curGeo = new THREE.CircleGeometry(0.48, 24);
    curGeo.rotateX(-Math.PI / 2);
    curMarker = new THREE.Mesh(curGeo, new THREE.MeshBasicMaterial({ color: 0x38ef67, side: THREE.DoubleSide }));
    curMarker.position.set(0, -3.93, 0);
    hudMarkersGroup.add(curMarker);

    // Goal Target Ring (◉)
    if (data?.goal) {
      const gx = (data.goal[0] / n - 0.5) * gridW;
      const gz = (data.goal[1] / n - 0.5) * gridW;
      const goalGeo = new THREE.RingGeometry(0.9, 1.25, 32);
      goalGeo.rotateX(-Math.PI / 2);
      const goalMesh = new THREE.Mesh(goalGeo, new THREE.MeshBasicMaterial({ color: 0xeb4545, side: THREE.DoubleSide }));
      goalMesh.position.set(gx, -3.95, gz);
      hudMarkersGroup.add(goalMesh);
    }
  }

  buildWorld(null);

  // =========================================================================
  // 7. REALISTIC EXPLORATION PATH TRAJECTORY
  // =========================================================================
  function updatePaths() {
    pathGroup.clear();
    if (pathPoints.length < 2) return;

    const n = envData?.size || 100;
    const gridW = 65.0;
    const numPts = pathPoints.length;

    const positions = new Float32Array(numPts * 3);
    const colors = new Float32Array(numPts * 3);

    for (let i = 0; i < numPts; i++) {
      const p = pathPoints[i];
      const wx = (p[0] / n - 0.5) * gridW;
      const wz = (p[1] / n - 0.5) * gridW;
      const wy = -3.9;

      positions[i * 3] = wx;
      positions[i * 3 + 1] = wy;
      positions[i * 3 + 2] = wz;

      const t = i / Math.max(1, numPts - 1);
      const col = new THREE.Color();
      if (t < 0.3) {
        col.setHSL(0.42 - t * 0.7, 0.95, 0.55); // Cyan -> Green -> Yellow
      } else if (t < 0.7) {
        col.setHSL(0.2 - (t - 0.3) * 0.5, 0.95, 0.55); // Yellow -> Orange
      } else {
        col.setHSL(0.85 + (t - 0.7) * 0.35, 0.9, 0.55); // Purple -> Blue -> Green
      }
      colors[i * 3] = col.r;
      colors[i * 3 + 1] = col.g;
      colors[i * 3 + 2] = col.b;
    }

    const pathGeo = new THREE.BufferGeometry();
    pathGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    pathGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const pathMat = new THREE.LineBasicMaterial({
      vertexColors: true,
      linewidth: 3.5,
      transparent: true,
      opacity: 0.95
    });

    pathGroup.add(new THREE.Line(pathGeo, pathMat));

    if (startMarker && pathPoints.length > 0) {
      const s = pathPoints[0];
      startMarker.position.set((s[0] / n - 0.5) * gridW, -3.95, (s[1] / n - 0.5) * gridW);
    }
  }

  // =========================================================================
  // 8. REAL TELEMETRY SYNCHRONIZATION
  // =========================================================================
  function updateRobot(r) {
    if (!r) return;
    robotState = r;
    const n = envData?.size || 100;
    const gridW = 65.0;

    // Real coordinate conversion
    const wx = (r.x / n - 0.5) * gridW;
    const wz = (r.y / n - 0.5) * gridW;

    // Real depth: mapped safely above seabed
    const depthMeters = Number(r.depth) || 8.4;
    const wy = 3.0 - (depthMeters / 30.0) * 6.0;

    auvGroup.position.set(wx, wy, wz);

    // Heading conversion
    const headingDeg = Number(r.heading) || 0;
    const headingRad = deg2rad(headingDeg);
    auvGroup.rotation.set(0, -headingRad, 0);

    // Update HUD Debug Badge
    const dbgX = document.getElementById('dbgX');
    const dbgY = document.getElementById('dbgY');
    const dbgDepth = document.getElementById('dbgDepth');
    const dbgHeading = document.getElementById('dbgHeading');
    const dbgTerrain = document.getElementById('dbgTerrain');
    if (dbgX) dbgX.textContent = Number(r.x).toFixed(1);
    if (dbgY) dbgY.textContent = Number(r.y).toFixed(1);
    if (dbgDepth) dbgDepth.textContent = Number(r.depth).toFixed(1);
    if (dbgHeading) dbgHeading.textContent = Number(r.heading).toFixed(0);
    if (dbgTerrain && r.current_terrain) dbgTerrain.textContent = r.current_terrain.toUpperCase();

    if (curMarker) {
      curMarker.position.set(wx, -3.93, wz);
    }

    // Mini Robot Camera in Submarine Nose
    cam.position.set(wx, wy + 0.1, wz);
    cam.rotation.set(0, -headingRad, 0);
    const forwardVec = new THREE.Vector3(Math.cos(-headingRad), -0.15, Math.sin(-headingRad));
    cam.lookAt(cam.position.clone().add(forwardVec.multiplyScalar(8)));

    // Compass Needle
    const needle = document.getElementById('compassNeedle');
    if (needle) {
      needle.style.transform = `rotate(${headingDeg}deg)`;
    }
  }

  // =========================================================================
  // 9. DYNAMIC CHASE & ORBIT CAMERA MODES
  // =========================================================================
  let isDragging = false;
  let prevMouse = { x: 0, y: 0 };
  let spherical = { radius: 24, theta: 0.85, phi: 1.05 };

  wrap.addEventListener('mousedown', e => {
    isDragging = true;
    prevMouse = { x: e.clientX, y: e.clientY };
  });
  window.addEventListener('mouseup', () => { isDragging = false; });
  window.addEventListener('mousemove', e => {
    if (!isDragging) return;
    const dx = e.clientX - prevMouse.x;
    const dy = e.clientY - prevMouse.y;
    prevMouse = { x: e.clientX, y: e.clientY };

    spherical.theta -= dx * 0.006;
    spherical.phi = Math.max(0.15, Math.min(Math.PI / 2 - 0.05, spherical.phi - dy * 0.006));
  });
  wrap.addEventListener('wheel', e => {
    spherical.radius = Math.max(6, Math.min(65, spherical.radius + e.deltaY * 0.025));
  }, { passive: true });

  // Camera Mode buttons in UI
  document.querySelectorAll('.cam-btn').forEach(btn => {
    btn.onclick = () => {
      document.querySelectorAll('.cam-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      cameraMode = btn.getAttribute('data-cam');
      if (cameraMode === 'top') {
        spherical.phi = 0.05;
        spherical.radius = 35;
      } else if (cameraMode === 'chase') {
        spherical.phi = 1.05;
        spherical.radius = 24;
      }
    };
  });

  function updateCamera() {
    const target = auvGroup.position;
    if (cameraMode === 'chase') {
      // Cinematic Chase Behind AUV
      const headingRad = deg2rad(robotState.heading || 0);
      const chaseDist = 18.0;
      const chaseHeight = 7.5;
      const targetCamX = target.x - Math.cos(-headingRad) * chaseDist;
      const targetCamZ = target.z - Math.sin(-headingRad) * chaseDist;
      const targetCamY = target.y + chaseHeight;

      camera.position.x += (targetCamX - camera.position.x) * 0.08;
      camera.position.y += (targetCamY - camera.position.y) * 0.08;
      camera.position.z += (targetCamZ - camera.position.z) * 0.08;
      camera.lookAt(target.x, target.y - 0.2, target.z);
    } else if (cameraMode === 'top') {
      // Top-Down Overview Camera
      camera.position.x += (target.x - camera.position.x) * 0.1;
      camera.position.y += (target.y + spherical.radius - camera.position.y) * 0.1;
      camera.position.z += (target.z + 0.1 - camera.position.z) * 0.1;
      camera.lookAt(target.x, target.y, target.z);
    } else {
      // Free Orbit
      camera.position.x = target.x + spherical.radius * Math.sin(spherical.phi) * Math.sin(spherical.theta);
      camera.position.y = target.y + spherical.radius * Math.cos(spherical.phi);
      camera.position.z = target.z + spherical.radius * Math.sin(spherical.phi) * Math.cos(spherical.theta);
      camera.lookAt(target.x, target.y - 0.4, target.z);
    }
  }

  // =========================================================================
  // 10. ANIMATION LOOP
  // =========================================================================
  let clockTime = 0;
  function animate() {
    requestAnimationFrame(animate);
    clockTime += 0.016;

    // Propeller rotates proportionally to real AUV speed
    const currentSpeed = Number(robotState.speed) || 0.0;
    if (propMesh) {
      if (currentSpeed > 0.01) {
        propMesh.rotation.x += currentSpeed * 0.45 + 0.15;
      }
    }

    // Dynamic water caustics animation
    updateCaustics(clockTime);

    // Drifting marine snow particulates
    if (particlePoints) {
      particlePoints.rotation.y = clockTime * 0.03;
    }

    // Update 3D Fish
    updateFish(window._latestFishPositions || [], clockTime);

    updateCamera();

    renderer.render(scene, camera);
    if (mini) {
      mini.render(scene, cam);
    }
  }
  animate();

  // EXPORT GLOBAL INTERFACE
  window.auvScene = {
    buildWorld,
    updateRobot,
    setPath: (p) => {
      pathPoints = p || [];
      updatePaths();
    },
    resetCamera: () => {
      spherical = { radius: 24, theta: 0.85, phi: 1.05 };
      cameraMode = 'chase';
      document.querySelectorAll('.cam-btn').forEach(b => b.classList.toggle('active', b.getAttribute('data-cam') === 'chase'));
    }
  };

  // Fetch Environment from Backend
  fetch('/api/environment')
    .then(r => r.json())
    .then(buildWorld)
    .catch(() => {});

  // Responsive Resize Observer
  const ro = new ResizeObserver(() => {
    const { w, h } = getContainerSize();
    renderer.setSize(w, h);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();

    if (camCanvas && mini) {
      const mw = camCanvas.clientWidth || 220;
      const mh = camCanvas.clientHeight || 140;
      mini.setSize(mw, mh);
      cam.aspect = mw / mh;
      cam.updateProjectionMatrix();
    }
  });
  ro.observe(wrap);
})();
