from stable_baselines3 import PPO
from env.auv_env import UnderwaterExplorationEnv
from pathlib import Path

def run(seed=12345,steps=5000):
    p=Path('models/ppo_auv.zip')
    if not p.exists(): raise FileNotFoundError('models/ppo_auv.zip not found. Train PPO first with rl/train_ppo.py.')
    env=UnderwaterExplorationEnv(seed=seed); model=PPO.load(p,env=env); obs,_=env.reset(seed=seed); done=False; i=0
    while not done and i<steps:
        action,_=model.predict(obs,deterministic=True); obs,rew,done,_,info=env.step(action); i+=1
    return env
if __name__=='__main__': print(run().total_reward)
