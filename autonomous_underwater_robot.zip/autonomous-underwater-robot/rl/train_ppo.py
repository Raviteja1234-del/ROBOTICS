from __future__ import annotations

# Allow direct execution such as: python cnn/train_cnn.py from the project root.
import sys
from pathlib import Path as _BootstrapPath
_PROJECT_ROOT = _BootstrapPath(__file__).resolve().parents[1]
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))
import argparse
from stable_baselines3 import PPO
from stable_baselines3.common.monitor import Monitor
from env.auv_env import UnderwaterExplorationEnv
from rl.callbacks import JsonRewardCallback

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--timesteps',type=int,default=100_000); ap.add_argument('--seed',type=int,default=12345); args=ap.parse_args()
    env=Monitor(UnderwaterExplorationEnv(seed=args.seed)); model=PPO('MlpPolicy',env,verbose=1,seed=args.seed,tensorboard_log='logs/tensorboard',n_steps=1024,batch_size=256,learning_rate=3e-4)
    model.learn(total_timesteps=args.timesteps,callback=JsonRewardCallback()); model.save('models/ppo_auv.zip'); env.close()
if __name__=='__main__': main()
