from stable_baselines3.common.callbacks import BaseCallback
import json
from pathlib import Path
class JsonRewardCallback(BaseCallback):
    def __init__(self,path='logs/ppo_rewards.jsonl',verbose=0): super().__init__(verbose); self.path=Path(path); self.path.parent.mkdir(exist_ok=True)
    def _on_step(self):
        if len(self.model.ep_info_buffer):
            r=self.model.ep_info_buffer[-1].get('r');
            if r is not None: self.path.open('a',encoding='utf-8').write(json.dumps({'timesteps':self.num_timesteps,'reward':float(r)})+'\n')
        return True
