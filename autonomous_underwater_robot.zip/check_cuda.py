import torch, json, sys
print(json.dumps({"cuda": torch.cuda.is_available(), "device_count": torch.cuda.device_count() if torch.cuda.is_available() else 0}))
