"""
Universal PyQt6 / PyQt5 Mission Control Dashboard for Autonomous Underwater Robot.
Matches the dark-themed command center layout with real-time telemetry polling.
"""

from __future__ import annotations
import os
import sys
import time
import math
import threading
from typing import Dict, Any, Optional
import numpy as np
import cv2

# Set Qt binding for pyqtgraph
os.environ.setdefault("PYQTGRAPH_QT_LIB", "PyQt5")

try:
    from PyQt5.QtCore import Qt, QTimer, QRectF, QPointF
    from PyQt5.QtGui import QImage, QPixmap, QColor, QPainter, QBrush, QPen, QFont, QLinearGradient, QConicalGradient
    from PyQt5.QtWidgets import (
        QApplication, QMainWindow, QWidget, QLabel, QPushButton, QComboBox,
        QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox, QFrame, QSizePolicy,
        QProgressBar
    )
    ALIGN_CENTER = Qt.AlignCenter
    NO_BRUSH = Qt.NoBrush
    NO_PEN = Qt.NoPen
    KEEP_ASPECT = Qt.KeepAspectRatio
    FORMAT_RGB32 = QImage.Format_RGB32
    FORMAT_RGB888 = QImage.Format_RGB888
    FRAME_STYLED = QFrame.StyledPanel
    SIZE_EXPANDING = QSizePolicy.Expanding
except Exception:
    from PyQt6.QtCore import Qt, QTimer, QRectF, QPointF
    from PyQt6.QtGui import QImage, QPixmap, QColor, QPainter, QBrush, QPen, QFont, QLinearGradient, QConicalGradient
    from PyQt6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QLabel, QPushButton, QComboBox,
        QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox, QFrame, QSizePolicy,
        QProgressBar
    )
    ALIGN_CENTER = Qt.AlignmentFlag.AlignCenter
    NO_BRUSH = Qt.BrushStyle.NoBrush
    NO_PEN = Qt.PenStyle.NoPen
    KEEP_ASPECT = Qt.AspectRatioMode.KeepAspectRatio
    FORMAT_RGB32 = QImage.Format.Format_RGB32
    FORMAT_RGB888 = QImage.Format.Format_RGB888
    FRAME_STYLED = QFrame.Shape.StyledPanel
    SIZE_EXPANDING = QSizePolicy.Policy.Expanding

import pyqtgraph as pg

# Configure pyqtgraph styling for dark mission control
pg.setConfigOption('background', '#040c12')
pg.setConfigOption('foreground', '#8ea4ae')
pg.setConfigOption('antialias', True)


class DonutWidget(QWidget):
    """Custom painted donut pie chart for seabed exploration biomes."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.rock_pct = 45.0
        self.sand_pct = 35.0
        self.coral_pct = 20.0
        self.setMinimumSize(70, 70)
        self.setSizePolicy(SIZE_EXPANDING, SIZE_EXPANDING)

    def update_values(self, rock: float, sand: float, coral: float):
        self.rock_pct = max(0.0, rock)
        self.sand_pct = max(0.0, sand)
        self.coral_pct = max(0.0, coral)
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        try:
            painter.setRenderHint(QPainter.Antialiasing)
        except AttributeError:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        w = self.width()
        h = self.height()
        dim = min(w, h) - 6
        rect = QRectF((w - dim) / 2, (h - dim) / 2, dim, dim)

        total = self.rock_pct + self.sand_pct + self.coral_pct
        if total <= 0:
            total = 1.0

        span_coral = int((self.coral_pct / total) * 360 * 16)
        span_sand = int((self.sand_pct / total) * 360 * 16)
        span_rock = 360 * 16 - span_coral - span_sand

        # Coral segment (Purple #8135bd)
        painter.setBrush(QBrush(QColor("#8135bd")))
        painter.setPen(NO_PEN)
        start_angle = 90 * 16
        painter.drawPie(rect, start_angle, span_coral)

        # Sand segment (Gold #d4ad1b)
        painter.setBrush(QBrush(QColor("#d4ad1b")))
        start_angle += span_coral
        painter.drawPie(rect, start_angle, span_sand)

        # Rock segment (Brown #ad6428)
        painter.setBrush(QBrush(QColor("#ad6428")))
        start_angle += span_sand
        painter.drawPie(rect, start_angle, span_rock)

        # Center cutout for donut hole
        hole_dim = dim * 0.54
        hole_rect = QRectF((w - hole_dim) / 2, (h - hole_dim) / 2, hole_dim, hole_dim)
        painter.setBrush(QBrush(QColor("#040b10")))
        painter.drawEllipse(hole_rect)


class SeabedMapWidget(QWidget):
    """Custom 2D Top-View Seabed Classification Map with live AUV trajectory overlay."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.grid_size = 100
        self.classified_map = np.full((100, 100), -1, dtype=np.int8)
        self.explored_mask = np.zeros((100, 100), dtype=bool)
        self.path_history = []
        self.robot_pos = (15.0, 15.0)
        self.setMinimumSize(180, 140)

    def update_map(self, classified: np.ndarray, explored: np.ndarray, path: list, pos: tuple):
        self.classified_map = classified.copy()
        self.explored_mask = explored.copy()
        self.path_history = list(path)
        self.robot_pos = pos
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        try:
            painter.setRenderHint(QPainter.Antialiasing)
        except AttributeError:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        w = self.width()
        h = self.height()
        painter.fillRect(0, 0, w, h, QColor("#061017"))

        n = self.grid_size
        scale = min(w / n, h / n)
        off_x = (w - n * scale) / 2.0
        off_y = (h - n * scale) / 2.0

        # Draw grid cells
        color_unexplored = QColor("#0a1720")
        color_rock = QColor("#ad6428")
        color_sand = QColor("#d4ad1b")
        color_coral = QColor("#8135bd")
        color_default_exp = QColor("#223542")

        img_map = QImage(n, n, FORMAT_RGB32)
        for y in range(n):
            for x in range(n):
                if self.explored_mask[y, x]:
                    cl = self.classified_map[y, x]
                    c = color_rock if cl == 0 else (color_sand if cl == 1 else (color_coral if cl == 2 else color_default_exp))
                else:
                    c = color_unexplored
                img_map.setPixelColor(x, y, c)

        painter.drawImage(QRectF(off_x, off_y, n * scale, n * scale), img_map)

        # Draw path history
        if len(self.path_history) > 1:
            pen = QPen(QColor("#eed728"), 1.8)
            painter.setPen(pen)
            for i in range(len(self.path_history) - 1):
                p1 = self.path_history[i]
                p2 = self.path_history[i + 1]
                x1 = off_x + (p1[0] / n) * (n * scale)
                y1 = off_y + (p1[1] / n) * (n * scale)
                x2 = off_x + (p2[0] / n) * (n * scale)
                y2 = off_y + (p2[1] / n) * (n * scale)
                painter.drawLine(QPointF(x1, y1), QPointF(x2, y2))

            # Start Point ◯
            start_p = self.path_history[0]
            sx = off_x + (start_p[0] / n) * (n * scale)
            sy = off_y + (start_p[1] / n) * (n * scale)
            painter.setPen(QPen(QColor("#35f163"), 2))
            painter.setBrush(NO_BRUSH)
            painter.drawEllipse(QPointF(sx, sy), 3.5, 3.5)

        # Current Position ●
        rx = off_x + (self.robot_pos[0] / n) * (n * scale)
        ry = off_y + (self.robot_pos[1] / n) * (n * scale)
        painter.setPen(NO_PEN)
        painter.setBrush(QBrush(QColor("#35f163")))
        painter.drawEllipse(QPointF(rx, ry), 4.5, 4.5)


class DashboardWindow(QMainWindow):
    """Main Mission Control Window."""
    def __init__(self, shared_state: Dict[str, Any], state_lock: threading.Lock, control_callbacks: Dict[str, Any]):
        super().__init__()
        self.shared_state = shared_state
        self.state_lock = state_lock
        self.control_callbacks = control_callbacks
        self.start_time = time.time()

        # Telemetry History Buffers (200 samples)
        self.depth_history = []
        self.obstacle_history = []
        self.reward_history = []
        self.steps_history = []

        self.setWindowTitle("Autonomous Underwater Robot – Seabed Classification & Exploration")
        self.resize(1280, 800)
        self._apply_stylesheet()
        self._build_ui()

        # 100ms polling timer
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.poll_state)
        self.timer.start(100)

    def _apply_stylesheet(self):
        self.setStyleSheet("""
            QMainWindow, QWidget {
                background-color: #02060a;
                color: #cddbe2;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            }
            QFrame.panel {
                border: 1px solid #142833;
                background-color: #04090e;
                border-radius: 2px;
            }
            QLabel.panelTitle {
                background-color: #07121a;
                color: #cfdee4;
                font-size: 10px;
                font-weight: bold;
                padding: 4px 8px;
                border-bottom: 1px solid #112530;
                letter-spacing: 0.5px;
            }
            QPushButton {
                background-color: #081923;
                border: 1px solid #1c3c4d;
                color: #9cb2bd;
                font-size: 10px;
                font-weight: bold;
                padding: 4px 10px;
                border-radius: 2px;
            }
            QPushButton:hover {
                background-color: #0d2838;
                border-color: #388fb4;
                color: #ffffff;
            }
            QPushButton.activeSpeed {
                background-color: #0e313d;
                border-color: #35f163;
                color: #35f163;
            }
            QComboBox {
                background-color: #081923;
                border: 1px solid #1c3c4d;
                color: #9cb2bd;
                font-size: 10px;
                padding: 2px 6px;
            }
            QProgressBar {
                border: 1px solid #111e26;
                background-color: #0c161d;
                height: 9px;
                text-align: right;
                font-size: 8px;
                color: transparent;
            }
        """)

    def _build_ui(self):
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        root_layout = QVBoxLayout(main_widget)
        root_layout.setContentsMargins(8, 6, 8, 6)
        root_layout.setSpacing(6)

        # ----------------------------------------------------
        # 1. HEADER TITLE BAR
        # ----------------------------------------------------
        header_frame = QFrame()
        header_frame.setFixedHeight(34)
        header_frame.setStyleSheet("background-color: #04090e; border: 1px solid #142733; border-radius: 2px;")
        header_layout = QHBoxLayout(header_frame)
        header_layout.setContentsMargins(12, 0, 14, 0)

        header_title = QLabel("Autonomous Underwater Robot – Seabed Classification & Exploration (First Attempt)")
        header_title.setStyleSheet("font-size: 13px; font-weight: bold; color: #e2edf2;")
        header_layout.addWidget(header_title)
        header_layout.addStretch()

        self.led_dot = QLabel("●")
        self.led_dot.setStyleSheet("color: #25eb66; font-size: 14px;")
        header_layout.addWidget(self.led_dot)

        self.mission_status_lbl = QLabel("MISSION RUNNING")
        self.mission_status_lbl.setStyleSheet("color: #3de865; font-weight: bold; font-size: 11px;")
        header_layout.addWidget(self.mission_status_lbl)

        self.timer_lbl = QLabel("00:00:00")
        self.timer_lbl.setStyleSheet("color: #d1e2e8; font-family: monospace; font-size: 11px; margin-left: 8px;")
        header_layout.addWidget(self.timer_lbl)
        root_layout.addWidget(header_frame)

        # ----------------------------------------------------
        # 2. MAIN 3-COLUMN GRID
        # ----------------------------------------------------
        grid_layout = QGridLayout()
        grid_layout.setSpacing(6)
        root_layout.addLayout(grid_layout, stretch=1)

        # ------------------ LEFT COLUMN ------------------
        left_col = QVBoxLayout()
        left_col.setSpacing(6)

        # A. Robot View (Camera Feed)
        cam_box = QFrame()
        cam_box.setProperty("class", "panel")
        cam_box.setFrameShape(FRAME_STYLED)
        cam_v = QVBoxLayout(cam_box)
        cam_v.setContentsMargins(0, 0, 0, 0)
        cam_v.setSpacing(0)
        t_cam = QLabel("ROBOT VIEW (Live Camera Feed)")
        t_cam.setProperty("class", "panelTitle")
        cam_v.addWidget(t_cam)
        self.cam_label = QLabel()
        self.cam_label.setAlignment(ALIGN_CENTER)
        self.cam_label.setMinimumSize(180, 120)
        self.cam_label.setStyleSheet("background-color: #01131c;")
        cam_v.addWidget(self.cam_label, stretch=1)
        left_col.addWidget(cam_box, stretch=1)

        # B. CNN Classification
        cnn_box = QFrame()
        cnn_box.setProperty("class", "panel")
        cnn_box.setFrameShape(FRAME_STYLED)
        cnn_v = QVBoxLayout(cnn_box)
        cnn_v.setContentsMargins(0, 0, 0, 6)
        cnn_v.setSpacing(4)
        t_cnn = QLabel("CNN CLASSIFICATION (Current View)")
        t_cnn.setProperty("class", "panelTitle")
        cnn_v.addWidget(t_cnn)

        bars_layout = QVBoxLayout()
        bars_layout.setContentsMargins(8, 6, 8, 4)
        bars_layout.setSpacing(4)

        # Rock bar
        r_row = QHBoxLayout()
        r_lbl = QLabel("Rock")
        r_lbl.setStyleSheet("font-size: 10px; color: #bac8cf; min-width: 60px;")
        self.rock_bar = QProgressBar()
        self.rock_bar.setStyleSheet("QProgressBar::chunk { background-color: #ad6428; }")
        self.rock_val = QLabel("0.76")
        self.rock_val.setStyleSheet("font-size: 10px; font-family: monospace; color: #dbe6eb;")
        r_row.addWidget(r_lbl)
        r_row.addWidget(self.rock_bar, stretch=1)
        r_row.addWidget(self.rock_val)
        bars_layout.addLayout(r_row)

        # Sand bar
        s_row = QHBoxLayout()
        s_lbl = QLabel("Sand")
        s_lbl.setStyleSheet("font-size: 10px; color: #bac8cf; min-width: 60px;")
        self.sand_bar = QProgressBar()
        self.sand_bar.setStyleSheet("QProgressBar::chunk { background-color: #d4ad1b; }")
        self.sand_val = QLabel("0.18")
        self.sand_val.setStyleSheet("font-size: 10px; font-family: monospace; color: #dbe6eb;")
        s_row.addWidget(s_lbl)
        s_row.addWidget(self.sand_bar, stretch=1)
        s_row.addWidget(self.sand_val)
        bars_layout.addLayout(s_row)

        # Coral bar
        c_row = QHBoxLayout()
        c_lbl = QLabel("Coral Reef")
        c_lbl.setStyleSheet("font-size: 10px; color: #bac8cf; min-width: 60px;")
        self.coral_bar = QProgressBar()
        self.coral_bar.setStyleSheet("QProgressBar::chunk { background-color: #8135bd; }")
        self.coral_val = QLabel("0.06")
        self.coral_val.setStyleSheet("font-size: 10px; font-family: monospace; color: #dbe6eb;")
        c_row.addWidget(c_lbl)
        c_row.addWidget(self.coral_bar, stretch=1)
        c_row.addWidget(self.coral_val)
        bars_layout.addLayout(c_row)
        cnn_v.addLayout(bars_layout)

        # Predicted label
        pred_frame = QFrame()
        pred_frame.setStyleSheet("border-top: 1px solid #0f222b; margin-top: 4px; padding-top: 4px;")
        pred_layout = QVBoxLayout(pred_frame)
        pred_layout.setContentsMargins(0, 2, 0, 2)
        pred_t = QLabel("PREDICTION:")
        pred_t.setAlignment(ALIGN_CENTER)
        pred_t.setStyleSheet("font-size: 9px; color: #8da4ae;")
        self.pred_badge = QLabel("ROCKY")
        self.pred_badge.setAlignment(ALIGN_CENTER)
        self.pred_badge.setStyleSheet("font-size: 15px; font-weight: bold; color: #f09528; letter-spacing: 1px;")
        pred_layout.addWidget(pred_t)
        pred_layout.addWidget(self.pred_badge)
        cnn_v.addWidget(pred_frame)
        left_col.addWidget(cnn_box, stretch=1)

        # C. Robot Status
        stat_box = QFrame()
        stat_box.setProperty("class", "panel")
        stat_box.setFrameShape(FRAME_STYLED)
        stat_v = QVBoxLayout(stat_box)
        stat_v.setContentsMargins(0, 0, 0, 0)
        stat_v.setSpacing(0)
        t_stat = QLabel("ROBOT STATUS")
        t_stat.setProperty("class", "panelTitle")
        stat_v.addWidget(t_stat)

        stat_grid = QGridLayout()
        stat_grid.setContentsMargins(10, 8, 10, 8)
        stat_grid.setSpacing(5)

        labels = ["Depth:", "Speed:", "Battery:", "Heading:", "Mode:", "RL Algorithm:", "Episode:", "Step:"]
        self.stat_vals = {}
        for idx, name in enumerate(labels):
            lbl_k = QLabel(name)
            lbl_k.setStyleSheet("color: #7d96a0; font-size: 10px;")
            lbl_v = QLabel("--")
            lbl_v.setStyleSheet("color: #e1edf2; font-weight: bold; font-size: 10px;")
            stat_grid.addWidget(lbl_k, idx, 0)
            stat_grid.addWidget(lbl_v, idx, 1)
            self.stat_vals[name] = lbl_v

        self.stat_vals["RL Algorithm:"].setText("PPO")
        stat_v.addLayout(stat_grid)
        left_col.addWidget(stat_box, stretch=1)
        grid_layout.addLayout(left_col, 0, 0, 2, 1)

        # ------------------ CENTER COLUMN (3D View + Controls) ------------------
        center_col = QVBoxLayout()
        center_col.setSpacing(6)

        center_box = QFrame()
        center_box.setProperty("class", "panel")
        center_box.setFrameShape(FRAME_STYLED)
        center_v = QVBoxLayout(center_box)
        center_v.setContentsMargins(0, 0, 0, 0)
        center_v.setSpacing(0)

        t_center = QLabel("3D ENVIRONMENT VIEW")
        t_center.setProperty("class", "panelTitle")
        center_v.addWidget(t_center)

        # 3D Chase camera viewport frame
        self.chase_label = QLabel()
        self.chase_label.setAlignment(ALIGN_CENTER)
        self.chase_label.setMinimumSize(420, 280)
        self.chase_label.setStyleSheet("background-color: #021118;")
        center_v.addWidget(self.chase_label, stretch=1)

        # Controls Toolbar
        ctrl_bar = QFrame()
        ctrl_bar.setFixedHeight(34)
        ctrl_bar.setStyleSheet("background-color: #040c12; border-top: 1px solid #112530;")
        ctrl_layout = QHBoxLayout(ctrl_bar)
        ctrl_layout.setContentsMargins(8, 2, 8, 2)
        ctrl_layout.setSpacing(5)

        self.btn_start = QPushButton("START")
        self.btn_start.clicked.connect(self._on_start)
        self.btn_pause = QPushButton("PAUSE")
        self.btn_pause.clicked.connect(self._on_pause)
        self.btn_reset = QPushButton("RESET")
        self.btn_reset.clicked.connect(self._on_reset)
        self.btn_new_env = QPushButton("NEW RANDOM ENVIRONMENT")
        self.btn_new_env.clicked.connect(self._on_new_env)

        ctrl_layout.addWidget(self.btn_start)
        ctrl_layout.addWidget(self.btn_pause)
        ctrl_layout.addWidget(self.btn_reset)
        ctrl_layout.addWidget(self.btn_new_env)

        # Speed Multiplier Buttons
        ctrl_layout.addSpacing(10)
        spd_lbl = QLabel("Speed:")
        spd_lbl.setStyleSheet("font-size: 9px; color: #6d8692;")
        ctrl_layout.addWidget(spd_lbl)

        self.spd_btns = {}
        for spd in [1, 2, 4, 8]:
            btn = QPushButton(f"{spd}×")
            btn.setFixedWidth(28)
            btn.clicked.connect(lambda ch, s=spd: self._set_speed(s))
            if spd == 1:
                btn.setProperty("class", "activeSpeed")
            ctrl_layout.addWidget(btn)
            self.spd_btns[spd] = btn

        ctrl_layout.addStretch()
        center_v.addWidget(ctrl_bar)
        center_col.addWidget(center_box, stretch=1)
        grid_layout.addLayout(center_col, 0, 1, 1, 1)

        # ------------------ RIGHT COLUMN (Map & RL Plot) ------------------
        right_col = QVBoxLayout()
        right_col.setSpacing(6)

        # A. Seabed 2D Classification Map
        map_box = QFrame()
        map_box.setProperty("class", "panel")
        map_box.setFrameShape(FRAME_STYLED)
        map_v = QVBoxLayout(map_box)
        map_v.setContentsMargins(0, 0, 0, 0)
        map_v.setSpacing(0)
        t_map = QLabel("SEABED CLASSIFICATION MAP (Top View)")
        t_map.setProperty("class", "panelTitle")
        map_v.addWidget(t_map)

        self.map_widget = SeabedMapWidget()
        map_v.addWidget(self.map_widget, stretch=1)

        # Map Legend Bar
        map_legend = QFrame()
        map_legend.setFixedHeight(22)
        map_legend.setStyleSheet("background-color: #040a0f; border-top: 1px solid #0e202a;")
        leg_layout = QHBoxLayout(map_legend)
        leg_layout.setContentsMargins(6, 0, 6, 0)
        leg_layout.setSpacing(8)

        for name, col in [("Rock", "#ad6428"), ("Sand", "#d4ad1b"), ("Coral Reef", "#8135bd"), ("Unexplored", "#131f28")]:
            dot = QLabel("■")
            dot.setStyleSheet(f"color: {col}; font-size: 9px;")
            txt = QLabel(name)
            txt.setStyleSheet("color: #a4b7bf; font-size: 8.5px;")
            leg_layout.addWidget(dot)
            leg_layout.addWidget(txt)
        leg_layout.addStretch()
        map_v.addWidget(map_legend)
        right_col.addWidget(map_box, stretch=1)

        # B. RL Training Plot
        rl_box = QFrame()
        rl_box.setProperty("class", "panel")
        rl_box.setFrameShape(FRAME_STYLED)
        rl_v = QVBoxLayout(rl_box)
        rl_v.setContentsMargins(0, 0, 0, 0)
        rl_v.setSpacing(0)
        t_rl = QLabel("RL TRAINING (Live Plot)")
        t_rl.setProperty("class", "panelTitle")
        rl_v.addWidget(t_rl)

        self.rl_plot = pg.PlotWidget()
        self.rl_plot.showGrid(x=True, y=True, alpha=0.15)
        self.rl_plot.setLabel('bottom', 'Episode Steps', color='#7a949f', size='8pt')
        self.rl_plot.setLabel('left', 'Reward', color='#7a949f', size='8pt')
        self.rl_curve = self.rl_plot.plot(pen=pg.mkPen(color='#38ef67', width=1.6))
        rl_v.addWidget(self.rl_plot, stretch=1)
        right_col.addWidget(rl_box, stretch=1)
        grid_layout.addLayout(right_col, 0, 2, 1, 1)

        # ----------------------------------------------------
        # 3. BOTTOM ROW (Sensors + Summary + Logs)
        # ----------------------------------------------------
        bottom_row = QHBoxLayout()
        bottom_row.setSpacing(6)

        # A. Sensor Data (Depth & Obstacle Plots)
        sensor_box = QFrame()
        sensor_box.setProperty("class", "panel")
        sensor_box.setFrameShape(FRAME_STYLED)
        sensor_v = QVBoxLayout(sensor_box)
        sensor_v.setContentsMargins(0, 0, 0, 0)
        sensor_v.setSpacing(0)
        t_sens = QLabel("SENSOR DATA")
        t_sens.setProperty("class", "panelTitle")
        sensor_v.addWidget(t_sens)

        sensor_plots = QHBoxLayout()
        sensor_plots.setContentsMargins(4, 2, 4, 2)
        sensor_plots.setSpacing(4)

        # Depth Plot
        depth_frame = QFrame()
        depth_v = QVBoxLayout(depth_frame)
        depth_v.setContentsMargins(0, 0, 0, 0)
        depth_v.setSpacing(0)
        d_lbl = QLabel("Depth (m)")
        d_lbl.setAlignment(ALIGN_CENTER)
        d_lbl.setStyleSheet("font-size: 8.5px; color: #88a1aa;")
        self.depth_plot = pg.PlotWidget()
        self.depth_plot.showGrid(x=True, y=True, alpha=0.15)
        self.depth_plot.getViewBox().invertY(True)  # Depth goes downward
        self.depth_curve = self.depth_plot.plot(pen=pg.mkPen(color='#30b4ff', width=1.5))
        depth_v.addWidget(d_lbl)
        depth_v.addWidget(self.depth_plot, stretch=1)
        sensor_plots.addWidget(depth_frame)

        # Obstacle Distance Plot
        obs_frame = QFrame()
        obs_v = QVBoxLayout(obs_frame)
        obs_v.setContentsMargins(0, 0, 0, 0)
        obs_v.setSpacing(0)
        o_lbl = QLabel("Distance to Obstacle (m)")
        o_lbl.setAlignment(ALIGN_CENTER)
        o_lbl.setStyleSheet("font-size: 8.5px; color: #88a1aa;")
        self.obs_plot = pg.PlotWidget()
        self.obs_plot.showGrid(x=True, y=True, alpha=0.15)
        self.obs_curve = self.obs_plot.plot(pen=pg.mkPen(color='#35f163', width=1.5))
        obs_v.addWidget(o_lbl)
        obs_v.addWidget(self.obs_plot, stretch=1)
        sensor_plots.addWidget(obs_frame)
        sensor_v.addLayout(sensor_plots)
        bottom_row.addWidget(sensor_box, stretch=2)

        # B. Exploration Summary (Donut Chart)
        sum_box = QFrame()
        sum_box.setProperty("class", "panel")
        sum_box.setFrameShape(FRAME_STYLED)
        sum_v = QVBoxLayout(sum_box)
        sum_v.setContentsMargins(0, 0, 0, 0)
        sum_v.setSpacing(0)
        t_sum = QLabel("EXPLORATION SUMMARY")
        t_sum.setProperty("class", "panelTitle")
        sum_v.addWidget(t_sum)

        sum_body = QHBoxLayout()
        sum_body.setContentsMargins(8, 4, 8, 4)
        sum_body.setSpacing(6)

        sum_kv = QGridLayout()
        sum_kv.setSpacing(3)
        self.sum_labels = {}
        for idx, (k, d_val) in enumerate([("Explored Area:", "0.0 %"), ("Rock:", "0.0 %"), ("Sand:", "0.0 %"), ("Coral Reef:", "0.0 %"), ("Unexplored:", "100.0 %")]):
            l_k = QLabel(k)
            l_k.setStyleSheet("color: #7d96a0; font-size: 9px;")
            l_v = QLabel(d_val)
            l_v.setStyleSheet("color: #e1edf2; font-weight: bold; font-size: 9.5px;")
            sum_kv.addWidget(l_k, idx, 0)
            sum_kv.addWidget(l_v, idx, 1)
            self.sum_labels[k] = l_v

        sum_body.addLayout(sum_kv)
        self.donut_widget = DonutWidget()
        sum_body.addWidget(self.donut_widget)
        sum_v.addLayout(sum_body)
        bottom_row.addWidget(sum_box, stretch=1)
        grid_layout.addLayout(bottom_row, 1, 1, 1, 2)

        # ----------------------------------------------------
        # 4. SYSTEM LOG (Latest 4 messages)
        # ----------------------------------------------------
        log_frame = QFrame()
        log_frame.setFixedHeight(30)
        log_frame.setStyleSheet("background-color: #03080d; border: 1px solid #142833; border-radius: 2px;")
        log_layout = QHBoxLayout(log_frame)
        log_layout.setContentsMargins(8, 0, 8, 0)
        log_layout.setSpacing(14)

        t_log = QLabel("SYSTEM LOG (Latest)")
        t_log.setStyleSheet("color: #9db2bc; font-size: 9.5px; font-weight: bold;")
        log_layout.addWidget(t_log)

        self.log_msgs = QLabel("[00:00:00] Camera feed acquired   [00:00:01] CNN Prediction: ROCKY   [00:00:02] PPO Agent active")
        self.log_msgs.setStyleSheet("color: #3de865; font-family: monospace; font-size: 9.5px;")
        log_layout.addWidget(self.log_msgs, stretch=1)
        root_layout.addWidget(log_frame)

    # ----------------------------------------------------
    # BUTTON CONTROLS
    # ----------------------------------------------------
    def _on_start(self):
        if "start" in self.control_callbacks:
            self.control_callbacks["start"]()
        self.mission_status_lbl.setText("MISSION RUNNING")
        self.mission_status_lbl.setStyleSheet("color: #3de865; font-weight: bold;")

    def _on_pause(self):
        if "pause" in self.control_callbacks:
            self.control_callbacks["pause"]()
        self.mission_status_lbl.setText("MISSION PAUSED")
        self.mission_status_lbl.setStyleSheet("color: #ebaa38; font-weight: bold;")

    def _on_reset(self):
        if "reset" in self.control_callbacks:
            self.control_callbacks["reset"]()
        self.depth_history.clear()
        self.obstacle_history.clear()
        self.reward_history.clear()
        self.steps_history.clear()

    def _on_new_env(self):
        if "new_env" in self.control_callbacks:
            self.control_callbacks["new_env"]()

    def _set_speed(self, spd: int):
        for s, btn in self.spd_btns.items():
            if s == spd:
                btn.setStyleSheet("background-color: #0e313d; border-color: #35f163; color: #35f163;")
            else:
                btn.setStyleSheet("background-color: #081923; border: 1px solid #1c3c4d; color: #9cb2bd;")
        if "speed" in self.control_callbacks:
            self.control_callbacks["speed"](spd)

    # ----------------------------------------------------
    # TELEMETRY POLLING & UI UPDATE (Every 100ms)
    # ----------------------------------------------------
    def poll_state(self):
        with self.state_lock:
            state = dict(self.shared_state)

        if not state:
            return

        # 1. Update Timer
        elapsed = state.get("elapsed", time.time() - self.start_time)
        hrs = int(elapsed // 3600)
        mins = int((elapsed % 3600) // 60)
        secs = int(elapsed % 60)
        self.timer_lbl.setText(f"{hrs:02d}:{mins:02d}:{secs:02d}")

        # 2. Camera View & Chase Camera View
        cam_frame = state.get("camera_frame")
        if cam_frame is not None and isinstance(cam_frame, np.ndarray):
            h, w, ch = cam_frame.shape
            bytes_per_line = ch * w
            qimg = QImage(cam_frame.data, w, h, bytes_per_line, FORMAT_RGB888)
            self.cam_label.setPixmap(QPixmap.fromImage(qimg).scaled(self.cam_label.width(), self.cam_label.height(), KEEP_ASPECT))

        chase_frame = state.get("chase_frame")
        if chase_frame is not None and isinstance(chase_frame, np.ndarray):
            h, w, ch = chase_frame.shape
            bytes_per_line = ch * w
            qimg = QImage(chase_frame.data, w, h, bytes_per_line, FORMAT_RGB888)
            self.chase_label.setPixmap(QPixmap.fromImage(qimg).scaled(self.chase_label.width(), self.chase_label.height(), KEEP_ASPECT))

        # 3. CNN Classification Bars & Predicted Label
        cnn = state.get("cnn", {})
        probs = cnn.get("probabilities", {})
        p_rock = float(probs.get("Rock", 0.0))
        p_sand = float(probs.get("Sand", 0.0))
        p_coral = float(probs.get("Coral Reef", 0.0))

        self.rock_bar.setValue(int(p_rock * 100))
        self.rock_val.setText(f"{p_rock:.2f}")
        self.sand_bar.setValue(int(p_sand * 100))
        self.sand_val.setText(f"{p_sand:.2f}")
        self.coral_bar.setValue(int(p_coral * 100))
        self.coral_val.setText(f"{p_coral:.2f}")

        pred_name = cnn.get("class_name", "ROCK").upper()
        if pred_name == "ROCK":
            pred_name = "ROCKY"
        elif pred_name == "SAND":
            pred_name = "SANDY"
        self.pred_badge.setText(pred_name)

        # 4. Status Panel
        depth_val = float(state.get("depth", 11.5))
        speed_val = float(state.get("speed", 0.0))
        batt_val = float(state.get("battery", 100.0))
        heading_deg = math.degrees(float(state.get("heading", 0.0))) % 360
        ep_val = int(state.get("episode", 1))
        step_val = int(state.get("step", 0))

        self.stat_vals["Depth:"].setText(f"{depth_val:.1f} m")
        self.stat_vals["Speed:"].setText(f"{speed_val:.1f} m/s")
        self.stat_vals["Battery:"].setText(f"{batt_val:.0f}%")
        self.stat_vals["Heading:"].setText(f"{heading_deg:.0f}°")
        self.stat_vals["Mode:"].setText("Autonomous" if state.get("running", True) else "Paused")
        self.stat_vals["Episode:"].setText(str(ep_val))
        self.stat_vals["Step:"].setText(str(step_val))

        # 5. History Graphs
        self.depth_history.append(depth_val)
        obs_dist = float(state.get("obstacle_distance", 20.0))
        self.obstacle_history.append(obs_dist)
        reward_val = float(state.get("total_reward", 0.0))
        self.reward_history.append(reward_val)
        self.steps_history.append(step_val)

        if len(self.depth_history) > 200:
            self.depth_history.pop(0)
            self.obstacle_history.pop(0)
            self.reward_history.pop(0)
            self.steps_history.pop(0)

        # Update pyqtgraph plots
        self.depth_curve.setData(self.depth_history)
        self.obs_curve.setData(self.obstacle_history)
        self.rl_curve.setData(self.reward_history)

        # 6. Seabed 2D Classification Map
        cls_map = state.get("classified_map")
        exp_mask = state.get("explored_mask")
        path = state.get("path", [])
        pos = state.get("pos", (15.0, 15.0))
        if cls_map is not None and exp_mask is not None:
            self.map_widget.update_map(cls_map, exp_mask, path, pos)

            # Summary counts & Donut
            total_cells = exp_mask.size
            exp_count = int(exp_mask.sum())
            exp_pct = (exp_count / total_cells) * 100.0 if total_cells > 0 else 0.0

            r_count = int(((cls_map == 0) & exp_mask).sum())
            s_count = int(((cls_map == 1) & exp_mask).sum())
            c_count = int(((cls_map == 2) & exp_mask).sum())
            tot_exp = max(1, exp_count)

            r_p = (r_count / tot_exp) * 100.0
            s_p = (s_count / tot_exp) * 100.0
            c_p = (c_count / tot_exp) * 100.0
            unexp_p = 100.0 - exp_pct

            self.sum_labels["Explored Area:"].setText(f"{exp_pct:.1f} %")
            self.sum_labels["Rock:"].setText(f"{r_p:.1f} %")
            self.sum_labels["Sand:"].setText(f"{s_p:.1f} %")
            self.sum_labels["Coral Reef:"].setText(f"{c_p:.1f} %")
            self.sum_labels["Unexplored:"].setText(f"{unexp_p:.1f} %")
            self.donut_widget.update_values(r_p, s_p, c_p)

        # 7. System Log messages
        logs = state.get("logs", [])
        if logs:
            self.log_msgs.setText("   ".join(logs[-4:]))
