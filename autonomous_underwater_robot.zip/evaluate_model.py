import pathlib
import json
import torch
from torch.utils.data import DataLoader
from torchvision import datasets, transforms, models
import numpy as np
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix
import matplotlib.pyplot as plt

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
ROOT = pathlib.Path(__file__).parent
DATA_ROOT = ROOT / "cnn_dataset"
TEST_DIR = DATA_ROOT / "test"
MODELS_DIR = ROOT / "models"
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
BATCH_SIZE = 32

def load_model_and_classes():
    """Load the trained model and the class names from the training folder."""
    train_dir = ROOT / "cnn_dataset" / "train"
    dummy_dataset = datasets.ImageFolder(train_dir)
    class_names = dummy_dataset.classes
    model = models.resnet18(pretrained=True)
    model.fc = torch.nn.Linear(model.fc.in_features, len(class_names))
    model_path = MODELS_DIR / "best_model.pth"
    ckpt = torch.load(model_path, map_location=DEVICE)
    if isinstance(ckpt, dict):
        ckpt = {k: v.float() if torch.is_tensor(v) and v.is_floating_point() else v for k, v in ckpt.items()}
    model.load_state_dict(ckpt)
    model.to(DEVICE)
    model.eval()
    return model, class_names

def get_dataloader():
    """Create a DataLoader for the test split (no multiprocessing on Windows)."""
    transform = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
    ])
    test_dataset = datasets.ImageFolder(TEST_DIR, transform=transform)
    return DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)

def evaluate():
    model, class_names = load_model_and_classes()
    test_loader = get_dataloader()
    all_preds = []
    all_labels = []
    with torch.no_grad():
        for inputs, labels in test_loader:
            inputs = inputs.to(DEVICE)
            outputs = model(inputs)
            _, preds = torch.max(outputs, 1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
    accuracy = accuracy_score(all_labels, all_preds)
    precision, recall, f1, _ = precision_recall_fscore_support(
        all_labels, all_preds, average="weighted"
    )
    conf_mat = confusion_matrix(all_labels, all_preds)
    metrics = {
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "num_test_images": len(all_labels),
        "class_names": class_names,
    }
    metrics_path = MODELS_DIR / "evaluation_metrics.json"
    with open(metrics_path, "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)
    print(f"Evaluation metrics saved to {metrics_path}")
    plt.figure(figsize=(12, 10))
    plt.imshow(conf_mat, interpolation="nearest", cmap=plt.cm.Blues)
    plt.title("Confusion Matrix (Test Set)")
    plt.colorbar()
    tick_marks = np.arange(len(class_names))
    plt.xticks(tick_marks, class_names, rotation=90)
    plt.yticks(tick_marks, class_names)
    conf_norm = conf_mat.astype("float") / conf_mat.sum(axis=1)[:, np.newaxis]
    thresh = conf_norm.max() / 2.0
    for i, j in np.ndindex(conf_mat.shape):
        plt.text(j, i, f"{conf_mat[i, j]}\n{conf_norm[i, j]:.2f}",
                 horizontalalignment="center",
                 color="white" if conf_norm[i, j] > thresh else "black",
                 fontsize=8)
    plt.ylabel("True label")
    plt.xlabel("Predicted label")
    plt.tight_layout()
    conf_path = MODELS_DIR / "confusion_matrix.png"
    plt.savefig(conf_path, dpi=150)
    print(f"Confusion matrix image saved to {conf_path}")

if __name__ == "__main__":
    evaluate()
