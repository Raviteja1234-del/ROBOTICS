import os
import requests

BASE_URL = "https://huggingface.co/datasets/EPFL-ECEO/coralscapes/resolve/main/"

files = [
    "data/test-00000-of-00003.parquet",
    "data/test-00001-of-00003.parquet",
    "data/test-00002-of-00003.parquet",

    "data/train-00000-of-00009.parquet",
    "data/train-00001-of-00009.parquet",
    "data/train-00002-of-00009.parquet",
    "data/train-00003-of-00009.parquet",
    "data/train-00004-of-00009.parquet",
    "data/train-00005-of-00009.parquet",
    "data/train-00006-of-00009.parquet",
    "data/train-00007-of-00009.parquet",
    "data/train-00008-of-00009.parquet",

    "data/validation-00000-of-00001.parquet",

    ".gitattributes",
    "README.md",
    "figures/demo1.png",
    "figures/demo2.png",
    "figures/demo3.png",
    "figures/polygon_counts_colored.pdf",
    "figures/polygon_counts_colored.png",
    "id2label.json",
    "label2color.json",
]

OUT_DIR = "coralscapes"

os.makedirs(OUT_DIR, exist_ok=True)

for i, file_path in enumerate(files, 1):

    destination = os.path.join(OUT_DIR, file_path)
    os.makedirs(os.path.dirname(destination), exist_ok=True)

    print()
    print("=" * 70)
    print(f"[{i}/{len(files)}] {file_path}")

    if os.path.exists(destination) and os.path.getsize(destination) > 0:
        size_mb = os.path.getsize(destination) / (1024 * 1024)
        print(f"Already exists: {size_mb:.2f} MB")
        print("Skipping...")
        continue

    url = BASE_URL + file_path + "?download=true"

    try:
        print("Starting download...")

        with requests.get(
            url,
            stream=True,
            timeout=120,
            allow_redirects=True
        ) as response:

            response.raise_for_status()

            total = int(response.headers.get("content-length", 0))
            downloaded = 0
            temp_file = destination + ".part"

            with open(temp_file, "wb") as f:

                for chunk in response.iter_content(
                    chunk_size=1024 * 1024
                ):

                    if not chunk:
                        continue

                    f.write(chunk)
                    downloaded += len(chunk)

                    if total:
                        percent = downloaded * 100 / total

                        print(
                            f"\rProgress: {percent:6.2f}% "
                            f"({downloaded / (1024*1024):.1f} MB / "
                            f"{total / (1024*1024):.1f} MB)",
                            end="",
                            flush=True
                        )
                    else:
                        print(
                            f"\rDownloaded: "
                            f"{downloaded / (1024*1024):.1f} MB",
                            end="",
                            flush=True
                        )

            os.replace(temp_file, destination)

        print()
        print(f"Completed: {file_path}")

    except Exception as e:

        print()
        print(f"FAILED: {file_path}")
        print(f"Error: {e}")

        temp_file = destination + ".part"

        if os.path.exists(temp_file):
            os.remove(temp_file)

        print("Moving to the next file...")

print()
print("=" * 70)
print("DOWNLOAD PROCESS FINISHED")
print("=" * 70)