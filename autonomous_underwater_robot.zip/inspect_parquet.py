import pathlib, sys
import pyarrow.parquet as pq

def inspect_parquet(file_path: pathlib.Path):
    if not file_path.exists():
        print(f"Parquet file not found: {file_path}")
        sys.exit(1)
    table = pq.read_table(file_path)
    print(f"Rows: {table.num_rows}")
    print(f"Columns: {table.column_names}")
    if table.num_rows == 0:
        print("Parquet file has no rows.")
        return
    # inspect first row
    row = table.slice(0, 1).to_pydict()
    img = row['image'][0]
    lbl = row['label'][0]
    print("--- First row ---")
    print(f"Image keys: {list(img.keys())}")
    print(f"Image path: {img.get('path')}")
    print(f"Image bytes length: {len(img.get('bytes', b''))}")
    print(f"Label type: {type(lbl)}")
    if isinstance(lbl, dict):
        print(f"Label keys: {list(lbl.keys())}")
        first_key = next(iter(lbl))
        print(f"Label example: {{'{first_key}': {lbl[first_key]}}}")
    else:
        print(f"Label value: {lbl}")

if __name__ == "__main__":
    test_path = pathlib.Path(__file__).parent / "coralscapes" / "data" / "test-00000-of-00003.parquet"
    inspect_parquet(test_path)
